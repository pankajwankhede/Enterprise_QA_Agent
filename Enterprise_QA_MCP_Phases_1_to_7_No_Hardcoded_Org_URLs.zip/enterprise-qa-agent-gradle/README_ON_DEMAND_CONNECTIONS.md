# On-demand corporate connection enrollment (Windows + macOS)

This revision extends the Gradle source project with a browser-led, local-portal connection manager for the existing MCP connectors. It is **not an SSO-cookie extractor** and it **cannot exchange a normal corporate SSO website login for an API credential without an official provider-supported authorization flow**.

## QA engineer experience

1. A QA engineer asks GitHub Copilot to perform a supported tool operation, such as `sauce_get_job` or `octane_search_defects`.
2. If the OS vault has no credential, the tool creates a nonsecret pending request and tries to start the local browser portal. If a portal process is already running, the engineer uses its existing authenticated tab.
3. The portal automatically displays **Live Phase 7 → On-demand Connections** when started by a pending request. Otherwise select the tab manually and press **Refresh**.
4. The engineer uses **Open organization's sign-in** to visit the configured *approved HTTPS* Sauce Labs/Octane/etc. website and complete corporate SSO if needed. This step does **not** extract browser cookies or grant API access by itself.
5. Using an API credential that the organization's tool administrator explicitly permits (access key, personal API token or supported delegated authorization), the engineer enters it in the local protected portal. Sauce Labs typically expects `username:access-key`; other tools have different methods. **Never paste enterprise credentials into Copilot or source code.**
6. Backend stores the secret in the **Windows Credential Manager** or native **macOS Keychain** and checks the appropriate live HTTPS API endpoint. Credentials and API responses are not returned to Copilot. If the provider rejects the credential, the request is marked failed and the newly enrolled credential is discarded.
7. The pending request ID can be checked via the MCP tool `qa_connection_resume`. For **allowlisted read-only operations** `sauce_job` and `octane_defect_search`, the portal resumes that specific read and caches only its restricted result summary. All other actions must be retried explicitly after connection. No defect creates, file writes or CI runs are automatically replayed.
8. Once connected, following approved MCP reads use the OS-vault credential. On HTTP 401 for Sauce/Octane/Bitbucket, the old credential is invalidated and the browser connection flow is requested again.

## Connector behavior

| Tool | On-demand enrollment | API validation method | Seamless read-only resume |
|---|---|---|---|
| Sauce Labs | Browser sign-in + approved access key | `/rest/v1/users/{account}` or specific job lookup | `sauce_job` |
| ALM Octane | Browser sign-in + approved tenant API credential | Workspace defects list (profile shared-space/workspace required) | `octane_defect_search` |
| Bitbucket DC | Approved personal access token | Projects endpoint | Re-run original operation |
| Splunk Cloud | Approved management REST access token | Server info endpoint | Re-run original operation; search adapter still limited |
| Jira Cloud | Approved personal API token (email:token), tenant policy permitting | `/rest/api/3/myself` | Re-run original operation |
| Confluence Cloud | Approved personal API token (email:token), tenant policy permitting | `/wiki/api/v2/spaces?limit=1` | Re-run original operation |
| Jenkins | Approved `username:API-token` | `/api/json` | Never auto-replay CI trigger |

**Enterprise SSO OAuth:** Real one-click browser OAuth 2.0 with PKCE needs per-provider API authorization support, an organization-registered OAuth client ID and approved redirect/scopes. Sauce Labs and ALM Octane tenant auth schemes must be confirmed with administrators. The current flow uses official SSO website navigation plus approved API credential enrollment; it **does not implement provider OAuth exchange, refresh tokens or true zero-entry SSO-to-API authorization**. An IT-issued API key may be required. The browser process must not read SSO browser cookies.

## Setup

No tool credentials are required during Windows/macOS installation. Configure each team's HTTPS service URL only when needed from **Live Phase 7 → Connection Setup**. For ALM Octane, set shared space in `project` and workspace in `workspace` on the connection profile. The listed external API validation endpoints may be disallowed by your organization; confirm scopes and network allowlisting.

Windows CMD source build:

```cmd
scripts\build-windows.cmd
scripts\run-local-portal.cmd
```

macOS Terminal (on Mac):

```bash
bash scripts/build-macos.sh --app-image
bash scripts/run-local-portal-macos.sh
```

MCP tools are launched through the normal installed `--mcp` stdio mode, separately from the `--spring.profiles.active=portal` browser service. The on-demand request is coordinated using an ephemeral nonsecret JSON request file stored under `~/.enterprise-qa-mcp/pending-connections`. Request statuses expire after 30 minutes. OS vault credentials survive application restart; request state survives either process restarting.

## Security / production blockers

- The local API requires a per-process session token and loopback/Host/Origin validation. URLs must use approved HTTPS endpoints. OS-level malware/local process compromise remains a threat.
- Do not pass passwords, refresh tokens, SSO cookies or API keys into Copilot prompts, CLI arguments, source control, test fixtures, log events or browser URLs.
- Approvals for reading requirements, generating test code or executing tests remain separate from connection enrollment.
- The portal currently does not implement organization-wide SSO identity, enterprise RBAC, audit signing or centralized approval. That is a separate enterprise deployment requirement.
- Connecting a tool does **not** expand the engineer's access beyond existing service/API permissions.
- Existing platform-specific code has **not been built or end-to-end tested with enterprise systems** in this environment. Native Windows/macOS installers, Keychain API interaction, live Sauce Labs/Octane API validation, corporate SSO compatibility and IDE MCP compatibility require on-device testing. Corporate endpoint/security approvals and approved app registrations may be necessary.
- This is a **development implementation**, not a production-certified connector. A corporate HTTPS host allowlist and complete response redaction policy are required before broad rollout.
