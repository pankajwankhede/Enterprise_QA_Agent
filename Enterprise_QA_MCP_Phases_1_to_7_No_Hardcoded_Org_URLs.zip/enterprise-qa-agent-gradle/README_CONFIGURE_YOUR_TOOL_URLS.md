# Organization URLs removed from the distribution

This source does not bundle your company Bitbucket, ALM Octane, Jira, Confluence, Sauce Labs, Splunk, or Jenkins URLs; there are no prefilled organization-specific shared-space/workspace IDs.

After installing or launching the React portal, open **Connection Setup** (or **On-demand Connections** after a Copilot request). Enter the exact approved HTTPS API base URL for each tool **only when needed**. For ALM Octane fill:

- **Approved HTTPS service base URL**: your tenant origin (without the `/ui/` page route)
- **Optional project/shared-space**: your numeric shared-space ID
- **Optional workspace**: your numeric workspace ID

The nonsecret URL/profile information is saved under the individual user's `.enterprise-qa-mcp/connector-profiles.json`, not included in the installer. Credentials are kept separate in the approved OS credential store. The browser SSO login and API authorization flow still depend on enterprise provider capabilities and administrator approval.

Internal local portal addresses such as `http://127.0.0.1:8765` are deliberately retained: they are loopback addresses, **not corporate service URLs**. Generic sample `example.com`, `example.corp`, and registry placeholders are documentation, not runtime defaults.

No service is considered connected just because a URL is saved; its API reachability and authentication must be validated separately.
