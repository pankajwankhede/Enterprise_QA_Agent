> **Gradle edition note:** This file may contain historical implementation notes. Use the root `README.md` for current CMD/Gradle commands.

# Phase 7 scope and limitations

## Implemented in this starter
- React Phase 7 sample screens: Dashboard, Connections, Source Approval, Framework Discovery, Test Case Management, Execution Planner, Approvals, Results.
- Framework *hint* detection from manually provided filenames, example team catalog and execution-plan text generation as read-only MCP tools.
- Loopback-bound servlet profile for serving a production-built React app.
- Windows `jpackage` build script for bundled-runtime app image and optional WiX-backed EXE installer.
- Previous Phase 1–6 read-only integration foundation retained.

## Not implemented: critical production functionality
- Source approvals persisted securely and enforced server side (including user identity/task/scope/expiry).
- Team-specific Bitbucket/Jira/Confluence/OpenAPI/DB discovery; every source must be user authorized and URL allowlisted.
- Jenkins job triggering, webhook verification, approval gates, queue polling, notifications and permissions.
- Sauce Labs target capability lookup, account quota validation, device availability, test artifact collection in Phase 7.
- Automatic Copilot generation of test code or patching; require interactive authorized IDE workflow and reviewed PR.
- Secure loopback browser API authentication, CSRF and origin controls for any future mutation endpoints.
- Production-grade deployment checks, signed Windows installer, corporate TLS trust, admin approval and integration tests.

## Approval boundaries
1. Engineer approves each precise source/location/scope; never assume permission because a credential is configured.
2. Engineer reviews collected rules/test data provenance before proposed code changes.
3. Automation test changes through code review / branch protection.
4. Execution plan immutable and approved by authorized approver; actual execution mediated by Jenkins.
5. Octane/Jira/Confluence writes independently approved.

A per-laptop application cannot act as an always-on webhook listener when switched off. Use the organization's approved Jenkins job and Jenkins input gate for deployment-driven approvals. Do not make Jenkins read a QA engineer's local Windows Credential Manager entries.
