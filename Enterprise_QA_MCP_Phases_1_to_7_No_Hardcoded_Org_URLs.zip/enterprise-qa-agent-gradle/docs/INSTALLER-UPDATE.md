> **Gradle edition note:** This file may contain historical implementation notes. Use the root `README.md` for current CMD/Gradle commands.

# Windows installer and first-launch wizard update

The 8-step React Setup Wizard is accessible in the application's **Setup Wizard** menu. Native `jpackage` installation and the in-app first-launch setup are separate: the native installer installs prebuilt binaries and the bundled JRE; the wizard configures each engineer's local build environment.

## Wizard screens
1. Welcome
2. Installation Folder (informational: the actual installer controls this)
3. Java Configuration (bundled runtime or optional existing Java)
4. Node.js Configuration (optional local execution)
5. Build Environment: paste `.npmrc`, React project/commands, Gradle Wrapper and the three `ORG_GRADLE_PROJECT_nexus*` inputs
6. Verification (configuration checks only; live endpoints are not tested)
7. Summary & Save (local nonsecret profile; Nexus password enrollment to Windows Credential Manager)
8. Install/Finish (this is the React setup completion screen, not an MSI/EXE installation progress indicator)

## Security
`npmrc` editor is intentionally restricted to a supported **nonsecret subset**. Potential authentication values and unsupported keys are rejected, not silently stored. The design must be extended with a dedicated secure credential-import workflow before arbitrary complete `.npmrc` secrets can be imported. Do not paste organization credentials into Copilot prompts or screenshots. Nexus password is sent to the protected loopback endpoint and stored with the Windows Credential Manager adapter. The username is stored as nonsecret metadata. Treat local shell or debugger access as sensitive.

The local profile is written to `${user.home}/.enterprise-qa-mcp/installer-build-profile.json`. This prototype does not create global environment variables, run npm/Gradle scripts, install Node.js, download dependencies, or override corporate policies. Jenkins jobs must use Jenkins-managed secrets, not personal Windows secrets.

## Windows building
Run `scripts/build-windows.cmd -BuildExe` on an approved Windows build machine with JDK 21, Gradle (approved), Node.js/npm, corporate artifact access, and `jpackage`'s Windows packaging prerequisites (including compatible WiX for EXE). The generated source project has not been compiled or packaged as an EXE in this environment.
