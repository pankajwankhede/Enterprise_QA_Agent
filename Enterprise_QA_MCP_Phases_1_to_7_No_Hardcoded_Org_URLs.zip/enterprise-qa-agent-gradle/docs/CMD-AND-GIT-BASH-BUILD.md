> **Gradle edition note:** This file may contain historical implementation notes. Use the root `README.md` for current CMD/Gradle commands.

# Windows build without PowerShell

**Windows Command Prompt** from the project root:

```cmd
scripts\build-windows.cmd
scripts\build-windows.cmd --exe
```

**Git Bash** from the project root:

```bash
bash scripts/build-windows.sh --exe
```

Git Bash delegates to `cmd.exe` because `jpackage --type exe` runs on Windows. Neither script calls PowerShell.

For a built backend, start the development portal using:

```cmd
scripts\run-local-portal.cmd
```

Credential utility (developers only; requires Gradle):

```cmd
scripts\connect.cmd status bitbucket
```

## Requirements and important limitations

- These are **build-machine scripts**, not actions QA engineers need to perform with the finished installer.
- On the Windows build machine, JDK 21 with `jpackage`, Gradle, Node.js/npm and appropriate WiX tooling for EXE packaging must be installed and callable from that CMD/Git Bash session. Paths can reside on any drive; nothing is hardcoded to `C:`.
- The scripts use the configured `npm` registry and Gradle repository. If your organization blocks public registries, set up approved mirrors, trusted corporate CA certificates, and build-machine credentials beforehand. Do not put secrets in the script or commit them to Git.
- The frontend currently lacks a committed `package-lock.json`; the fallback `npm install` is not reproducible. Generate/review/commit a lockfile before an approved production release.
- Test build output, startup, and actual enterprise integrations on a Windows machine before distributing. This update does not turn placeholders into complete production functionality.
- Running the installed prebuilt application does **not** require Node.js, Gradle, or Gradle on QA laptops; those may be required to **build a particular automation framework locally**.
- The installed agent's bundled Java runtime is independent of the user's own Java path. Gradle itself still needs an appropriate build JDK on the builder.
