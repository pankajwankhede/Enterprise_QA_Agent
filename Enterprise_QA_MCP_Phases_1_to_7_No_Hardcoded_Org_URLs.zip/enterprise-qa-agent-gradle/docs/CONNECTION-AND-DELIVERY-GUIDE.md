> **Gradle edition note:** This file may contain historical implementation notes. Use the root `README.md` for current CMD/Gradle commands.

# Connection-driven installation and implementation boundaries

## What engineers provide at installation or on first access

Open **Live Phase 7 → Connection Setup**. Configure *nonsecret* HTTPS base URLs per tool. This is local user-specific configuration, stored in `%USERPROFILE%\.enterprise-qa-mcp\connector-profiles.json`. Example: Bitbucket `https://bitbucket.example.corp`, Jenkins `https://jenkins.example.corp`, Sauce Labs API for the correct region, Splunk REST API endpoint, tenant-specific Octane/Jira/Confluence endpoints. Do not copy a browser UI URL into an API field without verifying the documented API origin.

No URL is assumed valid merely because the user entered it. API calls additionally require the user's supported and authorized authentication method, corporate network access, TLS verification and server permissions. Supported credentials are enrolled separately through approved Windows Credential Manager workflows, not in Copilot or YAML.

## Agent approval boundaries

- Source URL enrollment does not grant source read permission. Each task must request and persist a separately scoped, expiring source access approval.
- A local plan approval cannot certify an organization's QA reviewer identity. **Production authorization for unattended Jenkins deployment-driven execution must be enforced within Jenkins**, e.g. an `input` step with `submitter` role/user/group allowlist, or via a central identity-backed approval service.
- The current local plan approval confirmation code alone is **not** proof of an authorized human identity. Limit local direct Jenkins execution to allowlisted, non-production jobs with independent Jenkins permissions and approval gate.
- Endpoint URL configuration does not permit arbitrary websites to be fetched by the framework scanner: the scanner calls the configured Bitbucket API with specific path components.
- Database aliases need a vetted allowlist and read-only query templates before enabling database data collection. No arbitrary connection URLs or SQL from prompts.

## Verified scope vs further integration needed

**Implemented source operations:** local/Bitbucket Data Center file tree scanning (framework hints), scoped source approval records, immutable execution plan creation, Jenkins build submission with configured user credential and allowlisted jobs, read-only Jenkins build status API, local framework scaffolding. These need a real deployment for integration verification.

**Not yet end-to-end complete:** automated modification of arbitrary existing automation frameworks, acceptance-criteria extraction from real Jira/Confluence tenants, Atlassian OAuth3LO native authorization, Sauce Labs device capability validation and artifact collection for every runner, supported Octane tenant auth, Splunk Cloud REST search adapter, universal production identity/approval enforcement, safe automatic AI code generation in CI, and corporate end-to-end tests.

**Why configuration alone does not implement an integration:** each SaaS or enterprise system has different authentication flows, API data models, tenant-specific permissions and version-dependent endpoints. Tests must run against approved sandbox instances. No generic URL + token form can guarantee those capabilities.

## Required test inventory to finish real integrations

One nonsecret sample for each: an actual Bitbucket automation repository structure, Jenkinsfile with build parameter names, Sauce Labs region and job/session metadata shape, sample approved Jira issue + Confluence page, Octane API auth method and test response, Splunk Cloud REST API access availability. Sensitive data must be redacted.

## Build and installer

See `scripts/build-windows.cmd`; on a Windows build host with Java 21, Gradle, npm and WiX, run with `-BuildExe`. This archive contains source and build scripts, **not** a verified EXE or verified production integrations.

## Approval gate for Jenkins workers

The example `examples/jenkins/Jenkinsfile` now uses a Jenkins `input` step and requires the Jenkins admin to configure `QA_APPROVERS` to authorized users/groups. This is the **authoritative CI approval**, independent of the local React plan acknowledgment. For real corporate deployments, verify that branch/revision checked out by the test job maps to the approved application deployment and that Sauce Labs secrets are configured in Jenkins Credential Store. Jenkins may impose additional security and CSRF requirements.
