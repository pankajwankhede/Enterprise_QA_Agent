# Enterprise QA MCP Agent — E2E Local Runner Integration

This package extends the previous Windows/macOS Gradle project. It is **development source**, not a production-certified application and not an already-built EXE/DMG.

## What is really implemented in this revision

- **Local Gradle, Playwright, Cypress, or saucectl runner** via fixed allowed commands, only for QA-approved local directory.
- **Two-step execution**: prepare (does not run), and explicit approval in the React portal (starts test process).
- **Fail-closed**: local runner is off by default. Enable only after application owner authorizes running repository scripts.
- **Task-scoped source approvals** for exact local directory or exact Jira/Confluence/Swagger URL.
- **Read-only Jira issue, Confluence page, and OpenAPI JSON retrieval** for individually approved sources. Jira/Confluence reads use **approved personal API tokens** in email:token format, not automatic enterprise SSO/OAuth.
- **Bitbucket Data Center framework repository-file listing and local framework scan** retained.
- **Sauce Labs job metadata lookup** using configured HTTPS API endpoint and personally approved credentials.
- **Read-only Jenkins status and approval-gated Jenkins build submission** retained from previous version.
- **Local output collection**: exit code, bounded runtime, log tail, and discovered `TEST-*.xml` JUnit test reports.
- **Gradle Nexus runtime properties** loaded from optional nonsecret build profile; Windows Credential Manager stores the Nexus password.
- **Selenium/JUnit scaffold now Gradle-based**, not Maven.
- **React Live Phase 7** has tabs for requirements, local execution and Sauce results.
- Copilot MCP tools can prepare local jobs and read status, but cannot bypass the React execution approval.

## Critical limitations / prerequisites

- No organization credentials, API access or endpoint availability were provided. **Actual integration testing against your enterprise systems has not been performed.**
- **A full working CI/production workflow is not verified**. Sauce Labs remote browser sessions must be configured in the respective team's *automation framework*; the runner does not automatically rewrite frameworks to support every browser/device. Browser/device labels are passed as environment metadata and require framework-specific adapter configuration.
- The local runner **does not install project dependencies**; it assumes `node_modules` for Playwright/Cypress or a working Gradle Wrapper, corporate npm/Nexus config and trusted TLS certificates. Avoid arbitrary network installs automatically.
- `saucectl run` assumes the approved `saucectl` CLI exists and the target project is configured.
- Automated generation/modification of arbitrary test-code using Jira/Confluence requirements needs Copilot-assisted editing and QA review; this source supplies requirements but doesn't independently run an LLM or auto-edit any project.
- Missing full OAuth 3LO sign-in, OpenText Octane session auth, Splunk Cloud tenant validation, mobile device availability validation, CI deployment webhooks and centralized enterprise approval identities. These require tenant-specific integrations and real testing.
- macOS Keychain credential adapter is still missing: credentialed connector calls will not work on macOS until implemented and tested.
- Build and frontend compilation could **not** be run here because Gradle and required npm packages are unavailable in the offline environment. Java source parsing succeeded for all code.
- Local execution can execute arbitrary code *within the approved repository's Gradle/npm test scripts*: only use repos trusted by your organization; no production environment is allowed by the local runner.

## Windows: use CMD (not PowerShell)

From extracted project root:

```cmd
scripts\build-windows.cmd
```

For a Windows EXE on a machine with required WiX tooling:

```cmd
scripts\build-windows.cmd --exe
```

Install the locally generated prebuilt application, or run portal for development:

```cmd
set QA_LOCAL_EXECUTION_ENABLED=true
scripts\run-local-portal.cmd
```

Do not set the enable flag until the organization has approved local code execution. When unset, the runner rejects all run preparation attempts.

Credential enrollment (Windows only; interactive, approved personal tokens, not SSO passwords):

```cmd
scripts\connect.cmd save bitbucket
scripts\connect.cmd save sauce
scripts\connect.cmd save jira
scripts\connect.cmd save confluence
```

### Local execution example

1. Select Connections, supply approved HTTPS base URLs (Bitbucket, Sauce Labs, Jira, etc.).
2. Select Source Approvals: task `qa-otp-task`, source `framework`, mode `CONNECT`, location absolute local automation repo path such as `D:\\Work\\bc-ui-automation`. Approve it.
3. Select Framework Discovery and scan the same local directory.
4. Select Local Execution: task `qa-otp-task`, same exact path; framework `gradle`, suite `smoke`, environment `qa`, target `chrome`; click Prepare.
5. Review the execution details, then explicitly approve execution in the portal.
6. Click Refresh to obtain job status and a bounded log tail; JUnit report count is stored under `%USERPROFILE%\.enterprise-qa-mcp\local-runs`.
7. For Sauce Labs job results, configure its approved API URL and account credentials; use Sauce Results with an actual Sauce job ID.

### Requirement retrieval example

1. QA approves a Jira issue URL as source=`jira`, e.g. `https://team.atlassian.net/browse/TEAM-123`.
2. Configure Jira base host and approved personal API token (`email:token`) using Windows credential enrollment.
3. In Requirements, enter the exact approved URL, task ID and Jira as source.
4. The agent fetches the approved issue summary and description. Copy only policy-permitted sanitized context into Copilot for test generation.
5. QA reviews generated test code and submits a PR. Execution has its own independent approval.

## E2E test checklist for corporate validation

- Validate Windows installation and MCP tools/list in Copilot.
- Validate read-only Bitbucket scan across two approved projects.
- Validate isolated Jira, Confluence and Swagger approvals including denied access.
- Validate local Java/Gradle and Playwright execution on a small *synthetic* test application.
- Confirm JUnit report discovery, browser-specific session IDs, Sauce Labs job metadata.
- Confirm corporate Nexus/npm/certificate settings and expired credentials behavior.
- Confirm approval challenge expiry, rejection, restart, and fail-closed behavior.
- Verify no secrets appear in logs, stdout, Copilot tool outputs, profiles, or installer binaries.
- Validate Jenkins approval/post-deployment flow separately before enabling it.
- Confirm endpoint security, code signing, macOS Keychain, macOS notarization and corporate release processes.

See `docs/IMPLEMENTATION-STATUS-E2E.md` for a capability-by-capability status table.
