# Windows + macOS Enterprise QA Agent Packaging — Phase 1–7

## What changed

- **No Node.js, npmrc, Gradle, Nexus, or JDK setup in the installed app’s First Run Setup screen.** The installed runtime bundles Java and compiled React assets.
- Optional team automation builds use the separate **Build Environment** menu in React. No source-code rebuild is needed to edit nonsecret local build profiles.
- Windows CMD/Git Bash scripts remain available.
- Native macOS build script added: `scripts/build-macos.sh --dmg`, `--pkg`, or `--app-image`.
- macOS installation and Windows installation require **separate native builds**. Windows cannot use `jpackage` to create macOS DMG/PKG. A Mac (Apple Silicon or Intel matching target architecture) is required to package and verify macOS builds.

## Building on macOS

Using Terminal (or a compatible Bash shell):

```bash
java -version
node -v
npm -v
gradle --version
jpackage --version
bash scripts/build-macos.sh --dmg
```

Requires: approved JDK 21, Node.js/npm, approved Gradle, company npm and Maven/Nexus registry access on the **build Mac only**. `jpackage` bundles Java for consumers. Output: `macos-dist/`. DMG is not signed/notarized automatically.

For an installer package rather than disk image: `bash scripts/build-macos.sh --pkg`. For local standalone app bundle: `bash scripts/build-macos.sh --app-image`.

## Building on Windows

CMD:

```cmd
scripts\build-windows.cmd --exe
```

Git Bash on Windows:

```bash
bash scripts/build-windows.sh --exe
```

Requires JDK 21, npm, Gradle, and compatible WiX for EXE generation **on build Windows only**.

## Mac credential storage limitation

**The existing source code uses the Windows Credential Manager. It does not have a macOS Keychain adapter yet.** The macOS application is packageable and may run the local portal, but Mac users cannot enroll or use protected enterprise connector credentials until a native macOS Keychain implementation and integration tests are added. It fails closed rather than storing secrets in plaintext or passing them as CLI args.

## Security and production caveats

Phase 1–7 enterprise integrations still require actual tenant authentication, approval enforcement, Sauce Labs/Jenkins validation, security checks and end-to-end testing. Cross-platform source packaging alone is **not** a tested production installer. Sign/notarize approved macOS artifacts and code-sign Windows artifacts before distributing to users. Do not disable certificate checks. Keep local user data outside app installation folders.

The first-run React guide is just guidance; it does not change native installer location or auto-register IDEs. Use a tested launcher/configuration for MCP IDE support.
