> **New:** See [On-demand Connection Enrollment](README_ON_DEMAND_CONNECTIONS.md) for browser-led setup on Windows/macOS and MCP request continuation.

# Windows and macOS packaging update

See [README_CROSS_PLATFORM.md](README_CROSS_PLATFORM.md) for the revised installation approach. Native installers contain prebuilt React and bundled Java; npmrc/Gradle/Nexus inputs are **not** required for installation, only optional local automation builds.

# Enterprise QA MCP Agent — Gradle Edition (Phases 1–7)

This is the **Gradle backend edition** of the existing development starter. There is **no `pom.xml` and no Maven requirement**.

**Status:** Source conversion completed; Gradle dependency resolution/compilation, Windows packaging, enterprise API integrations, and IDE registration have **not** been verified end to end. Do not treat this as a production-certified installer.

## Build locally with CMD (no PowerShell)

1. Extract the ZIP and open CMD in the folder containing `backend`, `frontend`, `scripts`.
2. Verify `java -version` (JDK 21), `gradle --version` (approved Gradle 8.14+/compatible version), `node -v`, `npm -v`, and `jpackage --version`.
3. Configure your organization's approved `.npmrc`, Nexus/Gradle init script, and corporate CA trust if required. Do **not** put credentials into `build.gradle` or Git.
4. Run `scripts\build-windows.cmd` to compile React and the Gradle backend and build a Windows app image.
5. Run `scripts\run-local-portal.cmd` and open `http://127.0.0.1:8765/`.
6. After validation, run `scripts\build-windows.cmd --exe` to attempt Windows EXE packaging (requires compatible WiX tooling).

Alternatively from Git Bash: `bash scripts/build-windows.sh --exe`.

## Backend only

```cmd
cd backend
gradle --no-daemon clean test bootJar
```

Generated executable JAR: `backend\build\libs\enterprise-qa-mcp-0.1.0.jar`.

## Gradle Wrapper

A Gradle Wrapper cannot safely be claimed included without its binary `gradle-wrapper.jar`. The archive ships **Gradle build definitions but not a Wrapper binary**. Use an organization-approved Gradle installation first; optionally run `gradle wrapper --gradle-version <approved-version>` and commit the generated wrapper files, including the binary, after supply-chain review. The scripts automatically prefer `gradlew.bat` when present.

## Nexus credentials

The team's requested Gradle project environment values are:

- `ORG_GRADLE_PROJECT_nexusUrl`
- `ORG_GRADLE_PROJECT_nexusUsername`
- `ORG_GRADLE_PROJECT_nexusPassword`

The setup UI models these three fields. For local builds, use your organization's approved credential injection. **The backend `build.gradle` does not automatically read Nexus settings**; a corporate Gradle init script or an approved repository configuration must supply the Nexus mirror and its credentials. Do not hardcode secrets.

## Approved credential utility

```cmd
scripts\connect.cmd save bitbucket
scripts\connect.cmd status bitbucket
```

This launches a Gradle `JavaExec` task which prompts through the Windows terminal; do not supply credentials as command-line arguments.

## Production limitations

Phase 1–7 components remain at differing maturity levels, including placeholders and demo actions. The installer is not compiled, signed, or tested here. Actual source approvals, OAuth, Sauce Labs mobile runs, CI coordination and corporate identity checks require controlled integration testing and security review. Read `docs/IMPLEMENTATION-MATRIX.md` before enabling any writes.
