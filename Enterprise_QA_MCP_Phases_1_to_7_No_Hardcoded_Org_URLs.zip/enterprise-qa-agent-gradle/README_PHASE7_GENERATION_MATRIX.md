# Phase 7 — Test-code generation + Sauce Labs target matrix

This source increment adds real API and MCP operations, **but is not a tested enterprise integration or a general autonomous coding agent**. Generate-test uses deterministic Java templates populated by explicitly verified QA test cases. GitHub Copilot may separately propose complex edits from authorized context, with standard code review. No separate unattended LLM execution is configured.

## Requirements

- Windows/macOS local application, Java 21/Gradle project; live build must be tested on your laptop.
- The approved local test repository must be trusted: Gradle and saucectl execute the repository's own scripts.
- Local Phase 7 execution remains **disabled by default**. Only if company policy allows, launch the portal with `QA_LOCAL_EXECUTION_ENABLED=true` (Windows CMD: `set QA_LOCAL_EXECUTION_ENABLED=true` before `scripts\run-local-portal.cmd`).
- Source approval is explicit **per task and exact local directory**. In Source Approvals set source `framework`, mode `CONNECT`, location the absolute test repository path. For test generation also approve `qaInput`, mode `MANUAL`, with real QA-verified requirements (synthetic data only). This workflow cannot use unapproved external requirements.
- Existing company QA credentials remain in Windows Credential Manager. The macOS Keychain adapter remains unimplemented; do not store API secrets in macOS plaintext configuration.

## Test generation workflow

1. Approve local `framework` directory and `qaInput` manual requirements independently.
2. Select **Test Code Generator** in the React Live Phase 7 portal.
3. Select Playwright TypeScript or Selenium Java/JUnit and provide the verified feature slug, URL path, CSS locator, assertion text and synthetic data provenance.
4. Click **Generate reviewable test code**. A source draft and SHA-256 fingerprint are stored in the user's app data folder; original repo files are untouched.
5. Review the code, then choose **Approve & write**. For a new target, the agent uses create-new semantics so existing files cannot be overwritten. For **previously generated Playwright** tests, the agent can add test cases only after checking the old content's SHA and obtaining a new approval; it backs up the previous version. Arbitrary edits/retirements of existing team tests require Copilot-assisted reviewed Git patches.
6. Run team lint/compile/tests, review Git diff and commit/PR under established QA team approval policy.

The generator produces assertions only from QA-confirmed structured scenarios. It cannot infer all business rules from developer source code, and does not auto-delete tests.

### API examples (within protected local portal only)

`POST /api/v1/phase7/live/test-code/generate`

```json
{
  "task":"otp-demo",
  "repository":"D:\\Work\\qa-automation",
  "framework":"playwright-ts",
  "feature":"otp-validation",
  "requirementSource":"qaInput",
  "scenarios":[{"name":"Valid OTP","urlPath":"/verify","locator":"[data-testid=success]","expectedText":"Verified","dataSourceId":"QA-approved-synthetic-123"}]
}
```

`POST /api/v1/phase7/live/test-code/approve` requires the exact `id` and `sha256` from the reviewed draft. No API can silently force overwrite.

## Sauce Labs browser/device matrix

1. Copy `examples/sauce-matrix/qa-sauce-matrix.json` into the local **approved test repository root**, named `qa-sauce-matrix.json`. This is an EXAMPLE — replace profiles, devices and suite mappings with platform targets truly supported by your account and test framework.
2. For `runner=saucectl`, ensure `saucectl` is installed in the approved runtime and the referenced `.sauce/*.yml` configuration files and named suites are valid. For `runner=gradle`, the test project needs a Gradle wrapper plus code that reads `QA_BROWSER`, `QA_PLATFORM`, `QA_BROWSER_VERSION`, `QA_DEVICE_NAME` and uses Sauce RemoteWebDriver/Appium correctly. The agent does not magically create a mobile test from a desktop browser test.
3. Configure approved Sauce Labs API URL in **Connections**, then enroll the personal `username:access-key` credential in native credential store. Do not paste secrets into Copilot.
4. Select **Sauce Matrix**, enter the task, exact approved framework directory, target IDs from the manifest, suite and parallel limit.
5. **Prepare** validates manifest, target names, mobile device mapping, reference files, Sauce credential availability, local opt-in flag and declared concurrency. It is NOT a live device-quota check.
6. **Approve** starts bounded target executions with at most `parallel` simultaneous subprocesses. Each subprocess receives a single target's requested metadata and Sauce credential in its child environment.
7. **Refresh** shows target PASS/FAIL, exit code and log file reference. If framework code writes `{ "jobId":"SAUCE_JOB_ID" }` to `<QA_RUN_OUTPUT_DIR>/sauce-job.json`, the run result links the job ID to the target; use the existing Sauce Results API to query Sauce account evidence.

The scheduler uses `saucectl run --config <config.yml> --select-suite <suite> --region <region> --ccy 1` for each `saucectl` target, as documented by Sauce Labs. It requires correct configuration YAMLs and an installed binary. The accepted regions in this source are `us-west-1`, `us-east-4`, `eu-central-1`.

This is **not** an online device catalog, a Sauce quota entitlement check, or guaranteed support of all combinations of browser/mobile framework. Unsupported targets must remain unconfigured rather than be guessed. Sauce concurrency is determined by account entitlements and requires customer-admin verification.

### Example matrix request

`POST /api/v1/phase7/live/sauce-matrix/prepare`

```json
{"task":"otp-demo","directory":"D:\\Work\\qa-automation","targetIds":["chrome-win","firefox-win"],"parallel":2,"suite":"smoke"}
```

Approval is separate: `POST /api/v1/phase7/live/sauce-matrix/approve` with exact `id`, `checksum` and `confirmation` from the local portal. No GitHub Copilot tool can approve or launch directly.

## Build and test

Windows CMD (no PowerShell):

```cmd
scripts\build-windows.cmd
scripts\build-windows.cmd --exe
```

macOS Terminal:

```bash
bash scripts/build-macos.sh --dmg
```

Builds require an approved Gradle environment, Node/npm dependencies, corporate registries and certificates on the **developer build machine only**. The installed portal itself does not need development tools. Local execution of project tests requires its approved runtime/dependencies. macOS native credential integration and notarization still require work.

## Verification completed in authoring environment

- ZIP integrity and file presence verified.
- Java syntax parsed using installed Java 21 compiler APIs.
- JSX syntax parsed using installed TypeScript compiler.
- **Not completed:** Full Gradle/npm compilation (dependencies unavailable), live Sauce Labs remote run, live Bitbucket/Jira auth, Windows EXE/macOS DMG generation, corporate security review.

Do not distribute as production-certified software until these pass. Follow `docs/IMPLEMENTATION-STATUS-E2E.md` for other phases' status.
