> **Gradle edition note:** This file may contain historical implementation notes. Use the root `README.md` for current CMD/Gradle commands.

# Enterprise QA MCP — Phases 1–7 starter

This archive extends the previous Phases 1–6 starter with **Phase 7 Automation Lifecycle design and preview implementation**. The code is an engineering starter, **not a production-complete seven-phase platform**.

## Two modes

**Copilot / MCP mode:** previous Spring AI MCP stdio configuration (`backend/src/main/resources/application.yml`) and the Phase 7 read-only MCP preview tools. Start with `java -jar backend/build/libs/enterprise-qa-mcp-0.1.0.jar` after building.

**React portal mode:** Spring Boot uses `--spring.profiles.active=portal` (`application-portal.yml`) to bind to `127.0.0.1:8765` and serve the built React assets. Phase 7 React approval buttons are demo-only and do not authorize external reads or launch Jenkins.

## Windows build (on a Windows build machine)
1. Install JDK 21 (with `jpackage`), Gradle (approved), Node.js/npm. Optional EXE installer requires Windows-compatible WiX Toolset.
2. Run `powershell -ExecutionPolicy Bypass -File .\scripts\build-windows.ps1` for an app-image with bundled Java runtime.
3. For an EXE installer, run `powershell -ExecutionPolicy Bypass -File .\scripts\build-windows.ps1 -BuildExe` after installing compatible WiX. Builds may need corporate proxy/network approval.
4. Launch built `windows-dist/EnterpriseQA/EnterpriseQA.exe`, the app attempts to open http://127.0.0.1:8765 automatically when started in a desktop session. If browser auto-open is blocked by corporate policy, navigate there manually.

## Local developer mode
- Frontend: `cd frontend; npm install; npm run dev` (Vite preview, client-only).
- Backend: `cd backend; mvn clean verify` (MCP stdio when run without portal profile).
- Portal production mode requires copying built `frontend/dist/*` to `backend/src/main/resources/static/` BEFORE packaging the JAR; Windows build script does this.

## Caveats
- Existing Windows Credential Manager adapter in v1 is a starting point; verify Windows-native struct layout/operation on actual Windows before using any real secrets.
- Never reuse `syf-skills` token files, scrape browser cookies, or paste secrets into Copilot or source code.
- Do not expose the portal beyond loopback. Before implementing actual credential/approval/write operations, secure the portal with per-launch authentication, Origin and CSRF validation and least privilege.
- Build script assumes compatible versions of Java, Gradle, Node and WiX and has **not** been executed on Windows here.
- Read `docs/PHASE7-SECURITY-AND-ROADMAP.md` for the implementation matrix.
