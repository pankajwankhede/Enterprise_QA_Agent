package com.company.qa;
import com.company.qa.phase7.full.LocalAutomationRunner;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
class LocalAutomationRunnerTest {
 @Test void localExecutionFailsClosedByDefault() {
   LocalAutomationRunner runner=new LocalAutomationRunner(null,null,null);
   var request=new LocalAutomationRunner.Request("task1","C:\\qa\\automation","gradle","smoke","qa",
           List.of("chrome"),1,false);
   assertThrows(IllegalStateException.class,()->runner.prepare(request));
 }
}
