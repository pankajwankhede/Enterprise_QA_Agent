package com.company.qa;
import com.company.qa.phase7.full.SauceMatrixOrchestrator;
import com.company.qa.phase7.full.SourceApprovals;
import com.company.qa.ConnectionService;
import com.company.qa.WindowsCredentials;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.test.util.ReflectionTestUtils;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.nio.file.*;
import java.util.*;
class SauceMatrixTest {
 @TempDir Path repo;
 @Test void failsClosedWithoutOperatorEnabling(){
   var orchestrator=new SauceMatrixOrchestrator(null,null,null);
   assertThrows(IllegalStateException.class,()->orchestrator.prepare(new SauceMatrixOrchestrator.Request("case1",repo.toString(),List.of("chrome"),1,"smoke")));
 }
 @Test void rejectsMissingApprovedManifest(){
   var source=mock(SourceApprovals.class);var credentials=mock(ConnectionService.class);
   var orchestrator=new SauceMatrixOrchestrator(source,credentials,mock(WindowsCredentials.class));
   ReflectionTestUtils.setField(orchestrator,"enabled",true);
   assertThrows(IllegalArgumentException.class,()->orchestrator.prepare(new SauceMatrixOrchestrator.Request("case1",repo.toString(),List.of("chrome"),1,"smoke")));
 }
}
