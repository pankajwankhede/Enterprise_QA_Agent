package com.company.qa;
import com.company.qa.phase7.full.ConnectorProfiles;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class ConnectorProfilesTest {
 @Test void rejectsSecretInUrl(){assertThrows(IllegalArgumentException.class,()->ConnectorProfiles.validate(new ConnectorProfiles.Endpoint("bitbucket","https://user:pass@bitbucket.example.com",null,null,null)));}
 @Test void rejectsHttp(){assertThrows(IllegalArgumentException.class,()->ConnectorProfiles.validate(new ConnectorProfiles.Endpoint("jenkins","http://jenkins.example.com",null,null,null)));}
 @Test void acceptsApprovedHttpsShape(){assertDoesNotThrow(()->ConnectorProfiles.validate(new ConnectorProfiles.Endpoint("bitbucket","https://bitbucket.example.com",null,null,null)));}
}
