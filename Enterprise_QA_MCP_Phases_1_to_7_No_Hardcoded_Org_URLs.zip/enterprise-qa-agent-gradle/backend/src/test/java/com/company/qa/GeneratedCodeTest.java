package com.company.qa;
import com.company.qa.phase7.full.TestCodeGeneration;
import com.company.qa.phase7.full.SourceApprovals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
class GeneratedCodeTest {
 @TempDir Path repo;
 @Test void generatesReviewedPlaywrightDraftWithoutModifyingRepository(){
   var approvals=mock(SourceApprovals.class);
   when(approvals.get("case1","qaInput")).thenReturn(Optional.of(new SourceApprovals.Decision("case1","qaInput","MANUAL","","Test verified text", "scope1",Instant.now().getEpochSecond())));
   var service=new TestCodeGeneration(approvals);
   var draft=service.generate(new TestCodeGeneration.Request("case1",repo.toString(),"playwright-ts","otp-validation",
      List.of(new TestCodeGeneration.Scenario("OTP valid","/verify","[data-testid=success]","Verified","QA-123")),"qaInput"));
   assertEquals("AWAITING_QA_REVIEW",draft.status());
   assertTrue(draft.content().contains("QA-123"));
   assertFalse(Files.exists(repo.resolve("tests/generated/otp-validation.spec.ts")));
   var accepted=service.approve(new TestCodeGeneration.Approval(draft.id(),draft.sha256()));
   assertEquals("WRITTEN_TO_WORKTREE_REVIEW_COMMIT_REQUIRED",accepted.status());
   assertTrue(Files.exists(repo.resolve("tests/generated/otp-validation.spec.ts")));
   assertThrows(IllegalStateException.class,()->service.approve(new TestCodeGeneration.Approval(draft.id(),draft.sha256())));
   var extension=service.generate(new TestCodeGeneration.Request("case1",repo.toString(),"playwright-ts","otp-validation",
      List.of(new TestCodeGeneration.Scenario("OTP expired","/verify","[data-testid=expired]","Expired","QA-124")),"qaInput"));
   assertEquals("APPEND_TO_GENERATED_FILE",extension.changeType());
   assertEquals("AWAITING_QA_REVIEW",extension.status());
   assertTrue(Files.readString(repo.resolve("tests/generated/otp-validation.spec.ts")).contains("OTP valid"));
   service.approve(new TestCodeGeneration.Approval(extension.id(),extension.sha256()));
   assertTrue(Files.readString(repo.resolve("tests/generated/otp-validation.spec.ts")).contains("OTP expired"));

 }
 @Test void requiresQARequirementsApproval(){
   var approvals=mock(SourceApprovals.class);
   var service=new TestCodeGeneration(approvals);
   assertThrows(IllegalStateException.class,()->service.generate(new TestCodeGeneration.Request("case2",repo.toString(),"playwright-ts","otp-validation",
      List.of(new TestCodeGeneration.Scenario("Valid","/verify","#success","Verified","QA-123")),"qaInput")));
 }
}
