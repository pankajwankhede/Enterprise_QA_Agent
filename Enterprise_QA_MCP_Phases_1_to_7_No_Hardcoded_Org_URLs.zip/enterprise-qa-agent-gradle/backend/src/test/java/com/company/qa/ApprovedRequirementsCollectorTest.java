package com.company.qa;
import com.company.qa.phase7.full.ApprovedRequirementsCollector;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class ApprovedRequirementsCollectorTest {
 @Test void invalidSourceRejectedBeforeNetworkCall() {
   var collector=new ApprovedRequirementsCollector(null,null,null,null);
   assertThrows(IllegalArgumentException.class,
       ()->collector.collect(new ApprovedRequirementsCollector.Request("task","database","https://example.com")));
 }
}
