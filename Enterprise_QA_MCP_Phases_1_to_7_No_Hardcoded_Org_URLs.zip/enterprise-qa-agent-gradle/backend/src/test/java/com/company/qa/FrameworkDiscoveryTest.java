package com.company.qa;
import com.company.qa.phase7.full.FrameworkDiscovery;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
class FrameworkDiscoveryTest {
 @Test void discoversPlaywrightTests(){FrameworkDiscovery finder=new FrameworkDiscovery(null,null,null,null);var result=finder.analyze("project/repo",List.of("playwright.config.ts","package.json","tests/login.spec.ts","data/testdata.json"),"abc",true);assertEquals("Playwright",result.framework());assertEquals("npm",result.buildTool());assertEquals(1,result.testFiles().size());}
 @Test void unknownIsNotInvented(){FrameworkDiscovery finder=new FrameworkDiscovery(null,null,null,null);var result=finder.analyze("project/repo",List.of("README.md"),"abc",true);assertTrue(result.framework().contains("UNKNOWN"));}
}
