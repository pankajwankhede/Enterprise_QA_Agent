package com.company.qa;
import com.company.qa.phase7.full.OnDemandConnections;
import org.junit.jupiter.api.Test;
import java.nio.file.*;
import static org.junit.jupiter.api.Assertions.*;
class OnDemandConnectionsTest {
 @Test void blocksUnapprovedAutomaticWrites(){
   OnDemandConnections service=new OnDemandConnections(null,null,null);
   assertThrows(IllegalArgumentException.class,()->service.request("octane","create_defect","x"));
   assertThrows(IllegalArgumentException.class,()->service.request("sauce","sauce_job","malformed"));
 }
 @Test void blocksSecretLookingArguments(){
   OnDemandConnections service=new OnDemandConnections(null,null,null);
   assertThrows(IllegalArgumentException.class,()->service.request("jira","","token=abc123"));
 }
}
