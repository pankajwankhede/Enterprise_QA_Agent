package com.company.qa;
import com.company.qa.phase7.full.ExecutionWorkflows;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
class ExecutionWorkflowsTest {
 @Test void invalidRevisionRejected(){ExecutionWorkflows service=new ExecutionWorkflows(null,null,null);assertThrows(IllegalArgumentException.class,()->service.prepare(new ExecutionWorkflows.Prepare("app","smoke","qa","develop",List.of("chrome"),1,"test-job")));}
}
