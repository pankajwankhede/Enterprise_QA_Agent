package com.company.qa;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;
class GuardTest { @Test void blocksTraversal(){assertThrows(IllegalArgumentException.class,()->Guard.project("../etc"));} @Test void acceptsProject(){assertEquals("BANKING",Guard.project("BANKING"));} @Test void redacts(){assertFalse(Guard.redacted("Bearer ABCDE123").contains("ABCDE123"));} }
