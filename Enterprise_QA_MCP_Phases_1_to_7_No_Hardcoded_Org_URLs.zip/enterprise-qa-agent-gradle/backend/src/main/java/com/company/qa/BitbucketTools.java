package com.company.qa;
import org.springframework.ai.mcp.annotation.McpTool;import org.springframework.stereotype.Component;
@Component
public class BitbucketTools{
 private final com.company.qa.phase7.full.ConnectorProfiles profiles;private final ApiClient api;private final ConnectionService conn;private final com.company.qa.phase7.full.AutoConnectGate gate;
 public BitbucketTools(ApiClient a,ConnectionService c,com.company.qa.phase7.full.ConnectorProfiles p,com.company.qa.phase7.full.AutoConnectGate gate){api=a;conn=c;profiles=p;this.gate=gate;}
 @McpTool(name="bitbucket_connection_status",description="Check the local Bitbucket connection")public String status(){return conn.status("bitbucket");}
 @McpTool(name="bitbucket_list_projects",description="List accessible Bitbucket Data Center projects, read-only")
 public String projects(){if(gate.missing("bitbucket"))return gate.connect("bitbucket","","");try{return api.get(profiles.base("bitbucket")+"/rest/api/1.0/projects?limit=25","Bearer "+conn.require("bitbucket")).toString();}catch(IllegalStateException e){if(gate.authRejected(e)){gate.invalidate("bitbucket");return gate.connect("bitbucket","","");}throw e;}}
 @McpTool(name="bitbucket_list_repositories",description="List accessible repositories for a Bitbucket project")
 public String repositories(String projectKey){Guard.project(projectKey);if(gate.missing("bitbucket"))return gate.connect("bitbucket","","");try{return api.get(profiles.base("bitbucket")+"/rest/api/1.0/projects/"+api.enc(projectKey)+"/repos?limit=25","Bearer "+conn.require("bitbucket")).toString();}catch(IllegalStateException e){if(gate.authRejected(e)){gate.invalidate("bitbucket");return gate.connect("bitbucket","","");}throw e;}}
}
