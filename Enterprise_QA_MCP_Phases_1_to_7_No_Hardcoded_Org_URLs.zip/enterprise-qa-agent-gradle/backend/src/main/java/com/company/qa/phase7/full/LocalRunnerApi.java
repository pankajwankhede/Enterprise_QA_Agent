package com.company.qa.phase7.full;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/v1/phase7/live/local-runner")
public class LocalRunnerApi {
 private final LocalAutomationRunner runner;
 public LocalRunnerApi(LocalAutomationRunner runner){this.runner=runner;}
 @PostMapping("/prepare")
 public LocalAutomationRunner.Job prepare(@RequestBody LocalAutomationRunner.Request request){return runner.prepare(request);}
 @GetMapping("/{id}/challenge")
 public Map<String,String> challenge(@PathVariable String id){return Map.of("confirmation",runner.approvalChallenge(id));}
 @PostMapping("/approve")
 public LocalAutomationRunner.Job approve(@RequestBody LocalAutomationRunner.Approval request){return runner.approveAndStart(request);}
 @PostMapping("/{id}/reject")
 public LocalAutomationRunner.Job reject(@PathVariable String id){return runner.reject(id);}
 @GetMapping("/{id}")
 public LocalAutomationRunner.Job status(@PathVariable String id){return runner.read(id);}
 @GetMapping("/{id}/log")
 public Map<String,String> log(@PathVariable String id){return Map.of("tail",runner.logTail(id));}
}
