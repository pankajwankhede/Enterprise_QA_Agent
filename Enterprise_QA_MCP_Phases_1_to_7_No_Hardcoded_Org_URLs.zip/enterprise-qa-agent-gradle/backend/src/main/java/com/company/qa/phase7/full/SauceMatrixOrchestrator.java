package com.company.qa.phase7.full;

import com.company.qa.ConnectionService;
import com.company.qa.WindowsCredentials;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/** Parallel scheduling with explicit framework mappings; no invented Sauce capability discovery. */
@Service
public class SauceMatrixOrchestrator {
  public record Target(String id,String platform,String browser,String version,String deviceName,
                       String runner,String configFile,String suiteName) {}
  public record Manifest(List<Target> targets,int maxParallel,String region) {}
  public record Request(String task,String directory,List<String> targetIds,int parallel,String suite) {}
  public record Outcome(String targetId,String status,Integer exitCode,String logPath,String sauceJobId,String message,long finishedAt) {}
  public record Plan(String id,String task,String directory,List<Target> targets,int parallel,String suite,
                     String region,String state,String sha256,long createdAt,List<Outcome> outcomes) {}
  public record Approval(String id,String checksum,String confirmation) {}
  private final SourceApprovals approvals;private final ConnectionService credentials;private final WindowsCredentials vault;
  private final ObjectMapper json=new ObjectMapper();
  private final Path jobs=Path.of(System.getProperty("user.home"),".enterprise-qa-mcp","sauce-matrix");
  private final ExecutorService dispatcher=Executors.newSingleThreadExecutor();
  private final ConcurrentMap<String,String> challenges=new ConcurrentHashMap<>();
  @Value("${qa.phase7.local-execution.enabled:false}") boolean enabled;
  @Value("${qa.phase7.local-execution.max-minutes:30}") int timeoutMinutes;
  public SauceMatrixOrchestrator(SourceApprovals a,ConnectionService c,WindowsCredentials vault){approvals=a;credentials=c;this.vault=vault;}
  public synchronized Plan prepare(Request r){
    if(!enabled)throw new IllegalStateException("Local matrix execution disabled by policy");
    if(r==null||r.task()==null||!r.task().matches("[A-Za-z0-9_-]{1,64}")||
      !Set.of("smoke","regression","e2e","all").contains(r.suite()) ||r.parallel()<1||r.parallel()>8||
      r.targetIds()==null||r.targetIds().isEmpty()||r.targetIds().size()>12||
      r.targetIds().stream().distinct().count()!=r.targetIds().size())throw new IllegalArgumentException("Invalid target list, suite, or parallelism");
    approvals.require(r.task(),"framework",r.directory());
    Path root=root(r.directory());Manifest m=readManifest(root);
    if(r.parallel()>m.maxParallel())throw new IllegalArgumentException("Parallelism exceeds approved team manifest limit");
    Map<String,Target> available=new LinkedHashMap<>();for(Target t:m.targets()){
      validateTarget(root,t);if(available.put(t.id(),t)!=null)throw new IllegalStateException("Duplicate target ID");
    }
    List<Target> selected=new ArrayList<>();for(String s:r.targetIds()){
      Target t=available.get(s);if(t==null)throw new IllegalArgumentException("Unsupported or unconfigured target: "+s);selected.add(t);
    }
    String credential=credentials.require("sauce");if(credential.indexOf(':')<=0)throw new IllegalStateException("Sauce credentials require username:accessKey");
    String id=UUID.randomUUID().toString(),hash=digest(jsonBytes(selected)+"/"+r.suite()+"/"+root+"/"+r.parallel());
    Plan p=new Plan(id,r.task(),root.toString(),List.copyOf(selected),r.parallel(),r.suite(),m.region(),"PENDING_APPROVAL",hash,Instant.now().getEpochSecond(),List.of());
    persist(p);challenges.put(id,UUID.randomUUID().toString().substring(0,8));return p;
  }
  public String challenge(String id){Plan p=read(id);String c=challenges.get(id);if(!p.state().equals("PENDING_APPROVAL")||c==null)throw new IllegalStateException("Approval challenge expired; prepare again");return c;}
  public synchronized Plan approve(Approval req){
    Plan p=read(req.id());if(!p.state().equals("PENDING_APPROVAL")||!p.sha256().equals(req.checksum()))throw new IllegalStateException("Plan changed or not pending");
    if(Instant.now().getEpochSecond()-p.createdAt()>1800)throw new IllegalStateException("Plan expired");
    String expected=challenges.remove(p.id());if(expected==null||!expected.equals(req.confirmation()))throw new IllegalStateException("Approval challenge missing or incorrect");
    Plan q=transition(p,"QUEUED",List.of());dispatcher.submit(()->execute(q));return q;
  }
  public synchronized Plan reject(String id){Plan p=read(id);if(!p.state().equals("PENDING_APPROVAL"))throw new IllegalStateException("Not pending");challenges.remove(id);return transition(p,"REJECTED",List.of());}
  public Plan read(String id){if(id==null||!id.matches("[a-f0-9-]{36}"))throw new IllegalArgumentException("Invalid run id");try{return json.readValue(jobs.resolve(id).resolve("plan.json").toFile(),Plan.class);}catch(Exception e){throw new IllegalArgumentException("Unknown run",e);}}
  private void execute(Plan plan){
    try {
      transition(plan,"RUNNING",List.of());
      ExecutorService pool=Executors.newFixedThreadPool(plan.parallel());
      try{
        List<Future<Outcome>> futures=new ArrayList<>();for(Target t:plan.targets())futures.add(pool.submit(()->runTarget(plan,t)));
        List<Outcome> outcomes=new ArrayList<>();for(Future<Outcome> f:futures)outcomes.add(f.get(Math.max(1,timeoutMinutes)*60L+30L,TimeUnit.SECONDS));
        boolean passed=outcomes.stream().allMatch(o->o.status().equals("PASSED"));
        transition(plan,passed?"PASSED":"FAILED",outcomes);
      }finally{pool.shutdownNow();}
    }catch(Exception ex){transition(plan,"FAILED",List.of(new Outcome("matrix","FAILED",-1,"","","Matrix execution failed: "+ex.getClass().getSimpleName(),Instant.now().getEpochSecond())));}
  }
  private Outcome runTarget(Plan plan,Target t){
    Path folder=jobs.resolve(plan.id()).resolve(t.id());
    try{
      Files.createDirectories(folder);Path logfile=folder.resolve("runner.log");
      List<String> command=command(t,plan.suite(),plan.region());
      ProcessBuilder pb=new ProcessBuilder(command).directory(Path.of(plan.directory()).toFile()).redirectErrorStream(true);
      Map<String,String> env=pb.environment();String secret=credentials.require("sauce");int sep=secret.indexOf(':');
      env.put("SAUCE_USERNAME",secret.substring(0,sep));env.put("SAUCE_ACCESS_KEY",secret.substring(sep+1));
      env.put("QA_BROWSER",t.browser());env.put("QA_PLATFORM",t.platform());env.put("QA_BROWSER_VERSION",t.version());
      env.put("QA_DEVICE_NAME",t.deviceName());env.put("QA_MATRIX_TARGET",t.id());env.put("QA_TEST_SUITE",plan.suite());env.put("QA_RUN_OUTPUT_DIR",folder.toString());
      if(t.runner().equals("gradle"))applyNexusSettings(env);
      Process process=pb.start();
      String nexus="";try{nexus=vault.read("nexus-password").orElse("");}catch(Exception ignored){}
      final String nexusSecret=nexus;
      Thread logReader=Thread.ofVirtual().start(()->sanitizedLog(process.getInputStream(),logfile,secret.substring(sep+1),nexusSecret));
      env.remove("SAUCE_ACCESS_KEY");env.remove("SAUCE_USERNAME");env.remove("ORG_GRADLE_PROJECT_nexusPassword");
      boolean finished=process.waitFor(Math.max(1,timeoutMinutes),TimeUnit.MINUTES);
      if(!finished){process.descendants().forEach(ProcessHandle::destroyForcibly);process.destroyForcibly();}
      logReader.join(10000);
      int exit=finished?process.exitValue():-1;
      String jobId="";Path artifact=folder.resolve("sauce-job.json");
      if(Files.isRegularFile(artifact)&&Files.size(artifact)<4096){String extracted=json.readTree(artifact.toFile()).path("jobId").asText("");if(extracted.matches("[A-Za-z0-9_-]{1,128}"))jobId=extracted;}
      // Never return raw build output from a privileged child process to Copilot.
      return new Outcome(t.id(),finished&&exit==0?"PASSED":"FAILED",exit,logfile.toString(),jobId,finished?"Execution ended; review authorized logs and Sauce Labs job details":"Execution timed out",Instant.now().getEpochSecond());
    }catch(Exception e){return new Outcome(t.id(),"FAILED",-1,"","","Unable to start target: "+e.getClass().getSimpleName(),Instant.now().getEpochSecond());}
  }
  private void sanitizedLog(InputStream input,Path output,String sauceSecret,String nexusSecret){
    try(BufferedReader reader=new BufferedReader(new InputStreamReader(input,StandardCharsets.UTF_8));
        BufferedWriter writer=Files.newBufferedWriter(output,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW)){
      int limit=1_000_000;String line;
      while((line=reader.readLine())!=null){
        if(limit<=0)continue;
        if(line.length()>12000)line=line.substring(0,12000)+" [LINE TRUNCATED]";
        line=line.replace(sauceSecret,"[REDACTED]");
        if(!nexusSecret.isBlank())line=line.replace(nexusSecret,"[REDACTED]");
        line=line.replaceAll("(?i)(authorization|token|password|access.?key)\\s*[:=]\\s*[^\\s,;]+","$1=[REDACTED]");
        if(line.length()+1>limit)line=line.substring(0,Math.max(0,limit-25))+" [LOG TRUNCATED]";
        writer.write(line);writer.newLine();limit-=line.length()+1;
      }
    }catch(Exception ignored){} // Logs are optional; job result still records exit status.
  }
  private void applyNexusSettings(Map<String,String> env){
    Path profile=Path.of(System.getProperty("user.home"),".enterprise-qa-mcp","installer-build-profile.json");
    if(!Files.isRegularFile(profile))return;
    try{
      var config=json.readTree(profile.toFile());String url=config.path("nexusUrl").asText("");String username=config.path("nexusUsername").asText("");
      if(!url.isBlank()){
        java.net.URI u=java.net.URI.create(url);
        if(!"https".equalsIgnoreCase(u.getScheme())||u.getUserInfo()!=null)throw new IllegalStateException("Approved HTTPS Nexus required");
        env.put("ORG_GRADLE_PROJECT_nexusUrl",url);
      }
      if(!username.isBlank())env.put("ORG_GRADLE_PROJECT_nexusUsername",username);
      vault.read("nexus-password").ifPresent(secret->env.put("ORG_GRADLE_PROJECT_nexusPassword",secret));
    }catch(Exception ex){throw new IllegalStateException("Gradle Nexus configuration failed",ex);}
  }
  private List<String> command(Target t,String suite,String region){
    if(t.runner().equals("saucectl")){
      // One team-approved config per browser or mobile device. No arbitrary commands.
      return List.of("saucectl","run","--config",t.configFile(),"--select-suite",t.suiteName(),"--region",region,"--ccy","1");
    }
    boolean win=System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
    return win?List.of("cmd.exe","/d","/c","gradlew.bat","--no-daemon","test","-Dqa.matrixTarget="+t.id(),"-Dqa.suite="+suite):
               List.of("./gradlew","--no-daemon","test","-Dqa.matrixTarget="+t.id(),"-Dqa.suite="+suite);
  }
  private Manifest readManifest(Path root){
    try{Path f=root.resolve("qa-sauce-matrix.json");if(!Files.isRegularFile(f)||Files.isSymbolicLink(f))throw new IllegalArgumentException("Approved qa-sauce-matrix.json is required");
      if(Files.size(f)>100000)throw new IllegalArgumentException("Manifest too large");Manifest m=json.readValue(f.toFile(),Manifest.class);
      if(m.targets()==null||m.targets().isEmpty()||m.targets().size()>25||m.maxParallel()<1||m.maxParallel()>8||!Set.of("us-west-1","us-east-4","eu-central-1").contains(m.region()))throw new IllegalArgumentException("Invalid matrix manifest");return m;
    }catch(java.io.IOException e){throw new IllegalArgumentException("Cannot read approved matrix",e);}
  }
  private void validateTarget(Path root,Target t){
    if(t==null||!clean(t.id(),64)||!Set.of("windows","macos","android","ios").contains(t.platform())||
       !Set.of("chrome","edge","firefox","safari","appium").contains(t.browser())||
       !Set.of("gradle","saucectl").contains(t.runner())||!clean(t.version(),25)||
       t.deviceName()==null||t.deviceName().length()>100)throw new IllegalArgumentException("Invalid target capability");
    if(Set.of("android","ios").contains(t.platform())&&(t.deviceName().isBlank()||!t.browser().equals("appium")))throw new IllegalArgumentException("Mobile requires device profile and Appium adapter");
    if(t.runner().equals("saucectl")){
      if(t.configFile()==null||!t.configFile().matches("[A-Za-z0-9_./-]{1,150}")||t.configFile().contains("..")||
         t.suiteName()==null||!clean(t.suiteName(),80))throw new IllegalArgumentException("Unsafe saucectl configuration");
      Path f=root.resolve(t.configFile()).normalize();try{if(!f.toRealPath().startsWith(root)||!Files.isRegularFile(f)||Files.isSymbolicLink(f))throw new IllegalArgumentException("Unsafe approved saucectl config");}catch(java.io.IOException ex){throw new IllegalArgumentException("Missing approved saucectl config: "+t.configFile());}
    }else if(!Files.isRegularFile(root.resolve(isWindows()?"gradlew.bat":"gradlew")))throw new IllegalArgumentException("Gradle Wrapper required");
  }
  private Path root(String dir){try{Path p=Path.of(dir).toRealPath();if(!Files.isDirectory(p))throw new IllegalArgumentException("Not a folder");return p;}catch(Exception e){throw new IllegalArgumentException("Invalid framework path",e);}}
  private boolean isWindows(){return System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");}
  private boolean clean(String s,int max){return s!=null&&s.matches("[A-Za-z0-9_.-]{1,"+max+"}");}
  private String jsonBytes(Object x){try{return json.writeValueAsString(x);}catch(Exception e){throw new IllegalStateException(e);}}
  private String digest(String s){try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8)));}catch(Exception e){throw new IllegalStateException(e);}}
  private synchronized Plan transition(Plan p,String state,List<Outcome> outcomes){Plan n=new Plan(p.id(),p.task(),p.directory(),p.targets(),p.parallel(),p.suite(),p.region(),state,p.sha256(),p.createdAt(),outcomes);persist(n);return n;}
  private void persist(Plan p){try{Path folder=jobs.resolve(p.id());Files.createDirectories(folder);Path tmp=Files.createTempFile(folder,"plan-",".tmp");Files.writeString(tmp,json.writeValueAsString(p));Files.move(tmp,folder.resolve("plan.json"),StandardCopyOption.REPLACE_EXISTING);}catch(Exception e){throw new IllegalStateException("Could not save run state",e);}}
}
