package com.company.qa.phase7.full;
import java.nio.file.*;
import java.util.*;
import org.springframework.stereotype.Service;
/** Generates reviewable framework starter code only within explicitly approved local workspace. */
@Service public class FrameworkScaffolder {
 private final SourceApprovals approvals;
 public FrameworkScaffolder(SourceApprovals a){approvals=a;}
 public record ScaffoldRequest(String task,String workspace,String framework,String packageName){}
 public record ScaffoldResult(String folder,String framework,List<String> files,String nextStep){}
 public ScaffoldResult scaffold(ScaffoldRequest r){
  approvals.require(r.task(),"framework",r.workspace());
  if(!Set.of("playwright-ts","selenium-junit-java").contains(r.framework()))throw new IllegalArgumentException("Unsupported approved template");
  if(r.packageName()==null||!r.packageName().matches("[a-z][a-z0-9]*(\\.[a-z][a-z0-9]*){1,6}"))throw new IllegalArgumentException("Invalid Java package namespace");
  try{
   Path root=Path.of(r.workspace()).toRealPath();if(!Files.isDirectory(root))throw new IllegalArgumentException("Workspace not a directory");
   Path child=root.resolve("generated-qa-framework").normalize();if(Files.exists(child))throw new IllegalStateException("Destination exists; never overwrite existing automation");
   Files.createDirectory(child);Map<String,String> files=r.framework().equals("playwright-ts")?playwright():selenium(r.packageName());
   for(var e:files.entrySet()){
    Path dest=child.resolve(e.getKey()).normalize();if(!dest.startsWith(child))throw new IllegalStateException("Unsafe template path");Files.createDirectories(dest.getParent());Files.writeString(dest,e.getValue(),StandardOpenOption.CREATE_NEW);
   }
   return new ScaffoldResult(child.toString(),r.framework(),new ArrayList<>(files.keySet()),"QA must add approved test accounts, validated assertions, review/commit changes, and configure Sauce Labs runner separately");
  }catch(Exception e){throw new IllegalStateException("Framework scaffold failed: "+e.getMessage(),e);}
 }
 private Map<String,String> playwright(){LinkedHashMap<String,String> m=new LinkedHashMap<>();m.put("package.json","{\"private\":true,\"scripts\":{\"test\":\"playwright test\"},\"devDependencies\":{\"@playwright/test\":\"^1.55.0\"}}\n");m.put("playwright.config.ts","import {defineConfig} from '@playwright/test';\nexport default defineConfig({testDir:'./tests',fullyParallel:true,retries:0,use:{baseURL:process.env.QA_BASE_URL,trace:'retain-on-failure'},reporter:[['list'],['junit',{outputFile:'results/junit.xml'}]]});\n");m.put("tests/smoke.spec.ts","import {test,expect} from '@playwright/test';\ntest('home page loads (replace with verified business assertion)',async({page})=>{if(!process.env.QA_BASE_URL)throw new Error('QA_BASE_URL required');await page.goto('/');await expect(page.locator('body')).toBeVisible();});\n");m.put(".gitignore","node_modules/\nplaywright-report/\ntest-results/\nresults/\n.env\n");m.put("README.md","# Generated Playwright QA Starter\n\nThis is a reviewed starter only. Configure QA_BASE_URL and approved test fixtures. Run npm install && npm test. Sauce Labs adapter must be configured according to your account and supported runner.\n");return m;}
 private Map<String,String> selenium(String pkg){LinkedHashMap<String,String> m=new LinkedHashMap<>();String path="src/test/java/"+pkg.replace('.','/')+"/";m.put("settings.gradle","rootProject.name = 'qa-tests'\n");
m.put("build.gradle","plugins { id 'java' }\njava { toolchain { languageVersion = JavaLanguageVersion.of(21) } }\nrepositories { mavenCentral() }\ndependencies { testImplementation 'org.seleniumhq.selenium:selenium-java:4.35.0'; testImplementation 'org.junit.jupiter:junit-jupiter:5.13.4'; testRuntimeOnly 'org.junit.platform:junit-platform-launcher' }\ntest { useJUnitPlatform() }\n");m.put(path+"SmokeTest.java","package "+pkg+";\nimport org.junit.jupiter.api.Test;\nimport org.openqa.selenium.*;\nimport org.openqa.selenium.chrome.ChromeOptions;\nimport org.openqa.selenium.remote.RemoteWebDriver;\nimport java.net.URI;\nimport java.util.Map;\nimport static org.junit.jupiter.api.Assertions.*;\nclass SmokeTest {\n @Test void appIsReachable() throws Exception {\n  String grid=System.getenv(\"QA_REMOTE_WEBDRIVER_URL\");String target=System.getenv(\"QA_BASE_URL\");\n  if(grid==null||target==null)throw new IllegalStateException(\"QA_REMOTE_WEBDRIVER_URL and QA_BASE_URL required\");\n  ChromeOptions options=new ChromeOptions();options.setCapability(\"sauce:options\",Map.of(\"name\",\"QA smoke\"));\n  WebDriver driver=new RemoteWebDriver(URI.create(grid).toURL(),options);\n  try { driver.get(target);assertNotNull(driver.findElement(By.tagName(\"body\"))); } finally {driver.quit();}\n }\n}\n");m.put("README.md","# Selenium/JUnit QA Starter\n\nSupply approved QA_BASE_URL and QA_REMOTE_WEBDRIVER_URL securely. Configure Sauce Labs region/credential injection in CI, test data, and verified business assertions. Execute an approved Gradle build. Generate a Gradle Wrapper before CI use.\n");m.put(".gitignore","build/\n.gradle/\n.env\n");return m;}
}
