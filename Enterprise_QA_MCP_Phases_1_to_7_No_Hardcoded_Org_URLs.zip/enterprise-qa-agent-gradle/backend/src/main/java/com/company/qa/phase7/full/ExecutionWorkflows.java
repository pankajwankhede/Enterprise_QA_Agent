package com.company.qa.phase7.full;

import com.company.qa.ConnectionService;
import com.company.qa.ApiClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.net.http.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.time.Duration;
import java.security.*;
import java.util.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
@Service
public class ExecutionWorkflows {
 public record Prepare(String application,String suite,String environment,String revision,List<String> targets,int parallel,String jenkinsJob){}
 public record Plan(String id,Prepare request,String state,long createdAt,String fingerprint,String approvalCode,String buildUrl){}
 public record Decision(String planId,String approver,String approvalCode){}
 private final SourceApprovals approvals;private final ConnectionService connections;private final ConnectorProfiles profiles;private final ObjectMapper mapper=new ObjectMapper();private final HttpClient client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).followRedirects(HttpClient.Redirect.NEVER).build();
 private final Path store=Path.of(System.getProperty("user.home"),".enterprise-qa-mcp","executions");
 @Value("${qa.phase7.jenkins.base-url:}") String jenkinsBase;
 @Value("${qa.phase7.jenkins.allowed-jobs:}") String jobNames;
 @Value("${qa.phase7.allowed-environments:qa,staging}") String environments;
 @Value("${qa.phase7.max-parallel:4}") int maxParallel;
 public ExecutionWorkflows(SourceApprovals a,ConnectionService c,ConnectorProfiles p){approvals=a;connections=c;profiles=p;}
 public synchronized Plan prepare(Prepare r){
  if(r==null||!safe(r.application())||!Set.of("smoke","regression","e2e").contains(r.suite())||!Arrays.asList(environments.split(",")).contains(r.environment())||!r.revision().matches("[a-fA-F0-9]{40}"))throw new IllegalArgumentException("Invalid suite/environment or revision: exact Git commit SHA required");
  if(r.parallel()<1||r.parallel()>maxParallel||r.targets()==null||r.targets().isEmpty()||r.targets().size()>12)throw new IllegalArgumentException("Invalid or excess Sauce concurrency/targets");
  for(String target:r.targets())if(!Set.of("chrome","edge","firefox","safari","android","ios").contains(target.toLowerCase(Locale.ROOT)))throw new IllegalArgumentException("Unsupported target "+target);
  if(!safe(r.jenkinsJob())||!Arrays.asList(jobNames.split(",")).contains(r.jenkinsJob()))throw new IllegalArgumentException("Jenkins job not allowlisted");
  profiles.base("jenkins");
  // Generate SHA-256 fingerprint and approval challenge bound to immutable plan.
  String id=UUID.randomUUID().toString();String code=UUID.randomUUID().toString().substring(0,8).toUpperCase(Locale.ROOT);
  String fingerprint=sha(mapper.valueToTree(r).toString());
  Plan plan=new Plan(id,r,"PENDING_APPROVAL",Instant.now().getEpochSecond(),fingerprint,code,"");persist(plan);return plan;
 }
 public synchronized Plan approveAndLaunch(Decision d){
  if(d==null||!safe(d.approver()))throw new IllegalArgumentException("Approver identity required");
  Plan p=read(d.planId());if(!p.state().equals("PENDING_APPROVAL"))throw new IllegalStateException("Already reviewed or submitted");
  if(Instant.now().getEpochSecond()-p.createdAt()>1800)throw new IllegalStateException("Plan expired after 30 minutes");
  if(!p.approvalCode().equals(d.approvalCode()))throw new IllegalStateException("Approval confirmation mismatch");
  Plan submitting=new Plan(p.id(),p.request(),"SUBMITTING",p.createdAt(),p.fingerprint(),"","");persist(submitting);
  try {String url=submitJenkins(p.request());Plan submitted=new Plan(p.id(),p.request(),"QUEUED",p.createdAt(),p.fingerprint(),"",url);persist(submitted);return submitted;}
  catch(RuntimeException ex){Plan unknown=new Plan(p.id(),p.request(),"SUBMISSION_UNCERTAIN",p.createdAt(),p.fingerprint(),"","");persist(unknown);throw ex;}
 }
 public synchronized Plan reject(String id){Plan p=read(id);if(!p.state().equals("PENDING_APPROVAL"))throw new IllegalStateException("Cannot reject");Plan r=new Plan(p.id(),p.request(),"REJECTED",p.createdAt(),p.fingerprint(),"","");persist(r);return r;}
 public Plan read(String id){if(id==null||!id.matches("[a-f0-9-]{36}"))throw new IllegalArgumentException("Invalid plan ID");try{return mapper.readValue(store.resolve(id+".json").toFile(),Plan.class);}catch(Exception e){throw new IllegalArgumentException("Unknown execution plan",e);}}
 private void persist(Plan p){try{Files.createDirectories(store);Path tmp=Files.createTempFile(store,"plan-",".tmp");Files.writeString(tmp,mapper.writeValueAsString(p));try{Files.move(tmp,store.resolve(p.id()+".json"),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(tmp,store.resolve(p.id()+".json"),StandardCopyOption.REPLACE_EXISTING);}}catch(Exception e){throw new IllegalStateException("Cannot persist plan",e);}}
 private String submitJenkins(Prepare r){
  // Only URL-encode allowlisted single Jenkins job name; no arbitrary Jenkins paths or commands.
  String job=URLEncoder.encode(r.jenkinsJob(),StandardCharsets.UTF_8);
  String base=profiles.base("jenkins").replaceAll("/$","");if(!base.startsWith("https://"))throw new IllegalStateException("Jenkins HTTPS required");
  String creds=connections.require("jenkins"); // Stored format: username:API-token
  if(!creds.contains(":"))throw new IllegalStateException("Jenkins Windows credential must be username:api-token");
  String basic="Basic "+Base64.getEncoder().encodeToString(creds.getBytes(StandardCharsets.UTF_8));
  String body="APPLICATION="+enc(r.application())+"&SUITE="+enc(r.suite())+"&ENVIRONMENT="+enc(r.environment())+"&REVISION="+enc(r.revision())+"&TARGETS="+enc(String.join(",",r.targets()))+"&PARALLEL="+r.parallel();
  // Jenkins API token generally exempts crumb requirement; server policy may still require a crumb.
  try{HttpRequest req=HttpRequest.newBuilder(URI.create(base+"/job/"+job+"/buildWithParameters")).header("Authorization",basic).header("Content-Type","application/x-www-form-urlencoded").timeout(Duration.ofSeconds(20)).POST(HttpRequest.BodyPublishers.ofString(body)).build();HttpResponse<String> response=client.send(req,HttpResponse.BodyHandlers.ofString());if(response.statusCode()!=201&&response.statusCode()!=200&&response.statusCode()!=302)throw new IllegalStateException("Jenkins refused trigger: HTTP "+response.statusCode());String location=response.headers().firstValue("Location").orElse("");return location.startsWith(base+"/")?location:base+"/job/"+job+"/";}
  catch(Exception ex){throw new IllegalStateException("Jenkins submission failed; check Jenkins queue before retrying: "+ex.getClass().getSimpleName(),ex);}
 }
 private String enc(String s){return URLEncoder.encode(s,StandardCharsets.UTF_8);}private boolean safe(String s){return s!=null&&s.matches("[A-Za-z0-9_-]{1,80}");}
 private String sha(String s){try{byte[] h=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));return HexFormat.of().formatHex(h);}catch(Exception e){throw new IllegalStateException(e);}}
}
