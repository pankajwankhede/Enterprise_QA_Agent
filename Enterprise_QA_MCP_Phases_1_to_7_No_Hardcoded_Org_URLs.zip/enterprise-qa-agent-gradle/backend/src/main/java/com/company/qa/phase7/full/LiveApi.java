package com.company.qa.phase7.full;

import java.util.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/v1/phase7/live")
public class LiveApi {
 private final JenkinsMonitor jenkins;private final SourceApprovals approvals;private final FrameworkDiscovery discovery;private final ExecutionWorkflows executions;private final FrameworkScaffolder scaffolder;
 public LiveApi(SourceApprovals a,FrameworkDiscovery d,ExecutionWorkflows e, FrameworkScaffolder s,JenkinsMonitor j){jenkins=j;approvals=a;discovery=d;executions=e;scaffolder=s;}
 @GetMapping("/jenkins/{job}/latest") public com.fasterxml.jackson.databind.JsonNode latest(@PathVariable String job){return jenkins.latest(job);}
 @GetMapping("/jenkins/{job}/builds/{number}") public com.fasterxml.jackson.databind.JsonNode build(@PathVariable String job,@PathVariable int number){return jenkins.build(job,number);}
 @PostMapping("/sources/approve") public SourceApprovals.Decision approve(@RequestBody SourceApprovals.Request r){return approvals.approve(r);}
 @GetMapping("/sources/{task}") public List<SourceApprovals.Decision> sources(@PathVariable String task){return approvals.list(task);}
 @PostMapping("/frameworks/local") public FrameworkDiscovery.Profile local(@RequestBody LocalScan r){return discovery.scanLocal(r.task(),r.path());}
 @PostMapping("/frameworks/bitbucket") public FrameworkDiscovery.Profile bitbucket(@RequestBody RepoScan r){return discovery.scanBitbucket(r.task(),r.project(),r.repo(),r.revision());}
 @PostMapping("/frameworks/scaffold") public FrameworkScaffolder.ScaffoldResult scaffold(@RequestBody FrameworkScaffolder.ScaffoldRequest r){return scaffolder.scaffold(r);}
 @PostMapping("/executions/prepare") public ExecutionWorkflows.Plan plan(@RequestBody ExecutionWorkflows.Prepare r){return executions.prepare(r);}
 @PostMapping("/executions/approve") public ExecutionWorkflows.Plan run(@RequestBody ExecutionWorkflows.Decision r){return executions.approveAndLaunch(r);}
 @PostMapping("/executions/{id}/reject") public ExecutionWorkflows.Plan reject(@PathVariable String id){return executions.reject(id);}
 @GetMapping("/executions/{id}") public ExecutionWorkflows.Plan status(@PathVariable String id){return executions.read(id);}
 public record LocalScan(String task,String path){}public record RepoScan(String task,String project,String repo,String revision){}
 @ExceptionHandler({IllegalArgumentException.class,IllegalStateException.class}) public ResponseEntity<Map<String,String>> error(RuntimeException e){return ResponseEntity.badRequest().body(Map.of("error",e.getMessage()==null?"Operation failed":e.getMessage()));}
}
