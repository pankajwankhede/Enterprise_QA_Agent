package com.company.qa.phase7.full;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import org.springframework.stereotype.Service;
@Service
public class SourceApprovals {
 public record Request(String task,String source,String mode,String location,String statement){}
 public record Decision(String task,String source,String mode,String location,String statement,String scopeId,long approvedAt){}
 private final Path directory=Path.of(System.getProperty("user.home"),".enterprise-qa-mcp","approvals");
 private final ObjectMapper mapper=new ObjectMapper();
 private static final Set<String> SOURCES=Set.of("jira","confluence","bitbucket","framework","swagger","tdm","qaApi","database","qaInput");
 private static final Set<String> MODES=Set.of("MANUAL","CONNECT","SKIP");
 public synchronized Decision approve(Request r){
  if(r==null||!safe(r.task())||!SOURCES.contains(r.source())||!MODES.contains(r.mode()))throw new IllegalArgumentException("Invalid task/source/mode");
  String loc=Objects.toString(r.location(),"").trim();String st=Objects.toString(r.statement(),"").trim();
  if(loc.length()>1024||st.length()>10000)throw new IllegalArgumentException("Oversized input");
  if(r.mode().equals("CONNECT")&&loc.isBlank())throw new IllegalArgumentException("Source location required");
  if(r.mode().equals("MANUAL")&&st.isBlank())throw new IllegalArgumentException("Manual requirements required");
  if(r.mode().equals("CONNECT"))validateLocation(r.source(),loc);
  var d=new Decision(r.task(),r.source(),r.mode(),loc,st,UUID.randomUUID().toString(),Instant.now().getEpochSecond());
  try {Files.createDirectories(directory);Path dest=directory.resolve(r.task()+"__"+r.source()+".json");Path tmp=Files.createTempFile(directory,"approval-",".tmp");Files.writeString(tmp,mapper.writeValueAsString(d));try{Files.move(tmp,dest,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException ex){Files.move(tmp,dest,StandardCopyOption.REPLACE_EXISTING);}return d;}
  catch(Exception ex){throw new IllegalStateException("Cannot persist local approval",ex);}
 }
 public synchronized Optional<Decision> get(String task,String source){if(!safe(task)||!SOURCES.contains(source))throw new IllegalArgumentException("Invalid task or source");try{Path f=directory.resolve(task+"__"+source+".json");return Files.exists(f)?Optional.of(mapper.readValue(f.toFile(),Decision.class)):Optional.empty();}catch(Exception ex){throw new IllegalStateException("Cannot load approval",ex);}}
 public List<Decision> list(String task){if(!safe(task))throw new IllegalArgumentException("Invalid task");return SOURCES.stream().map(s->get(task,s)).flatMap(Optional::stream).sorted(Comparator.comparing(Decision::source)).toList();}
 public Decision require(String task,String source,String exactLocation){Decision d=get(task,source).orElseThrow(()->new IllegalStateException("APPROVAL_REQUIRED: "+source));if(!d.mode().equals("CONNECT")||!d.location().equals(exactLocation))throw new IllegalStateException("Scope not approved");if(Instant.now().getEpochSecond()-d.approvedAt()>3600)throw new IllegalStateException("Approval expired (1 hour)");return d;}
 private boolean safe(String v){return v!=null&&v.matches("[A-Za-z0-9_-]{1,64}");}
 private void validateLocation(String source,String loc){
   if(source.equals("framework")){if(!java.nio.file.Path.of(loc).isAbsolute())throw new IllegalArgumentException("Absolute working directory required");return;}
   if(source.equals("database")){if(!loc.matches("[A-Za-z0-9_-]{2,60}"))throw new IllegalArgumentException("Configured datasource alias required");return;}
   try{java.net.URI u=java.net.URI.create(loc);if(!"https".equalsIgnoreCase(u.getScheme())||u.getUserInfo()!=null||u.getHost()==null||u.getFragment()!=null)throw new IllegalArgumentException("Approved HTTPS URL required");}
   catch(IllegalArgumentException e){throw new IllegalArgumentException("Invalid approved source URL",e);}
 }
}
