package com.company.qa.phase7.full;

import java.awt.Desktop;
import java.net.*;
import java.io.File;
import java.nio.file.*;
import java.util.*;
import org.springframework.stereotype.Service;

/** Launch browser portal only on a user-initiated MCP connection request. */
@Service
public class ConnectionBrowserLauncher {
 public String ensurePortal(){
  if(listening())return "The local portal is already running; open its existing authenticated browser tab and select On-demand Connections.";
  try{
    String jar=System.getProperty("java.class.path","");
    if(!jar.toLowerCase(Locale.ROOT).endsWith(".jar")||!Files.isRegularFile(Path.of(jar)))
      return "Launch the local portal using the installed application shortcut or scripts/run-local-portal.cmd (macOS: scripts/run-local-portal-macos.sh).";
    String java=Path.of(System.getProperty("java.home"),"bin",isWindows()?"java.exe":"java").toString();
    ProcessBuilder builder=new ProcessBuilder(java,"-jar",Path.of(jar).toAbsolutePath().toString(),"--spring.profiles.active=portal");
    builder.redirectOutput(ProcessBuilder.Redirect.DISCARD).redirectError(ProcessBuilder.Redirect.DISCARD);
    builder.start();
    return "The local browser portal is starting; its own authenticated browser tab should open. Select On-demand Connections.";
  }catch(Exception ex){return "The portal could not start automatically. Launch the installed Enterprise QA portal shortcut and use On-demand Connections.";}
 }
 private boolean isWindows(){return System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");}
 private boolean listening(){try(java.net.Socket sock=new java.net.Socket()){
   sock.connect(new InetSocketAddress("127.0.0.1",8765),400);return true;
 }catch(Exception e){return false;}}
}
