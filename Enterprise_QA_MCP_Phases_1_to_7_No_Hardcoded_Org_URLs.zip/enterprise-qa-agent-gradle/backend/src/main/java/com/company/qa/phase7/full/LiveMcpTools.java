package com.company.qa.phase7.full;
import org.springframework.ai.mcp.annotation.McpTool;
import org.springframework.stereotype.Component;
/** MCP reads require a prior local React source authorization for the exact task and location. */
@Component public class LiveMcpTools {
 private final FrameworkDiscovery discovery;private final SourceApprovals approvals;
 public LiveMcpTools(FrameworkDiscovery d,SourceApprovals a){discovery=d;approvals=a;}
 @McpTool(name="qa_phase7_discover_approved_bitbucket_framework",description="Read a specifically approved Bitbucket Data Center repo and classify framework from repository files. QA must first approve the exact repository URL in local portal.")
 public String bitbucket(String task,String project,String repo,String revision){return discovery.scanBitbucket(task,project,repo,revision).toString();}
 @McpTool(name="qa_phase7_list_source_approvals",description="List current task-scoped source decisions. Never grants or escalates permission.")
 public String sources(String task){return approvals.list(task).stream().map(d->d.source()+" "+d.mode()+" approvedAt="+d.approvedAt()).toList().toString();}
}
