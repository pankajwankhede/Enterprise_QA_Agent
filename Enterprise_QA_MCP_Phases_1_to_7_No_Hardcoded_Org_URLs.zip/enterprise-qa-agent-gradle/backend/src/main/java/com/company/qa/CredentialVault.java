package com.company.qa;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.springframework.stereotype.Component;
/** Per-user OS vault. No filesystem or JVM settings are used to persist secrets. */
@Component
public class CredentialVault {
 private final WindowsCredentials windows;private final MacKeychainCredentials macKeychain;
 public CredentialVault(WindowsCredentials windows,MacKeychainCredentials macKeychain){this.windows=windows;this.macKeychain=macKeychain;}
 private boolean win(){return System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");}
 private boolean mac(){return System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("mac");}
 private String service(String key){if(key==null||!key.matches("[a-z0-9-]{2,45}"))throw new IllegalArgumentException("Invalid credential name");return "EnterpriseQA-MCP/"+key;}
 public void save(String key,String secret){
  service(key);if(secret==null||secret.isBlank()||secret.length()>8192)throw new IllegalArgumentException("Invalid credential");
  if(win()){windows.save(key,secret);return;}
  if(!mac())throw new IllegalStateException("OS vault unsupported on this platform");
  // macOS security utility reads secret from stdin: do not pass it in command line arguments.
  macKeychain.save(key,secret);
 }
 public Optional<String> read(String key){
  service(key);if(win())return windows.read(key);
  if(!mac())throw new IllegalStateException("OS vault unsupported on this platform");
  return macKeychain.read(key);
 }
 public void delete(String key){
  service(key);if(win()){windows.delete(key);return;}
  if(!mac())throw new IllegalStateException("OS vault unsupported on this platform");
  macKeychain.delete(key);
 }
}
