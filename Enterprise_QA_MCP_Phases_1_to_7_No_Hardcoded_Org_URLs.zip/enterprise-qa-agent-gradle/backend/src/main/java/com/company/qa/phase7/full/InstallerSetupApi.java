package com.company.qa.phase7.full;

import com.company.qa.CredentialVault;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.nio.file.*;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

/** Nonsecret build-profile configuration for the optional local automation-build configuration. */
@RestController
@RequestMapping("/api/v1/phase7/live/installer")
public class InstallerSetupApi {
  private final ObjectMapper json = new ObjectMapper();
  private final CredentialVault vault;
  private final Path file = Path.of(System.getProperty("user.home"),".enterprise-qa-mcp","installer-build-profile.json");
  private static final Set<String> KEYS=Set.of("location","javaMode","javaExe","nodeMode","nodeExe","execution","npmrc","reactPath","npmInstall","npmBuild","gradleMode","gradlePath","nexusUrl","nexusUsername","additionalVariables","createShortcut");
  private static final Set<String> NPM_KEYS=Set.of("registry","proxy","https-proxy","cafile","strict-ssl","fetch-retries","fetch-timeout","cache","audit","fund","always-auth","fetch-retry-mintimeout","fetch-retry-maxtimeout");
  public InstallerSetupApi(CredentialVault vault){this.vault=vault;}
  @GetMapping("/profile") public Map<String,Object> read(){
    try {if(!Files.exists(file)) return Map.of("profile",Map.of());
      return Map.of("profile",json.readValue(file.toFile(),Map.class));
    } catch(Exception e){throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,"Cannot read profile");}
  }
  @PutMapping("/profile") public Map<String,String> save(@RequestBody Map<String,Object> incoming){
    if(incoming.size()>KEYS.size()||!KEYS.containsAll(incoming.keySet()))throw bad("Unknown configuration fields");
    Map<String,Object> safe=new LinkedHashMap<>();
    for(var kv:incoming.entrySet()){
      if(!(kv.getValue() instanceof String)&&!(kv.getValue() instanceof Boolean))throw bad("Invalid field type");
      if(kv.getValue() instanceof String s && (s.length()>16384 || (s.length()>2048&&!kv.getKey().equals("npmrc"))))throw bad("Field too large");
      safe.put(kv.getKey(),kv.getValue());
    }
    String url=Objects.toString(safe.getOrDefault("nexusUrl",""),"");
    if(!url.isBlank())validateUrl(url);
    String npm=Objects.toString(safe.getOrDefault("npmrc",""),"");validateNpm(npm);
    for(String field:List.of("javaExe","nodeExe","reactPath","gradlePath","location","npmInstall","npmBuild","additionalVariables","nexusUsername")){
      String s=Objects.toString(safe.getOrDefault(field,""),"");
      if(s.matches("(?is).*?(?:_authToken|secret|password|bearer\\s+|-----BEGIN PRIVATE KEY-----).*"))throw bad("Secret-like data in "+field);
    }
    try{Files.createDirectories(file.getParent());Path tmp=Files.createTempFile(file.getParent(),"build-profile-",".tmp");
      Files.writeString(tmp,json.writerWithDefaultPrettyPrinter().writeValueAsString(safe));
      try{Files.move(tmp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(tmp,file,StandardCopyOption.REPLACE_EXISTING);}
      return Map.of("status","SAVED","storage","LOCAL_PROFILE");
    }catch(Exception e){throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,"Unable to save profile");}
  }
  @PostMapping("/nexus-secret") public Map<String,String> secret(@RequestBody Map<String,String> form){
    if(!form.keySet().equals(Set.of("username","password")))throw bad("Expected username and password only");
    String username=form.get("username"),password=form.get("password");
    if(username==null||username.isBlank()||username.length()>150||password==null||password.isEmpty()||password.length()>2048)throw bad("Invalid Nexus credential");
    try{vault.save("nexus-password",password);return Map.of("status","STORED_IN_WINDOWS_CREDENTIAL_MANAGER");}
    catch(Exception ex){throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"Native credential enrollment unavailable for this platform");}
  }
  private static void validateUrl(String url){
    try{URI u=URI.create(url);if(!"https".equalsIgnoreCase(u.getScheme())||u.getHost()==null||u.getUserInfo()!=null||u.getFragment()!=null||u.getQuery()!=null)throw bad("HTTPS Nexus URL without inline secrets required");}
    catch(IllegalArgumentException ex){throw bad("Invalid Nexus URL");}
  }
  private static void validateNpm(String npm){
    if(npm.length()>16384)throw bad("npmrc too large");
    for(String line:npm.split("\\R")){
      String s=line.trim();if(s.isEmpty()||s.startsWith("#")||s.startsWith(";"))continue;
      int idx=s.indexOf('=');if(idx<1)throw bad("Invalid npmrc line");
      String key=s.substring(0,idx).trim(),value=s.substring(idx+1).trim();
      if(!(NPM_KEYS.contains(key)||key.matches("@[a-zA-Z0-9_.-]+:registry")))throw bad("Unsupported or sensitive npmrc key: "+key);
      if(value.matches("(?is).*?(?:_authToken|_password|password|secret|-----BEGIN|\\$\\{[^}]*?(?:TOKEN|PASSWORD)[^}]*?\\}).*"))throw bad("Secret-like npmrc value detected");
      if((key.equals("registry")||key.endsWith(":registry"))&&!value.startsWith("https://"))throw bad("HTTPS npm registry required");
      if(key.equals("strict-ssl")&&!value.equals("true"))throw bad("strict-ssl=true required");
      if((key.equals("proxy")||key.equals("https-proxy"))&&value.matches("(?i)https?://[^/@]+:[^/@]+@.*"))throw bad("Proxy URL contains embedded credentials");
    }
  }
  private static ResponseStatusException bad(String text){return new ResponseStatusException(HttpStatus.BAD_REQUEST,text);}
}
