package com.company.qa.phase7;
import java.util.*;
import org.springframework.stereotype.Service;
/** Demo catalog until per-team approved profiles are configured. */
@Service
public class Phase7Catalog {
  public List<Map<String,Object>> profiles(){return List.of(
    Map.of("id","business-center","label","Business Center","framework","UNVERIFIED","repository","NOT_CONFIGURED"),
    Map.of("id","payments","label","Payments","framework","UNVERIFIED","repository","NOT_CONFIGURED"),
    Map.of("id","customer-portal","label","Customer Portal","framework","UNVERIFIED","repository","NOT_CONFIGURED"));}
  public Map<String,Object> detect(List<String> paths){
    if(paths==null || paths.size()>300)throw new IllegalArgumentException("Provide at most 300 nonsecret relative filenames");
    var names=paths.stream().map(x->x.replace('\\','/').toLowerCase(Locale.ROOT)).toList();
    String framework=names.stream().anyMatch(x->x.endsWith("playwright.config.ts"))?"playwright":
      names.stream().anyMatch(x->x.endsWith("testng.xml"))?"selenium-testng-possible":
      names.stream().anyMatch(x->x.endsWith("cypress.config.ts"))?"cypress":
      names.stream().anyMatch(x->x.endsWith("wdio.conf.js"))?"webdriverio":"unknown";
    String build=names.stream().anyMatch(x->x.endsWith("pom.xml"))?"maven":
      names.stream().anyMatch(x->x.endsWith("build.gradle"))?"gradle":
      names.stream().anyMatch(x->x.endsWith("package.json"))?"npm":"unknown";
    return Map.of("frameworkHint",framework,"buildToolHint",build,"verified",false,"requiresRepositoryApproval",true);
  }
}
