package com.company.qa.phase7.full;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/v1/phase7/live/sauce")
public class SauceResultsApi{
 private final SauceResultsService service;
 public SauceResultsApi(SauceResultsService s){service=s;}
 @GetMapping("/{username}/jobs/{jobId}")
 public Map<String,Object> job(@PathVariable String username,@PathVariable String jobId){return service.job(username,jobId);}
}
