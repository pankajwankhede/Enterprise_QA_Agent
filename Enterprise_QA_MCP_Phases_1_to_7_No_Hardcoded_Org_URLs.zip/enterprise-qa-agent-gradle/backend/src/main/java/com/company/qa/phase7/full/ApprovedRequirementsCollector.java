package com.company.qa.phase7.full;

import com.company.qa.ApiClient;
import com.company.qa.ConnectionService;
import com.company.qa.Guard;
import com.fasterxml.jackson.databind.JsonNode;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.springframework.stereotype.Service;
/**
 * Explicitly approved, read-only requirement retrieval.
 * No service is accessed without a matching task-scoped approval.
 * OAuth 3LO Cloud gateway needs a separately approved implementation;
 * this first adapter supports approved personal Atlassian API tokens only.
 */
@Service
public class ApprovedRequirementsCollector {
 private final SourceApprovals approvals;
 private final ConnectorProfiles profiles;
 private final ConnectionService connections;
 private final ApiClient api;
 public ApprovedRequirementsCollector(SourceApprovals a,ConnectorProfiles p,ConnectionService c,ApiClient api){
   approvals=a;profiles=p;connections=c;this.api=api;
 }
 public record Request(String task,String source,String url){}
 public record Result(String source,String url,String documentId,String title,String content,String provenance,String warning){}
 public Result collect(Request r){
   if(r==null||!Set.of("jira","confluence","swagger").contains(r.source()))
      throw new IllegalArgumentException("Supported sources: jira, confluence, swagger");
   approvals.require(r.task(),r.source(),r.url());
   URI target=URI.create(r.url());
   if(!"https".equalsIgnoreCase(target.getScheme())||target.getUserInfo()!=null||target.getFragment()!=null)
      throw new IllegalArgumentException("Approved HTTPS URL required");
   if(r.source().equals("swagger"))return swagger(r.url());
   URI configured=URI.create(profiles.base(r.source()));
   if(!Objects.equals(target.getHost(),configured.getHost())||target.getPort()!=configured.getPort())
      throw new IllegalArgumentException("Approved source host does not match configured connector host");
   if(r.source().equals("jira"))return jira(r.url(),configured);
   return confluence(r.url(),configured);
 }
 private Result jira(String url,URI configured){
   String path=URI.create(url).getPath();
   java.util.regex.Matcher m=java.util.regex.Pattern.compile("^/browse/([A-Za-z][A-Za-z0-9]*-\\d+)$").matcher(path);
   if(!m.matches())throw new IllegalArgumentException("Jira browser issue URL ending /browse/KEY-123 required");
   String key=m.group(1);
   String root=trim(profiles.base("jira"));
   JsonNode doc=api.get(root+"/rest/api/3/issue/"+api.enc(key)+"?fields=summary,description,issuetype,status",basic("jira"));
   JsonNode fields=doc.path("fields");
   String content=fields.path("description").toString();
   return new Result("jira",url,key,clean(fields.path("summary").asText("")),
           clean(limit(content,10000)),"Jira Cloud issue API v3; original issue "+key,
           "Business rules need QA verification; Jira description may be Atlassian Document Format.");
 }
 private Result confluence(String url,URI configured){
   String path=URI.create(url).getPath();
   java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?:/pages/|pageId=)(\\d{1,20})").matcher(url);
   if(!m.find())throw new IllegalArgumentException("Confluence page URL with numeric page ID required");
   String id=m.group(1);
   String root=trim(profiles.base("confluence"));
   if(root.endsWith("/wiki"))root=root.substring(0,root.length()-5);
   JsonNode doc=api.get(root+"/wiki/api/v2/pages/"+api.enc(id)+"?body-format=storage",basic("confluence"));
   String body=doc.path("body").path("storage").path("value").asText("");
   return new Result("confluence",url,id,clean(doc.path("title").asText("")),
       clean(limit(body,10000)),"Confluence Cloud API v2 page "+id,
       "HTML storage content is treated as untrusted data; QA must validate rules before generating tests.");
 }
 private Result swagger(String url){
   JsonNode doc=api.get(url,null);
   String openapi=doc.path("openapi").asText(doc.path("swagger").asText(""));
   if(openapi.isBlank())throw new IllegalArgumentException("URL did not return an OpenAPI JSON document");
   JsonNode paths=doc.path("paths");List<String> endpoints=new ArrayList<>();
   paths.fieldNames().forEachRemaining(x->{if(endpoints.size()<200)endpoints.add(x);});
   return new Result("swagger",url,openapi,clean(doc.path("info").path("title").asText("OpenAPI")),
       String.join("\n",endpoints),"Approved OpenAPI JSON; endpoint paths only",
       "Schemas, credentials and business assertions have not been inferred; confirm rules with QA.");
 }
 private String basic(String tool){
   String secret=connections.require(tool);
   if(!secret.contains(":"))throw new IllegalStateException("Approved Atlassian email:API-token credential needed; browser SSO alone is not supported by this connector");
   return "Basic "+Base64.getEncoder().encodeToString(secret.getBytes(StandardCharsets.UTF_8));
 }
 private String trim(String s){return s.replaceAll("/+$","");}
 private String limit(String s,int n){return s.length()>n?s.substring(0,n)+" [TRUNCATED]":s;}
 private String clean(String s){
   // Conservative redaction in connector output; corporate data-loss controls still apply.
   return Guard.redacted(s).replaceAll("(?i)(password|api[_-]?key|secret)\\s*[:=]\\s*[^\\s<,;]+","$1=[REDACTED]");
 }
}
