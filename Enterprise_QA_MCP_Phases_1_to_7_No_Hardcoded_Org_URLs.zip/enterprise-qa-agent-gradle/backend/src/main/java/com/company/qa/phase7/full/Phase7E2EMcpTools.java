package com.company.qa.phase7.full;
import org.springframework.ai.mcp.annotation.McpTool;
import org.springframework.stereotype.Component;
@Component
public class Phase7E2EMcpTools {
 private final LocalAutomationRunner runner;
 private final ApprovedRequirementsCollector requirements;
 private final SauceResultsService sauce;
 public Phase7E2EMcpTools(LocalAutomationRunner r,ApprovedRequirementsCollector req,SauceResultsService s){
  runner=r;requirements=req;sauce=s;
 }
 @McpTool(name="qa_phase7_collect_approved_requirement",
  description="Read approved Jira/Confluence/OpenAPI requirement data for one task and exact source URL. Source must be approved separately in local React portal.")
 public String collect(String task,String source,String approvedUrl){
  return requirements.collect(new ApprovedRequirementsCollector.Request(task,source,approvedUrl)).toString();
 }
 @McpTool(name="qa_phase7_prepare_local_automation",
  description="Prepare a local framework execution without running it. QA must first approve exact framework directory. Actual execution requires React portal approval.")
 public String prepare(String task,String directory,String framework,String suite,String environment,
                       String browser,int parallel,boolean useSauce){
  return runner.prepare(new LocalAutomationRunner.Request(task,directory,framework,suite,environment,
          java.util.List.of(browser),parallel,useSauce)).toString();
 }
 @McpTool(name="qa_phase7_local_execution_status",
  description="Read the state of a previously approved local test execution.")
 public String status(String executionId){return runner.read(executionId).toString();}
 @McpTool(name="qa_phase7_sauce_job_summary",
  description="Fetch authorized Sauce Labs job metadata and available artifact links, not inferred root cause.")
 public String sauce(String account,String jobId){return sauce.job(account,jobId).toString();}
}
