package com.company.qa.phase7;
import java.util.*;
import java.util.concurrent.*;
import org.springframework.stereotype.Service;
/** In-memory DEMO approvals only. Does not authorize external collection or Jenkins actions. */
@Service
public class Phase7ApprovalService {
 public record SourceDecision(String taskId,String source,String mode,String location,String reason,String state){}
 private final ConcurrentMap<String,SourceDecision> decisions=new ConcurrentHashMap<>();
 private static final Set<String> MODES=Set.of("MANUAL","CONNECT","SKIP");
 private static final Set<String> SOURCES=Set.of("jira","confluence","bitbucket","framework","swagger","tdm","qaApi","database","qaInput");
 public SourceDecision decide(String taskId,String source,String mode,String location,String reason){
  if(!valid(taskId)||!SOURCES.contains(source)||!MODES.contains(mode))throw new IllegalArgumentException("Invalid task/source/mode");
  if(location!=null && location.length()>800)throw new IllegalArgumentException("Location too long");
  if(reason!=null && reason.length()>300)throw new IllegalArgumentException("Reason too long");
  String status="SKIP".equals(mode)?"SKIPPED":"RECORDED_NOT_AUTHORIZED";
  var d=new SourceDecision(taskId,source,mode,location==null?"":location,reason==null?"":reason,status);
  decisions.put(taskId+":"+source,d);return d;
 }
 public List<SourceDecision> list(String taskId){if(!valid(taskId))throw new IllegalArgumentException("Invalid task");return decisions.values().stream().filter(d->d.taskId().equals(taskId)).sorted(Comparator.comparing(SourceDecision::source)).toList();}
 private boolean valid(String value){return value!=null && value.matches("[A-Za-z0-9_-]{1,60}");}
}
