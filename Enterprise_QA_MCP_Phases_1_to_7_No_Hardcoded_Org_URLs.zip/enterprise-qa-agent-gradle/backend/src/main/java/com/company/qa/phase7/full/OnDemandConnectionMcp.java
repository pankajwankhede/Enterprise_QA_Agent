package com.company.qa.phase7.full;

import org.springframework.stereotype.Component;
import org.springframework.ai.mcp.annotation.McpTool;
/** MCP never sees secrets. Only safe read-only actions are resumed after enrollment. */
@Component public class OnDemandConnectionMcp {
 private final OnDemandConnections flow;private final ConnectionBrowserLauncher launcher;
 public OnDemandConnectionMcp(OnDemandConnections flow,ConnectionBrowserLauncher launcher){this.flow=flow;this.launcher=launcher;}
 @McpTool(name="qa_connect_when_needed",description="Start an approved tool connection setup request. Read-only replay is available only for sauce_job and octane_defect_search; leave operation empty for other connectors. Never supply a token, password or browser cookie.")
 public String connect(String tool,String operation,String argument){
  var job=flow.request(tool,operation,argument);
  String browser=launcher.ensurePortal();
  return "CONNECTION_REQUIRED: "+tool+". Request ID: "+job.id()+". Launch Enterprise QA Portal on this laptop and open Live Phase 7 > On-demand Connections; complete approved API credential enrollment. Then call qa_connection_resume with request ID "+job.id()+". "+browser+" Do not paste secrets in Copilot.";
 }
 @McpTool(name="qa_connection_resume",description="Read a pending on-demand connection and result after the user completes secure local browser authorization. Does not access credentials or submit writes.")
 public String resume(String requestId){
  var j=flow.get(requestId);
  return "State="+j.status()+"; connector="+j.tool()+"; message="+j.message()+"; result="+j.result();
 }
}
