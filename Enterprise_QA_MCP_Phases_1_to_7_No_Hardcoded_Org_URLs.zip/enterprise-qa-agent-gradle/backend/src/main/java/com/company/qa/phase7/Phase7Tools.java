package com.company.qa.phase7;
import java.util.*;
import org.springframework.ai.mcp.annotation.McpTool;
import org.springframework.stereotype.Component;
/** Pure proposal/read-only MCP tools; never execute external commands. */
@Component
public class Phase7Tools {
 private final Phase7Catalog catalog;
 public Phase7Tools(Phase7Catalog c){this.catalog=c;}
 @McpTool(name="qa_phase7_list_example_teams",description="Return example team profiles. Examples are not real discoveries.")
 public String listTeams(){return catalog.profiles().toString();}
 @McpTool(name="qa_phase7_detect_framework_from_filenames",description="Infer possible test framework from manually supplied nonsecret relative filenames. Does not access Bitbucket or the filesystem.")
 public String detect(String commaSeparatedRelativeFilenames){if(commaSeparatedRelativeFilenames==null||commaSeparatedRelativeFilenames.length()>5000)throw new IllegalArgumentException("Invalid filenames");return catalog.detect(Arrays.asList(commaSeparatedRelativeFilenames.split(","))).toString();}
 @McpTool(name="qa_phase7_prepare_execution_preview",description="Draft a non-executable QA run plan. Requires separate authorization before any real Jenkins/Sauce Labs invocation.")
 public String plan(String application,String suite,String environment,String targets,int parallel){
  if(!application.matches("[a-zA-Z0-9_-]{1,80}")||!Set.of("smoke","regression","e2e").contains(suite)||!Set.of("qa","staging").contains(environment)||parallel<1||parallel>12||targets==null||targets.length()>200)throw new IllegalArgumentException("Invalid plan input");
  return "PREVIEW ONLY: application="+application+"; suite="+suite+"; environment="+environment+"; targets="+targets+"; parallel="+parallel+". NOT APPROVED, NOT EXECUTED. Verify Sauce Labs capabilities, Jenkins job, revision and quota before use.";
 }
}
