package com.company.qa.phase7.full;

import com.company.qa.ConnectionService;
import com.company.qa.ApiClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.awt.Desktop;
import java.net.URI;
import java.net.http.*;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import org.springframework.stereotype.Service;

/**
 * Cross-process, durable, nonsecret queue: MCP process may differ from browser portal.
 * Stores only strict operation identifiers, approved query identifiers and sanitized results.
 * Status polling is explicit, and no write action can be queued for automatic replay.
 */
@Service
public class OnDemandConnections {
 public record Job(String id,String tool,String operation,String argument,String status,long createdAt,
                   String message,String result) {}
 public record Created(String id,String status,String instruction){}
 private final Path home=Path.of(System.getProperty("user.home"),".enterprise-qa-mcp","pending-connections");
 private final ObjectMapper json=new ObjectMapper();
 private final ConnectionService credentials;private final ConnectorProfiles profiles;private final ApiClient api;
 private static final Set<String> TOOLS=Set.of("sauce","octane","splunk","bitbucket","jira","confluence","jenkins");
 private static final Set<String> READS=Set.of("sauce_job","octane_defect_search");
 public OnDemandConnections(ConnectionService c,ConnectorProfiles p,ApiClient a){credentials=c;profiles=p;api=a;}
 public synchronized Created request(String tool,String operation,String argument){
   if(!TOOLS.contains(tool))throw new IllegalArgumentException("Unsupported connector");
   if(operation!=null&&!operation.isBlank()&&!READS.contains(operation))throw new IllegalArgumentException("Unapproved automatic replay operation");
   String arg=Objects.toString(argument,"").trim();
   if(arg.length()>300||arg.matches("(?is).*(?:token|password|authorization|secret)=.*"))throw new IllegalArgumentException("Invalid request argument");
   if("sauce_job".equals(operation)&&(!"sauce".equals(tool)||!arg.matches("[A-Za-z0-9_.-]{1,80}:[A-Za-z0-9_-]{1,120}")))throw new IllegalArgumentException("Expected account:jobId");
   if("octane_defect_search".equals(operation)&&(!"octane".equals(tool)||!arg.matches("[A-Za-z0-9_. -]{1,80}")))throw new IllegalArgumentException("Invalid Octane search term");
   // A tool connection may already exist; read-only work still requires live authorization.
   String id=UUID.randomUUID().toString();
   Job job=new Job(id,tool,Objects.toString(operation,""),arg,"WAITING_FOR_CONNECTION",
                   Instant.now().getEpochSecond(),"Finish the organization's approved API connection setup in the local browser","");
   write(job);
   return new Created(id,job.status(),"Open the local Enterprise QA portal. The connection request is waiting for "+tool+". After connection, poll qa_connection_resume with this request ID.");
 }
 public synchronized Job get(String id){
   if(id==null||!id.matches("[a-f0-9-]{36}"))throw new IllegalArgumentException("Invalid connection request ID");
   try {Path file=home.resolve(id+".json");Job j=json.readValue(file.toFile(),Job.class);
     if(Instant.now().getEpochSecond()-j.createdAt()>1800&&!Set.of("COMPLETE","FAILED","CANCELED").contains(j.status())){
       j=new Job(j.id(),j.tool(),j.operation(),j.argument(),"EXPIRED",j.createdAt(),"Request expired. Start a new connection attempt.","");write(j);
     }return j;
   }catch(Exception e){throw new IllegalArgumentException("Unknown or expired connection request",e);}
 }
 public synchronized List<Job> pending(){
   if(!Files.isDirectory(home))return List.of();
   try(var list=Files.list(home)){
     return list.filter(x->x.getFileName().toString().matches("[a-f0-9-]{36}\\.json"))
       .limit(100).map(x->{try{return get(x.getFileName().toString().substring(0,36));}catch(Exception e){return null;}})
       .filter(Objects::nonNull).filter(x->x.status().equals("WAITING_FOR_CONNECTION")).toList();
   }catch(Exception e){return List.of();}
 }
 public synchronized Job complete(String id){
   Job j=get(id);
   if(!j.status().equals("WAITING_FOR_CONNECTION"))throw new IllegalStateException("Request not waiting");
   if(!credentials.status(j.tool()).startsWith("CONFIGURED"))throw new IllegalStateException("Connection missing");
   try{
     String result=executeRead(j);
     Job completed=new Job(j.id(),j.tool(),j.operation(),j.argument(),"COMPLETE",j.createdAt(),
                           "Connected. Pending read-only action completed.",result);
     write(completed);return completed;
   }catch(Exception ex){
     Job failed=new Job(j.id(),j.tool(),j.operation(),j.argument(),"FAILED",j.createdAt(),
                       "Connection saved but operation could not complete: "+ex.getClass().getSimpleName(),"");
     write(failed);return failed;
   }
 }
 public synchronized Job cancel(String id){Job j=get(id);if(!j.status().equals("WAITING_FOR_CONNECTION"))throw new IllegalStateException("Cannot cancel");Job canceled=new Job(j.id(),j.tool(),j.operation(),j.argument(),"CANCELED",j.createdAt(),"Canceled","");write(canceled);return canceled;}
 private String executeRead(Job j){
   if(j.operation().isBlank()){
     validateRemote(j.tool());
     return "API connection validated. Repeat the original Copilot command for any operation that is not explicitly replayable.";
   }
   if(j.operation().equals("sauce_job")){
     int separator=j.argument().indexOf(':');String account=j.argument().substring(0,separator),id=j.argument().substring(separator+1);
     String secret=credentials.require("sauce");String auth="Basic "+Base64.getEncoder().encodeToString(secret.getBytes(java.nio.charset.StandardCharsets.UTF_8));
     String url=profiles.base("sauce").replaceAll("/+$","")+"/rest/v1/"+api.enc(account)+"/jobs/"+api.enc(id);
     JsonNode doc=api.get(url,auth);
     return json.createObjectNode().put("jobId",id).put("status",doc.path("status").asText("UNKNOWN"))
         .put("passed",doc.path("passed").asText("UNKNOWN"))
         .put("error",doc.path("error").asText("")).toString();
   }
   if(j.operation().equals("octane_defect_search")){
     var profile=profiles.get("octane").orElseThrow(()->new IllegalStateException("Octane profile missing"));
     String shared=Objects.toString(profile.project(),""),workspace=Objects.toString(profile.workspace(),"");
     if(!shared.matches("[0-9]{1,20}")||!workspace.matches("[0-9]{1,20}"))throw new IllegalStateException("Octane shared space / workspace missing");
     String path="/api/shared_spaces/"+shared+"/workspaces/"+workspace+"/defects?limit=10&query="+
        api.enc("name EQ '^"+j.argument()+"^'");
     JsonNode data=api.get(profiles.base("octane").replaceAll("/+$","")+path,"Bearer "+credentials.require("octane"));
     return "Octane search completed; returned "+data.path("total_count").asText("unknown")+" matches. Use approved Octane read tools to inspect sanitized defects.";
   }
   throw new IllegalStateException("Operation not allowlisted");
 }
 private void validateRemote(String tool){
   String base=profiles.base(tool).replaceAll("/+$","");
   String credential=credentials.require(tool);
   String auth="Bearer "+credential;
   String url;
   switch(tool){
     case "sauce" -> {
       int sep=credential.indexOf(':');
       if(sep<=0)throw new IllegalStateException("Sauce requires authorized username:access-key");
       String account=credential.substring(0,sep);
       auth="Basic "+Base64.getEncoder().encodeToString(credential.getBytes(java.nio.charset.StandardCharsets.UTF_8));
       url=base+"/rest/v1/users/"+api.enc(account);
     }
     case "bitbucket" -> url=base+"/rest/api/1.0/projects?limit=1";
     case "jira" -> {
       if(!credential.contains(":"))throw new IllegalStateException("Approved Atlassian email:API-token required");
       auth="Basic "+Base64.getEncoder().encodeToString(credential.getBytes(java.nio.charset.StandardCharsets.UTF_8));
       url=base+"/rest/api/3/myself";
     }
     case "confluence" -> {
       if(!credential.contains(":"))throw new IllegalStateException("Approved Atlassian email:API-token required");
       auth="Basic "+Base64.getEncoder().encodeToString(credential.getBytes(java.nio.charset.StandardCharsets.UTF_8));
       url=base.replaceAll("/wiki$","")+"/wiki/api/v2/spaces?limit=1";
     }
     case "octane" -> {
       var endpoint=profiles.get("octane").orElseThrow();
       if(!Objects.toString(endpoint.project(),"").matches("[0-9]{1,20}") ||
          !Objects.toString(endpoint.workspace(),"").matches("[0-9]{1,20}"))throw new IllegalStateException("Octane shared space and workspace needed");
       url=base+"/api/shared_spaces/"+endpoint.project()+"/workspaces/"+endpoint.workspace()+"/defects?limit=1";
     }
     case "jenkins" -> {
       if(!credential.contains(":"))throw new IllegalStateException("Jenkins user:API-token required");
       auth="Basic "+Base64.getEncoder().encodeToString(credential.getBytes(java.nio.charset.StandardCharsets.UTF_8));
       url=base+"/api/json";
     }
     case "splunk" -> url=base+"/services/server/info?output_mode=json";
     default -> throw new IllegalArgumentException("Unsupported tool validation");
   }
   api.get(url,auth); // requires an actual 2xx HTTPS API response
 }
 private void write(Job j){
   try{Files.createDirectories(home);
     Path tmp=Files.createTempFile(home,"request-",".tmp");Files.writeString(tmp,json.writeValueAsString(j));
     try{Files.move(tmp,home.resolve(j.id()+".json"),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
     catch(AtomicMoveNotSupportedException e){Files.move(tmp,home.resolve(j.id()+".json"),StandardCopyOption.REPLACE_EXISTING);}
   }catch(Exception e){throw new IllegalStateException("Cannot save connection request",e);}
 }
}
