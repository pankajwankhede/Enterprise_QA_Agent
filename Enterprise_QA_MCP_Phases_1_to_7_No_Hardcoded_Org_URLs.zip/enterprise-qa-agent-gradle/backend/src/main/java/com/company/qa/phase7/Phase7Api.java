package com.company.qa.phase7;
import java.util.*;
import org.springframework.web.bind.annotation.*;
/** Read-only informational portal endpoints. No credential, approval or runner mutations. */
@RestController
@RequestMapping("/api/v1/phase7")
public class Phase7Api {
 private final Phase7Catalog catalog;
 public Phase7Api(Phase7Catalog c){catalog=c;}
 @GetMapping("/teams") public List<Map<String,Object>> teams(){return catalog.profiles();}
 @GetMapping("/status") public Map<String,Object> status(){return Map.of("mode","PHASE7_PREVIEW","externalCollectionEnabled",false,"jenkinsLaunchEnabled",false,"approvalExecutionEnabled",false);}
}
