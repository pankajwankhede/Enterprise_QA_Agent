package com.company.qa;
import java.util.*;
public final class Guard {
 private Guard(){}
 public static String id(String value){if(value==null||!value.matches("[A-Za-z0-9_.:-]{1,120}")) throw new IllegalArgumentException("Invalid identifier");return value;}
 public static String project(String value){if(value==null||!value.matches("[A-Za-z0-9_-]{1,70}"))throw new IllegalArgumentException("Invalid project");return value;}
 public static String redacted(String message){if(message==null)return "";String cleaned=message.replaceAll("(?i)(bearer|token|password|authorization)[ :=]+[^\\s,;]+","$1=[REDACTED]");
 return cleaned.substring(0,Math.min(cleaned.length(),500));}
}
