package com.company.qa.phase7.full;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/v1/phase7/live")
public class TestAndMatrixApi {
 private final TestCodeGeneration tests; private final SauceMatrixOrchestrator matrix;
 public TestAndMatrixApi(TestCodeGeneration tests,SauceMatrixOrchestrator matrix){this.tests=tests;this.matrix=matrix;}
 @PostMapping("/test-code/generate") public TestCodeGeneration.Draft generate(@RequestBody TestCodeGeneration.Request req){return tests.generate(req);}
 @GetMapping("/test-code/{id}") public TestCodeGeneration.Draft draft(@PathVariable String id){return tests.read(id);}
 @PostMapping("/test-code/approve") public TestCodeGeneration.Draft approveDraft(@RequestBody TestCodeGeneration.Approval req){return tests.approve(req);}
 @PostMapping("/sauce-matrix/prepare") public SauceMatrixOrchestrator.Plan prepare(@RequestBody SauceMatrixOrchestrator.Request req){return matrix.prepare(req);}
 @GetMapping("/sauce-matrix/{id}/challenge") public Map<String,String> challenge(@PathVariable String id){return Map.of("confirmation",matrix.challenge(id));}
 @PostMapping("/sauce-matrix/approve") public SauceMatrixOrchestrator.Plan approve(@RequestBody SauceMatrixOrchestrator.Approval req){return matrix.approve(req);}
 @PostMapping("/sauce-matrix/{id}/reject") public SauceMatrixOrchestrator.Plan reject(@PathVariable String id){return matrix.reject(id);}
 @GetMapping("/sauce-matrix/{id}") public SauceMatrixOrchestrator.Plan status(@PathVariable String id){return matrix.read(id);}
}
