package com.company.qa;
import com.sun.jna.*;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.win32.StdCallLibrary;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.springframework.stereotype.Component;
/** Per-user Windows Generic Credential. No plaintext secret files. */
@Component
public class WindowsCredentials {
 public interface Advapi extends StdCallLibrary {
  Advapi INSTANCE = Native.load("Advapi32", Advapi.class);
  boolean CredWriteW(Credential credential, int flags);
  boolean CredReadW(WString target, int type, int flags, PointerByReference out);
  boolean CredDeleteW(WString target, int type, int flags);
  void CredFree(Pointer pointer);
 }
 @Structure.FieldOrder({"Flags","Type","TargetName","Comment","LastWritten","CredentialBlobSize","CredentialBlob","Persist","AttributeCount","Attributes","TargetAlias","UserName"})
 public static class Credential extends Structure {
  public int Flags,Type; public WString TargetName, Comment; public long LastWritten; public int CredentialBlobSize;
  public Pointer CredentialBlob; public int Persist,AttributeCount; public Pointer Attributes; public WString TargetAlias,UserName;
  public Credential(){} public Credential(Pointer p){ super(p); read(); }
 }
 private void windows(){if(!System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win")) throw new IllegalStateException("Windows Credential Manager requires Windows");}
 private String target(String tool){ if(!tool.matches("[a-z0-9_-]{2,40}")) throw new IllegalArgumentException("Invalid tool"); return "CompanyQA-MCP/"+tool; }
 public void save(String tool,String value){
  windows();byte[] bytes=value.getBytes(StandardCharsets.UTF_16LE);Memory mem=new Memory(bytes.length);mem.write(0,bytes,0,bytes.length);
  try { Credential c=new Credential();c.Type=1;c.TargetName=new WString(target(tool));c.UserName=new WString(System.getProperty("user.name"));c.CredentialBlob=mem;c.CredentialBlobSize=bytes.length;c.Persist=2;c.write();if(!Advapi.INSTANCE.CredWriteW(c,0))throw new IllegalStateException("Windows credential write failed"); }
  finally {mem.clear();Arrays.fill(bytes,(byte)0);}
 }
 public Optional<String> read(String tool){
  windows();PointerByReference out=new PointerByReference();if(!Advapi.INSTANCE.CredReadW(new WString(target(tool)),1,0,out))return Optional.empty();
  try{Credential c=new Credential(out.getValue());if(c.CredentialBlobSize<=0||c.CredentialBlobSize>65536)throw new IllegalStateException("Invalid secret length");return Optional.of(new String(c.CredentialBlob.getByteArray(0,c.CredentialBlobSize),StandardCharsets.UTF_16LE));}
  finally{Advapi.INSTANCE.CredFree(out.getValue());}
 }
 public void delete(String tool){windows();Advapi.INSTANCE.CredDeleteW(new WString(target(tool)),1,0);}
}
