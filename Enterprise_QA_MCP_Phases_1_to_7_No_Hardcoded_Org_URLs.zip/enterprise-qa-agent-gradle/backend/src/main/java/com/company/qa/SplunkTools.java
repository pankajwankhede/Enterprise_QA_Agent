package com.company.qa;
import org.springframework.ai.mcp.annotation.McpTool;import org.springframework.stereotype.Component;
@Component
public class SplunkTools{
 private final ConnectionService conn;private final ApiClient api;private final com.company.qa.phase7.full.ConnectorProfiles profiles;private final com.company.qa.phase7.full.AutoConnectGate gate;
 
 public SplunkTools(ConnectionService c,ApiClient a,com.company.qa.phase7.full.ConnectorProfiles p,com.company.qa.phase7.full.AutoConnectGate gate){conn=c;api=a;profiles=p;this.gate=gate;}
 @McpTool(name="splunk_connection_status",description="Check configured Splunk connection")public String status(){return conn.status("splunk");}
 @McpTool(name="splunk_search_errors",description="Search approved QA Splunk index for a service name, read-only")
 public String errors(String service,int minutes){Guard.id(service);if(minutes<1||minutes>60)throw new IllegalArgumentException("Allowed range: 1-60 minutes");
  if(gate.missing("splunk"))return gate.connect("splunk","","");profiles.base("splunk");
  // REST search export uses form data; deliberately not enabled until approved endpoint and search permissions verified.
  return "INTEGRATION_PENDING: Splunk search endpoint configured, but query job adapter must be enabled after REST-access approval; no search performed";
 }
}
