package com.company.qa;
import java.io.*;import java.util.*;
/** Standalone utility; run locally in Windows terminal. Do not pass secrets as CLI arguments. */
public final class SetupCredentials {
 public static void main(String[] args)throws Exception {
  if(args.length!=2||!Set.of("save","delete","status").contains(args[0])||!Set.of("octane","sauce","splunk","bitbucket","jira","confluence","jenkins").contains(args[1])){
   System.err.println("Usage: SetupCredentials <save|delete|status> <octane|sauce|splunk|bitbucket|jira|confluence|jenkins>");System.exit(2); }
  WindowsCredentials wc=new WindowsCredentials();String action=args[0],tool=args[1];
  if(action.equals("status")){System.out.println(wc.read(tool).isPresent()?"CREDENTIAL_SAVED":"NOT_CONFIGURED");return;}
  if(action.equals("delete")){wc.delete(tool);System.out.println("Credential deleted locally");return;}
  Console console=System.console();if(console==null)throw new IllegalStateException("Run from interactive Windows terminal, not an IDE console");
  console.printf("Tool: %s. Only enter admin-approved API credential. Do not enter corporate password.%n",tool);
  if(tool.equals("jenkins"))console.printf("Enter value as username:API-token (not a password)%n");
  if(tool.equals("sauce"))console.printf("Enter value as username:accessKey (both are treated as a single protected secret)%n");
  char[] secret=console.readPassword("Credential (hidden): ");
  try{if(secret==null||secret.length==0)throw new IllegalArgumentException("No credential entered");wc.save(tool,new String(secret));console.printf("Saved in Windows Credential Manager. This does not validate remote access.%n");}
  finally{if(secret!=null)Arrays.fill(secret,'\0');}
 }
}
