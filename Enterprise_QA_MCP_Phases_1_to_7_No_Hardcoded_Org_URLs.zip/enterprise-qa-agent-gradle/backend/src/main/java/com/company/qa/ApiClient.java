package com.company.qa;
import org.springframework.stereotype.Component;
import java.net.*;import java.net.http.*;import java.time.Duration;import java.util.*;import com.fasterxml.jackson.databind.*;
@Component
public class ApiClient {
 private final HttpClient http=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).followRedirects(HttpClient.Redirect.NEVER).build();
 private final ObjectMapper mapper=new ObjectMapper();
 public JsonNode get(String url, String auth) {return send("GET",url,auth,null);}
 public JsonNode post(String url,String auth,String json){return send("POST",url,auth,json);}
 public JsonNode send(String method,String url,String auth,String body){
  try{URI uri=URI.create(url);if(!"https".equalsIgnoreCase(uri.getScheme())||uri.getUserInfo()!=null)throw new IllegalArgumentException("HTTPS required");
   HttpRequest.Builder b=HttpRequest.newBuilder(uri).timeout(Duration.ofSeconds(20)).header("Accept","application/json");
   if(auth!=null&&!auth.isBlank()) b.header("Authorization",auth);
   if(body!=null)b.header("Content-Type","application/json");
   HttpRequest request=b.method(method,body==null?HttpRequest.BodyPublishers.noBody():HttpRequest.BodyPublishers.ofString(body)).build();
   HttpResponse<String> response=http.send(request,HttpResponse.BodyHandlers.ofString());
   if(response.statusCode()<200||response.statusCode()>=300)throw new IllegalStateException("Remote API HTTP "+response.statusCode()+"; verify permissions / endpoint");
   String data=response.body(); if(data.length()>300000) throw new IllegalStateException("Result too large");
   return mapper.readTree(data.isBlank()?"{}":data);
  }catch(IllegalStateException e){throw e;}catch(Exception e){throw new IllegalStateException("API request failed: "+e.getClass().getSimpleName());}
 }
 public String enc(String v){return URLEncoder.encode(v,java.nio.charset.StandardCharsets.UTF_8);}
}
