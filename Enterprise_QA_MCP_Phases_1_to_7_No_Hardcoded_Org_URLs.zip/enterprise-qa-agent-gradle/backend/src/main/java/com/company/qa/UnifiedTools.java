package com.company.qa;
import org.springframework.ai.mcp.annotation.McpTool;import org.springframework.stereotype.Component;
@Component
public class UnifiedTools {
 private final SauceTools sauce;private final SplunkTools splunk;private final OctaneTools octane;
 public UnifiedTools(SauceTools s,SplunkTools p,OctaneTools o){sauce=s;splunk=p;octane=o;}
 @McpTool(name="qa_investigation_readiness",description="List available connectors for unified QA root-cause investigation")
 public String readiness(){return "Sauce="+sauce.status()+", Splunk="+splunk.status()+", Octane="+octane.status()+". Bitbucket/Jira/Confluence status via own tools.";}
 @McpTool(name="qa_classify_failure",description="Rule-based classification of a sanitized automation exception string")
 public String classify(String exception){String s=exception.toLowerCase();String type=s.contains("nosuchelement")?"POSSIBLE_LOCATOR_ISSUE":s.contains("staleelement")?"POSSIBLE_DOM_CHANGE":s.contains("assertion")?"ASSERTION_MISMATCH":s.contains("timeout")?"TIMEOUT_NEEDS_CORRELATION":s.contains("http 500")?"BACKEND_FAILURE_CANDIDATE":"INSUFFICIENT_EVIDENCE";return "classification="+type+"; source=heuristic; requires independent verification";}
}
