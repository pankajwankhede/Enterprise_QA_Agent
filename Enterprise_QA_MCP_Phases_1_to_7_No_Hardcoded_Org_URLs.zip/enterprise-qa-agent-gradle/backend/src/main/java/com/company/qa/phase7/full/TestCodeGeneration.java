package com.company.qa.phase7.full;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import org.springframework.stereotype.Service;

/** Generates reviewable tests from QA-verified, structured assertions. No autonomous LLM claim. */
@Service
public class TestCodeGeneration {
  public record Scenario(String name, String urlPath, String locator, String expectedText, String dataSourceId) {}
  public record Request(String task, String repository, String framework, String feature,
                        List<Scenario> scenarios, String requirementSource) {}
  public record Draft(String id, String task, String framework, String feature, String relativePath,
                      String content, String sha256, String status, String originalRepository,
                      int scenarios, long createdAt, String provenance, String baselineSha256, String changeType) {}
  public record Approval(String id, String checksum) {}
  private final SourceApprovals approvals;
  private final ObjectMapper mapper = new ObjectMapper();
  private final Path drafts=Path.of(System.getProperty("user.home"), ".enterprise-qa-mcp", "generated-tests");
  public TestCodeGeneration(SourceApprovals approvals){this.approvals=approvals;}
  public Draft generate(Request r){
    if(r==null || r.task()==null || !r.task().matches("[A-Za-z0-9_-]{1,64}") ||
      !Set.of("playwright-ts","selenium-junit-java").contains(r.framework()) ||
      r.scenarios()==null || r.scenarios().isEmpty() || r.scenarios().size()>40)
      throw new IllegalArgumentException("Invalid or unsupported test generation request");
    approvals.require(r.task(),"framework",r.repository());
    if(r.requirementSource()==null || !r.requirementSource().equals("qaInput"))
      throw new IllegalArgumentException("Only QA-reviewed manual requirements are accepted for deterministic generation; review imported Jira/Confluence rules first");
    SourceApprovals.Decision source=approvals.get(r.task(),"qaInput").orElseThrow(()->new IllegalStateException("QA manual requirements must be approved"));
    if(!source.mode().equals("MANUAL") || Instant.now().getEpochSecond()-source.approvedAt()>3600)
      throw new IllegalStateException("Manual requirements not approved or expired");
    Path repo=repository(r.repository());
    String feature=id(r.feature(),"feature");
    for(Scenario s:r.scenarios())validate(s);
    String path=r.framework().equals("playwright-ts")?"tests/generated/"+feature+".spec.ts":
       "src/test/java/generated/"+camel(feature)+"GeneratedTest.java";
    // A draft never modifies the source repository.
    String code=r.framework().equals("playwright-ts")?playwright(r.scenarios()):junit(feature,r.scenarios());
    Path destination=repo.resolve(path).normalize();
    String baseline="",change="ADD";
    try {
      if(Files.exists(destination)){
        if(!r.framework().equals("playwright-ts") || Files.isSymbolicLink(destination) || !Files.isRegularFile(destination) || Files.size(destination)>100000)
          throw new IllegalStateException("Existing file unsupported for deterministic append; ask Copilot for a reviewed patch instead");
        String old=Files.readString(destination,StandardCharsets.UTF_8);
        if(!old.contains("import { test, expect } from '@playwright/test';"))
          throw new IllegalStateException("Existing test is not a recognized Playwright generated file");
        for(Scenario scene:r.scenarios())if(old.contains("test('"+escape(scene.name())+"'"))
          throw new IllegalStateException("Test case already exists; request a Copilot-reviewed edit to replace existing behavior");
        baseline=sha(old); change="APPEND_TO_GENERATED_FILE";
        int first=code.indexOf("\ntest('");if(first<0)throw new IllegalStateException("No generated scenarios");
        code=old+"\n"+code.substring(first+1);
      }
    }catch(java.io.IOException e){throw new IllegalStateException("Could not safely inspect existing test file",e);}
    try {
      Files.createDirectories(drafts);
      String uid=UUID.randomUUID().toString();
      String hash=sha(code); Path folder=drafts.resolve(uid);Files.createDirectory(folder);
      Draft draft=new Draft(uid,r.task(),r.framework(),feature,path,code,hash,"AWAITING_QA_REVIEW",repo.toString(),r.scenarios().size(),Instant.now().getEpochSecond(),"QA-approved manual rules; verify locators, data and business assertions",baseline,change);
      Files.writeString(folder.resolve("draft.json"),mapper.writeValueAsString(draft),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
      return draft;
    }catch(Exception e){throw new IllegalStateException("Draft could not be created",e);}
  }
  public Draft read(String id){
    if(id==null||!id.matches("[a-f0-9-]{36}"))throw new IllegalArgumentException("Invalid draft ID");
    try{return mapper.readValue(drafts.resolve(id).resolve("draft.json").toFile(),Draft.class);}
    catch(Exception e){throw new IllegalArgumentException("Unknown draft",e);}
  }
  /** Explicitly approved: create a new file only, never overwrite; no Git commit/push. */
  public synchronized Draft approve(Approval a){
    Draft d=read(a.id());
    if(!"AWAITING_QA_REVIEW".equals(d.status()) || !d.sha256().equals(a.checksum()))
      throw new IllegalStateException("Draft is stale, already reviewed, or content checksum mismatched");
    approvals.require(d.task(),"framework",d.originalRepository());
    Path repo=repository(d.originalRepository()); Path target=repo.resolve(d.relativePath()).normalize();
    if(!target.startsWith(repo))throw new IllegalArgumentException("Unsafe target");
    try {
      Files.createDirectories(target.getParent());
      if(d.baselineSha256().isEmpty()){
        Files.writeString(target,d.content(),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
      }else{
        if(!Files.isRegularFile(target)||Files.isSymbolicLink(target)||!sha(Files.readString(target)).equals(d.baselineSha256()))
          throw new IllegalStateException("Underlying existing test was modified; refuse stale approval");
        Files.copy(target,drafts.resolve(d.id()).resolve("previous-version.spec.ts"),StandardCopyOption.COPY_ATTRIBUTES);
        Path tmp=Files.createTempFile(target.getParent(),"qa-reviewed-",".tmp");
        try {
          Files.writeString(tmp,d.content(),StandardCharsets.UTF_8,StandardOpenOption.TRUNCATE_EXISTING);
          try{Files.move(tmp,target,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
          catch(AtomicMoveNotSupportedException ex){Files.move(tmp,target,StandardCopyOption.REPLACE_EXISTING);}
        }finally{Files.deleteIfExists(tmp);}
      }
      Draft accepted=new Draft(d.id(),d.task(),d.framework(),d.feature(),d.relativePath(),d.content(),d.sha256(),"WRITTEN_TO_WORKTREE_REVIEW_COMMIT_REQUIRED",d.originalRepository(),d.scenarios(),d.createdAt(),d.provenance(),d.baselineSha256(),d.changeType());
      Files.writeString(drafts.resolve(d.id()).resolve("draft.json"),mapper.writeValueAsString(accepted),StandardCharsets.UTF_8,StandardOpenOption.TRUNCATE_EXISTING);
      return accepted;
    }catch(FileAlreadyExistsException e){throw new IllegalStateException("Existing test file will never be overwritten; QA must review changes separately");}
    catch(Exception e){throw new IllegalStateException("Could not write reviewed test",e);}
  }
  private Path repository(String raw){try{Path p=Path.of(raw).toRealPath();if(!Files.isDirectory(p))throw new IllegalArgumentException("Not a repository");return p;}catch(Exception e){throw new IllegalArgumentException("Approved local framework path not accessible",e);}}
  private void validate(Scenario s){
    if(s==null || s.name()==null || s.name().isBlank() || s.name().length()>100 ||
      s.urlPath()==null || !s.urlPath().matches("/[A-Za-z0-9/_?&=.%\\-]{0,180}") ||
      s.locator()==null || s.locator().isBlank() || s.locator().length()>160 ||
      s.expectedText()==null || s.expectedText().isBlank() || s.expectedText().length()>250 ||
      s.dataSourceId()==null || s.dataSourceId().isBlank())throw new IllegalArgumentException("Each scenario needs a verified path, locator, assertion, and data-source reference");
  }
  private String playwright(List<Scenario> scenarios){
    StringBuilder sb=new StringBuilder("import { test, expect } from '@playwright/test';\n// QA-reviewed test draft; verify assertions and locator stability.\n");
    for(Scenario s:scenarios){
      sb.append("\ntest('").append(escape(s.name())).append("', async ({ page }) => {\n")
        .append("  // Data provenance: ").append(comment(s.dataSourceId())).append("\n")
        .append("  await page.goto('").append(escape(s.urlPath())).append("');\n")
        .append("  await expect(page.locator('").append(escape(s.locator())).append("')).toContainText('")
        .append(escape(s.expectedText())).append("');\n});\n");
    }
    return sb.toString();
  }
  private String junit(String feature,List<Scenario> scenarios){
    StringBuilder sb=new StringBuilder("package generated;\nimport org.junit.jupiter.api.Test;\nimport org.openqa.selenium.*;\nimport org.openqa.selenium.chrome.ChromeOptions;\nimport org.openqa.selenium.remote.RemoteWebDriver;\nimport java.net.URI;\nimport static org.junit.jupiter.api.Assertions.*;\npublic class ")
      .append(camel(feature)).append("GeneratedTest {\n");
    for(int i=0;i<scenarios.size();i++){
      Scenario s=scenarios.get(i);
      sb.append(" @Test void scenario").append(i+1).append("() throws Exception {\n")
        .append("  // ").append(comment(s.name())).append(" | Data source: ").append(comment(s.dataSourceId())).append("\n")
        .append("  String grid=System.getenv(\"QA_REMOTE_WEBDRIVER_URL\");\n")
        .append("  String base=System.getenv(\"QA_BASE_URL\");\n")
        .append("  if(grid==null||base==null)throw new IllegalStateException(\"QA grid and base URL required\");\n")
        .append("  WebDriver driver=new RemoteWebDriver(URI.create(grid).toURL(),new ChromeOptions());\n")
        .append("  try {driver.get(base+\"").append(escapeJava(s.urlPath())).append("\");\n")
        .append("    assertTrue(driver.findElement(By.cssSelector(\"").append(escapeJava(s.locator()))
        .append("\")).getText().contains(\"").append(escapeJava(s.expectedText())).append("\"));\n")
        .append("  } finally {driver.quit();}\n }\n");
    }
    return sb.append("}\n").toString();
  }
  private String escape(String v){return v.replace("\\","\\\\").replace("'","\\'").replace("\n","\\n").replace("\r","\\r").replace("`","\\`").replace("${","\\${");}
  private String escapeJava(String v){return v.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r");}
  private String comment(String v){String safe=v.replace("\n"," ").replace("\r"," ").replace("*/","");return safe.substring(0,Math.min(safe.length(),120));}
  private String id(String s,String kind){if(s==null||!s.matches("[a-z][a-z0-9-]{1,48}"))throw new IllegalArgumentException("Invalid "+kind+" slug");return s;}
  private String camel(String s){StringBuilder b=new StringBuilder();for(String w:s.split("-"))b.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));return b.toString();}
  private String sha(String s){try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8)));}catch(Exception e){throw new IllegalStateException(e);}}
}
