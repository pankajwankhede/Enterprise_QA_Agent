package com.company.qa;
import org.springframework.stereotype.Service;
import java.util.*;
@Service
public class ConnectionService {
 private final CredentialVault credentials;
 public ConnectionService(CredentialVault credentials){this.credentials=credentials;}
 private static final Set<String> TOOLS=Set.of("octane","sauce","splunk","bitbucket","jira","confluence","jenkins");
 public void save(String tool,String credential){validate(tool);if(credential==null||credential.isBlank())throw new IllegalArgumentException("Empty credential");credentials.save(tool,credential);}
 public String require(String tool){validate(tool);return credentials.read(tool).orElseThrow(()->new IllegalStateException("CONNECTION_REQUIRED: "+tool+"; use the approved OS credential setup, never paste secrets into Copilot"));}
 public String status(String tool){validate(tool);return credentials.read(tool).isPresent()?"CONFIGURED_NOT_VALIDATED":"NOT_CONNECTED";}
 public void disconnect(String tool){validate(tool);credentials.delete(tool);}
 private void validate(String tool){if(!TOOLS.contains(tool))throw new IllegalArgumentException("Unknown connector");}
}
