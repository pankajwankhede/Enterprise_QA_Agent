package com.company.qa.phase7.full;
import org.springframework.ai.mcp.annotation.McpTool;
import org.springframework.stereotype.Component;
/** Copilot can prepare draft/plan, but cannot approve destructive changes or execute tests. */
@Component public class TestAndMatrixMcp {
 private final TestCodeGeneration tests;private final SauceMatrixOrchestrator matrix;
 public TestAndMatrixMcp(TestCodeGeneration tests,SauceMatrixOrchestrator matrix){this.tests=tests;this.matrix=matrix;}
 @McpTool(name="qa_generate_reviewable_test_draft",description="Generate new QA-reviewed test source from exact structured scenario inputs; never overwrites existing files. Approval is via the local portal.")
 public String draft(String task,String repository,String framework,String feature,String scenarioName,String urlPath,String cssLocator,String expectedText){
   return tests.generate(new TestCodeGeneration.Request(task,repository,framework,feature,
     java.util.List.of(new TestCodeGeneration.Scenario(scenarioName,urlPath,cssLocator,expectedText,"qa-approved-manual-input")),"qaInput")).toString();
 }
 @McpTool(name="qa_prepare_sauce_execution_matrix",description="Prepare approved Sauce browser/mobile matrix run based on a team-owned qa-sauce-matrix.json; no execution without separate portal approval.")
 public String matrix(String task,String directory,String targetIdsCsv,int parallel,String suite){
  java.util.List<String> ids=java.util.Arrays.asList(targetIdsCsv.split(","));
  return matrix.prepare(new SauceMatrixOrchestrator.Request(task,directory,ids,parallel,suite)).toString();
 }
 @McpTool(name="qa_sauce_matrix_status",description="Read the latest per-target result of an approved Sauce matrix execution.")
 public String status(String planId){return matrix.read(planId).toString();}
}
