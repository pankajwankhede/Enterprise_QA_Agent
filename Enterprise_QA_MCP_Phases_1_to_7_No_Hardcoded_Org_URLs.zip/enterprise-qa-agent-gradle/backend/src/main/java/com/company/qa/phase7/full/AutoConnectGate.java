package com.company.qa.phase7.full;
import com.company.qa.ConnectionService;
import org.springframework.stereotype.Service;
/** Resolves missing per-user API credentials without leaking them to Copilot. */
@Service public class AutoConnectGate {
 private final ConnectionService c;private final OnDemandConnections queue;private final ConnectionBrowserLauncher browser;
 public AutoConnectGate(ConnectionService c,OnDemandConnections q,ConnectionBrowserLauncher b){this.c=c;queue=q;browser=b;}
 public boolean authRejected(RuntimeException e){return e.getMessage()!=null&&e.getMessage().contains("Remote API HTTP 401");}
 public void invalidate(String tool){c.disconnect(tool);}
 public boolean missing(String tool){return !c.status(tool).startsWith("CONFIGURED");}
 public String connect(String tool,String operation,String argument){
   var request=queue.request(tool,operation,argument);
   String note=browser.ensurePortal();
   return "CONNECTION_REQUIRED: "+tool+" request="+request.id()+". "+note+
     " Complete the approved connection in React On-demand Connections, then call qa_connection_resume(requestId) to retrieve state or supported read-only result.";
 }
}
