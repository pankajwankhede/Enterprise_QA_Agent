package com.company.qa;

import com.sun.jna.*;
import com.sun.jna.ptr.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.springframework.stereotype.Component;
/** Native macOS Security.framework Keychain generic-password operations; no CLI secret arguments. */
@Component
public class MacKeychainCredentials {
 interface Security extends Library {
   Security INSTANCE=Native.load("Security",Security.class);
   int SecKeychainAddGenericPassword(Pointer keychain,int serviceLen,byte[] service,
         int accountLen,byte[] account,int dataLen,byte[] data,PointerByReference out);
   int SecKeychainFindGenericPassword(Pointer keychain,int serviceLen,byte[] service,
         int accountLen,byte[] account,IntByReference size,PointerByReference data,PointerByReference item);
   int SecKeychainItemModifyAttributesAndData(Pointer item,Pointer attributes,int dataLen,byte[] data);
   int SecKeychainItemDelete(Pointer item);
   int SecKeychainItemFreeContent(Pointer attrs,Pointer data);
 }
 interface CoreFoundation extends Library {
   CoreFoundation INSTANCE=Native.load("CoreFoundation",CoreFoundation.class);
   void CFRelease(Pointer object);
 }
 private byte[] key(String tool){return ("EnterpriseQA-MCP/"+tool).getBytes(StandardCharsets.UTF_8);}
 private byte[] account(){return System.getProperty("user.name").getBytes(StandardCharsets.UTF_8);}
 private void os(){if(!System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("mac"))throw new IllegalStateException("Keychain only supported on macOS");}
 public Optional<String> read(String tool){
   os();byte[] s=key(tool),a=account();IntByReference size=new IntByReference();PointerByReference data=new PointerByReference(),item=new PointerByReference();
   int result=Security.INSTANCE.SecKeychainFindGenericPassword(null,s.length,s,a.length,a,size,data,item);
   if(result==-25300)return Optional.empty(); // errSecItemNotFound
   if(result!=0)throw new IllegalStateException("macOS Keychain read denied: OSStatus "+result);
   try{
     int n=size.getValue();if(n<0||n>16384)throw new IllegalStateException("Invalid Keychain entry length");
     return Optional.of(new String(data.getValue().getByteArray(0,n),StandardCharsets.UTF_8));
   }finally{
     if(data.getValue()!=null)Security.INSTANCE.SecKeychainItemFreeContent(null,data.getValue());
     if(item.getValue()!=null)CoreFoundation.INSTANCE.CFRelease(item.getValue());
   }
 }
 public void save(String tool,String value){
   os();byte[] s=key(tool),a=account(),data=value.getBytes(StandardCharsets.UTF_8);
   PointerByReference item=new PointerByReference();PointerByReference existingData=new PointerByReference();IntByReference len=new IntByReference();
   try{
     int existing=Security.INSTANCE.SecKeychainFindGenericPassword(null,s.length,s,a.length,a,len,existingData,item);
     if(existing==0){
       try{int code=Security.INSTANCE.SecKeychainItemModifyAttributesAndData(item.getValue(),null,data.length,data);
           if(code!=0)throw new IllegalStateException("Keychain update declined: OSStatus "+code);
       }finally{
         if(existingData.getValue()!=null)Security.INSTANCE.SecKeychainItemFreeContent(null,existingData.getValue());
         if(item.getValue()!=null)CoreFoundation.INSTANCE.CFRelease(item.getValue());
       }
     }else if(existing==-25300){
       int code=Security.INSTANCE.SecKeychainAddGenericPassword(null,s.length,s,a.length,a,data.length,data,null);
       if(code!=0)throw new IllegalStateException("Keychain enrollment declined: OSStatus "+code);
     }else throw new IllegalStateException("Keychain search failed: OSStatus "+existing);
   }finally{Arrays.fill(data,(byte)0);}
 }
 public void delete(String tool){
   os();byte[] s=key(tool),a=account();PointerByReference item=new PointerByReference();
   int status=Security.INSTANCE.SecKeychainFindGenericPassword(null,s.length,s,a.length,a,null,null,item);
   if(status==-25300)return;
   if(status!=0)throw new IllegalStateException("Keychain lookup declined: OSStatus "+status);
   try{int code=Security.INSTANCE.SecKeychainItemDelete(item.getValue());if(code!=0)throw new IllegalStateException("Keychain deletion declined: OSStatus "+code);}
   finally{if(item.getValue()!=null)CoreFoundation.INSTANCE.CFRelease(item.getValue());}
 }
}
