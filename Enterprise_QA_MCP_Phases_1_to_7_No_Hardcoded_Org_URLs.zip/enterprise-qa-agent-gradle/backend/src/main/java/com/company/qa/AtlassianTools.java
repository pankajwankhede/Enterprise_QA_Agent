package com.company.qa;
import org.springframework.ai.mcp.annotation.McpTool;import org.springframework.stereotype.Component;
@Component
public class AtlassianTools{
 private final ConnectionService conn;
 public AtlassianTools(ConnectionService c){conn=c;}
 @McpTool(name="jira_connection_status",description="Check Jira OAuth credential setup")public String jira(){return conn.status("jira")+"; OAuth app and cloud ID approval required for live API";}
 @McpTool(name="confluence_connection_status",description="Check Confluence OAuth credential setup")public String confluence(){return conn.status("confluence")+"; OAuth app and cloud ID approval required for live API";}
 @McpTool(name="jira_search_issues",description="Jira issue search, requires approved Atlassian OAuth integration")
 public String issues(String jql){return "INTEGRATION_PENDING: Jira Cloud OAuth 3LO app/Cloud ID and scopes must be approved. No query executed.";}
 @McpTool(name="confluence_prepare_report",description="Produce local sanitized RCA report draft; does not publish")
 public String draft(String summary,String evidence){return "# QA Root Cause Investigation\n\n## Summary\n"+Guard.redacted(summary)+"\n\n## Evidence (unverified)\n"+Guard.redacted(evidence)+"\n\n## Reviewer checklist\n- Validate conclusions\n- Redact sensitive data\n- Select destination and approve publication\n";}
}
