package com.company.qa.phase7.full;

import com.company.qa.ConnectionService;
import com.company.qa.ApiClient;
import java.util.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;

/** Local browser-only APIs: protected by local session token and Origin/Host validation. */
@RestController @RequestMapping("/api/v1/phase7/live/on-demand")
public class OnDemandConnectionApi {
 private final OnDemandConnections queue;private final ConnectionService creds;private final ConnectorProfiles profiles;private final ApiClient api;
 public OnDemandConnectionApi(OnDemandConnections q,ConnectionService c,ConnectorProfiles p,ApiClient api){queue=q;creds=c;profiles=p;this.api=api;}
 public record Enroll(String tool,String secret){}
 @GetMapping("/pending") public List<OnDemandConnections.Job> pending(){return queue.pending();}
 @GetMapping("/requests/{id}") public OnDemandConnections.Job get(@PathVariable String id){return queue.get(id);}
 @PostMapping("/requests/{id}/cancel") public OnDemandConnections.Job cancel(@PathVariable String id){return queue.cancel(id);}
 @PostMapping("/requests/{id}/enroll") public OnDemandConnections.Job enroll(@PathVariable String id,@RequestBody Enroll e){
   var job=queue.get(id);if(!job.status().equals("WAITING_FOR_CONNECTION")||!job.tool().equals(e.tool()))throw new IllegalStateException("Mismatched request");
   if(e.secret()==null||e.secret().isBlank()||e.secret().length()>8192)throw new IllegalArgumentException("Credential missing");
   // Never log or include the submitted token in errors or response.
   creds.save(e.tool(),e.secret());
   var result=queue.complete(id);
   if(result.status().equals("FAILED"))creds.disconnect(e.tool());
   return result;
 }
 @PostMapping("/requests/{id}/retry") public OnDemandConnections.Job retry(@PathVariable String id){return queue.complete(id);}
 @GetMapping("/connections/{tool}/status") public Map<String,String> status(@PathVariable String tool){return Map.of("tool",tool,"state",creds.status(tool));}
 @ExceptionHandler({IllegalArgumentException.class,IllegalStateException.class})
 public ResponseEntity<Map<String,String>> error(RuntimeException ex){return ResponseEntity.badRequest().body(Map.of("error",ex.getMessage()==null?"Connection setup error":ex.getMessage()));}
}
