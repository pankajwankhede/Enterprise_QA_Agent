package com.company.qa.phase7.full;

import com.company.qa.ConnectionService;
import com.company.qa.ApiClient;
import com.fasterxml.jackson.databind.JsonNode;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import org.springframework.stereotype.Service;

/** Read-only Jenkins API polling; never constructs job paths from an arbitrary URL. */
@Service
public class JenkinsMonitor {
 private final ConnectorProfiles profiles;private final ConnectionService credentials;private final ApiClient api;
 public JenkinsMonitor(ConnectorProfiles p,ConnectionService c,ApiClient a){profiles=p;credentials=c;api=a;}
 private String auth(){return "Basic "+Base64.getEncoder().encodeToString(credentials.require("jenkins").getBytes(StandardCharsets.UTF_8));}
 private String root(){return profiles.base("jenkins").replaceAll("/$","");}
 private String jobUrl(String job){if(job==null||!job.matches("[A-Za-z0-9_-]{1,80}"))throw new IllegalArgumentException("Invalid job name");return root()+"/job/"+job;}
 public JsonNode build(String job,int number){if(number<1)throw new IllegalArgumentException("Invalid build number");return api.get(jobUrl(job)+"/"+number+"/api/json?tree=number,building,result,url,timestamp,duration,actions[parameters[name,value]]",auth());}
 public JsonNode latest(String job){return api.get(jobUrl(job)+"/lastBuild/api/json?tree=number,building,result,url,timestamp,duration",auth());}
 public JsonNode queue(String job){return api.get(jobUrl(job)+"/api/json?tree=name,lastBuild[number,building,result,url],lastCompletedBuild[number,result,url]",auth());}
}
