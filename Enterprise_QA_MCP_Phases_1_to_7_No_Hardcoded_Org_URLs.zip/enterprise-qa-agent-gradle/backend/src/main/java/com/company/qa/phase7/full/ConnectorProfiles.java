package com.company.qa.phase7.full;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.nio.file.*;
import java.util.*;
import org.springframework.stereotype.Service;

/** User-supplied, non-secret service endpoints. Never stores credentials. */
@Service
public class ConnectorProfiles {
 public record Endpoint(String tool, String baseUrl, String project, String workspace, String notes) {}
 private static final Set<String> TOOLS=Set.of("bitbucket","jenkins","sauce","splunk","octane","jira","confluence","swagger","tdm","qaApi");
 private final Path file=Path.of(System.getProperty("user.home"),".enterprise-qa-mcp","connector-profiles.json");
 private final ObjectMapper json=new ObjectMapper();
 private Map<String,Endpoint> inMemory=null;
 private synchronized Map<String,Endpoint> all(){
  if(inMemory!=null)return inMemory;
  try{if(Files.exists(file)){
   Endpoint[] values=json.readValue(file.toFile(),Endpoint[].class);Map<String,Endpoint> result=new LinkedHashMap<>();
   for(Endpoint p:values){validate(p);result.put(p.tool(),p);}inMemory=result;
  }else inMemory=new LinkedHashMap<>();
  return inMemory;
  }catch(Exception e){throw new IllegalStateException("Could not read connection profiles",e);}
 }
 public synchronized List<Endpoint> list(){return List.copyOf(all().values());}
 public synchronized Optional<Endpoint> get(String tool){verifyTool(tool);return Optional.ofNullable(all().get(tool));}
 public String base(String tool){return get(tool).map(Endpoint::baseUrl).orElseThrow(()->new IllegalStateException("SETUP_REQUIRED: Add "+tool+" HTTPS URL in Connections"));}
 public synchronized Endpoint save(Endpoint endpoint){validate(endpoint);all().put(endpoint.tool(),endpoint);persist();return endpoint;}
 public synchronized void delete(String tool){verifyTool(tool);all().remove(tool);persist();}
 private void persist(){
  try{Files.createDirectories(file.getParent());Path tmp=Files.createTempFile(file.getParent(),"profiles-",".tmp");
   Files.writeString(tmp,json.writerWithDefaultPrettyPrinter().writeValueAsString(all().values()));
   try{Files.move(tmp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException ex){Files.move(tmp,file,StandardCopyOption.REPLACE_EXISTING);}
  }catch(Exception e){throw new IllegalStateException("Could not save connection profiles",e);}
 }
 private void verifyTool(String tool){if(!TOOLS.contains(tool))throw new IllegalArgumentException("Unsupported tool");}
 public static void validate(Endpoint p){
  if(p==null)throw new IllegalArgumentException("Missing connection");
  if(!TOOLS.contains(p.tool()))throw new IllegalArgumentException("Unsupported tool");
  if(p.baseUrl()==null||p.baseUrl().length()>400)throw new IllegalArgumentException("Invalid URL");
  URI uri;
  try{uri=URI.create(p.baseUrl());}catch(Exception e){throw new IllegalArgumentException("Invalid URL");}
  if(!"https".equalsIgnoreCase(uri.getScheme())||uri.getHost()==null||uri.getUserInfo()!=null||uri.getQuery()!=null||uri.getFragment()!=null||uri.getPort()==0)
   throw new IllegalArgumentException("Only HTTPS service origins/approved base paths are allowed; no credentials or query strings");
  if(p.project()!=null&&p.project().length()>100||p.workspace()!=null&&p.workspace().length()>100||p.notes()!=null&&p.notes().length()>200)throw new IllegalArgumentException("Metadata too long");
 }
}
