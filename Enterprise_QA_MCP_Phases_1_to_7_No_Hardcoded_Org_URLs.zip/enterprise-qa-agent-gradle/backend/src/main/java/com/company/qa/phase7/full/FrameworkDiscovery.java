package com.company.qa.phase7.full;

import com.company.qa.ConnectionService;
import com.company.qa.ApiClient;
import com.fasterxml.jackson.databind.JsonNode;
import java.net.URI;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
@Service
public class FrameworkDiscovery {
 private final SourceApprovals approvals;private final ApiClient api;private final ConnectionService connections;private final ConnectorProfiles profiles;
 
 public FrameworkDiscovery(SourceApprovals a,ApiClient c,ConnectionService conn,ConnectorProfiles p){approvals=a;api=c;connections=conn;profiles=p;}
 public record Profile(String repository,String framework,String buildTool,List<String> manifests,List<String> testFiles,List<String> fixtures,boolean verified,String revision,String provenance){}
 public Profile scanLocal(String task,String directory){approvals.require(task,"framework",directory);try{
   Path root=Path.of(directory).toRealPath();if(!Files.isDirectory(root))throw new IllegalArgumentException("Not a directory");
   List<String> paths=new ArrayList<>();try(Stream<Path> walk=Files.walk(root,12)){walk.filter(Files::isRegularFile).filter(f->!Files.isSymbolicLink(f)).limit(15000).forEach(f->{String rel=root.relativize(f).toString().replace('\\','/');if(!rel.contains("node_modules/")&&!rel.contains(".git/")&&!rel.contains("target/"))paths.add(rel);});}
   return analyze(root.toString(),paths,"local-working-copy",true);
 }catch(Exception e){throw new IllegalStateException("Local scan failed: "+e.getMessage(),e);}}
 /** Bitbucket Data Center repository-tree API, paginated. Requires approved exact browse URL. */
 public Profile scanBitbucket(String task,String project,String repo,String revision){
   if(!project.matches("[A-Za-z0-9_-]{1,64}")||!repo.matches("[A-Za-z0-9_.-]{1,128}")||!revision.matches("[A-Za-z0-9_./-]{1,120}")||revision.contains(".."))throw new IllegalArgumentException("Invalid repository coordinates");
   String base=profiles.base("bitbucket").replaceAll("/$","");String url=base+"/projects/"+project+"/repos/"+repo+"/browse";
   approvals.require(task,"bitbucket",url);
   String auth="Bearer "+connections.require("bitbucket");
   String tree=base+"/rest/api/1.0/projects/"+api.enc(project)+"/repos/"+api.enc(repo)+"/files?at="+api.enc(revision);
   List<String> paths=new ArrayList<>();int start=0;boolean next=true;
   while(next&&paths.size()<10000){JsonNode response=api.get(tree+"&limit=500&start="+start,auth);for(JsonNode f:response.path("values")){if(f.isTextual())paths.add(f.asText());}next=!response.path("isLastPage").asBoolean(true);int n=response.path("nextPageStart").asInt(-1);if(next&&(n<0||n<=start))throw new IllegalStateException("Invalid Bitbucket pagination");start=n;}
   if(next)throw new IllegalStateException("Repository exceeds safe 10k-file scan limit");
   return analyze(project+"/"+repo,paths,revision,true);
 }
 public Profile analyze(String repository,List<String> paths,String revision,boolean verified){
   List<String> normalized=paths.stream().map(x->x.replace('\\','/')).toList();
   String lower=String.join("\n",normalized).toLowerCase(Locale.ROOT);
   List<String> manifests=normalized.stream().filter(x->x.matches("(?i).*(pom.xml|build.gradle(?:.kts)?|package.json|playwright.config.[jt]s|testng.xml|pytest.ini|wdio.conf.[jt]s|cypress.config.[jt]s|.*\\.feature)$")).limit(80).toList();
   String framework=lower.contains("playwright.config.")?"Playwright":lower.contains("cypress.config.")?"Cypress":lower.contains("wdio.conf.")?"WebdriverIO":lower.contains("testng.xml")?"TestNG (Selenium unverified)":lower.contains("pytest.ini")?"pytest":lower.contains(".feature")?"Cucumber (driver unverified)":"UNKNOWN - inspect dependencies";
   String build=lower.contains("pom.xml")?"Maven":lower.contains("build.gradle")?"Gradle":lower.contains("package.json")?"npm":"Unknown";
   List<String> tests=normalized.stream().filter(x->x.matches("(?i).*(test|spec)[^/]*\\.(java|ts|tsx|js|py)$")||x.endsWith(".feature")).limit(300).toList();
   List<String> fixtures=normalized.stream().filter(x->x.matches("(?i).*(fixture|testdata|test-data|dataset).*\\.(json|csv|yaml|yml)$")).limit(200).toList();
   return new Profile(repository,framework,build,manifests,tests,fixtures,verified,revision,"File structure only; dependency/requirements review needed");
 }
}
