package com.company.qa.phase7.full;

import com.company.qa.ConnectionService;
import java.util.*;
import org.springframework.web.bind.annotation.*;
/** The local portal configures endpoints, not credentials. Token entry uses native Windows enrollment. */
@RestController @RequestMapping("/api/v1/phase7/live/connections")
public class ConnectionSetupApi {
 private final ConnectorProfiles profiles;private final ConnectionService credentials;
 public ConnectionSetupApi(ConnectorProfiles profiles, ConnectionService credentials){this.profiles=profiles;this.credentials=credentials;}
 @GetMapping public List<Map<String,String>> list(){return profiles.list().stream().map(p->Map.of("tool",p.tool(),"baseUrl",p.baseUrl(),"project",Objects.toString(p.project(),""),"workspace",Objects.toString(p.workspace(),""),"credentials",credentialStatus(p.tool()))).toList();}
 @PutMapping("/{tool}") public ConnectorProfiles.Endpoint configure(@PathVariable String tool,@RequestBody ConnectorProfiles.Endpoint p){
  if(!tool.equals(p.tool()))throw new IllegalArgumentException("Tool path mismatch");return profiles.save(p);
 }
 @DeleteMapping("/{tool}") public Map<String,String> remove(@PathVariable String tool){profiles.delete(tool);return Map.of("status","PROFILE_DELETED","tool",tool);}
 @GetMapping("/{tool}") public Map<String,String> state(@PathVariable String tool){var p=profiles.get(tool);return Map.of("tool",tool,"state",p.isPresent()?"URL_CONFIGURED":"URL_MISSING","credentialStatus",credentialStatus(tool));}
 private String credentialStatus(String tool){try{return credentials.status(tool);}catch(RuntimeException e){return "NOT_APPLICABLE_OR_UNSUPPORTED";}}
}
