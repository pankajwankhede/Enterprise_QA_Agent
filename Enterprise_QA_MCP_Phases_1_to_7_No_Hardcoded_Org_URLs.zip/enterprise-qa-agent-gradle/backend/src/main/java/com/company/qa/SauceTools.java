package com.company.qa;
import org.springframework.ai.mcp.annotation.McpTool;import org.springframework.stereotype.Component;
import java.util.Base64;import java.nio.charset.StandardCharsets;
@Component
public class SauceTools{
 private final com.company.qa.phase7.full.ConnectorProfiles profiles;private final ApiClient api; private final ConnectionService conn;private final com.company.qa.phase7.full.AutoConnectGate gate;
 
 public SauceTools(ApiClient a,ConnectionService c,com.company.qa.phase7.full.ConnectorProfiles p,com.company.qa.phase7.full.AutoConnectGate gate){api=a;conn=c;profiles=p;this.gate=gate;}
 @McpTool(name="sauce_connection_status",description="Check Sauce Labs credentials configured locally") public String status(){return conn.status("sauce");}
 @McpTool(name="sauce_get_job",description="Read Sauce Labs automated test job metadata by account username and job ID")
 public String job(String username,String jobId){Guard.id(username);Guard.id(jobId);if(gate.missing("sauce"))return gate.connect("sauce","sauce_job",username+":"+jobId);String pair=conn.require("sauce");
  String auth="Basic "+Base64.getEncoder().encodeToString(pair.getBytes(StandardCharsets.UTF_8));
  try{return api.get(profiles.base("sauce")+"/rest/v1/"+api.enc(username)+"/jobs/"+api.enc(jobId),auth).toString();}
  catch(IllegalStateException e){if(gate.authRejected(e)){gate.invalidate("sauce");return gate.connect("sauce","sauce_job",username+":"+jobId);}throw e;}}
}
