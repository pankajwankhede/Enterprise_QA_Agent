package com.company.qa.phase7.full;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/v1/phase7/live/requirements")
public class RequirementsApi {
 private final ApprovedRequirementsCollector service;
 public RequirementsApi(ApprovedRequirementsCollector s){service=s;}
 @PostMapping("/collect")
 public ApprovedRequirementsCollector.Result collect(@RequestBody ApprovedRequirementsCollector.Request r){return service.collect(r);}
}
