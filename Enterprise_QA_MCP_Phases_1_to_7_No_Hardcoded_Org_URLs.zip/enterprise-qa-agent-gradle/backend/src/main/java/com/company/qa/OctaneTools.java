package com.company.qa;
import org.springframework.ai.mcp.annotation.McpTool;
import org.springframework.stereotype.Component;
@Component
public class OctaneTools {
 private final com.company.qa.phase7.full.ConnectorProfiles profiles;private final ApiClient api;private final ConnectionService conn;private final com.company.qa.phase7.full.AutoConnectGate gate;
 
 
 
 public OctaneTools(ApiClient a,ConnectionService c,com.company.qa.phase7.full.ConnectorProfiles p,com.company.qa.phase7.full.AutoConnectGate gate){api=a;conn=c;profiles=p;this.gate=gate;}
 private String root(){
  var endpoint=profiles.get("octane").orElseThrow(()->new IllegalStateException("SETUP_REQUIRED: Configure Octane URL in Connections"));
  // In React Connections: project = shared-space ID; workspace = workspace ID.
  String shared=endpoint.project(),workspace=endpoint.workspace();
  if(shared==null||!shared.matches("[0-9]{1,20}")||workspace==null||!workspace.matches("[0-9]{1,20}"))
    throw new IllegalStateException("SETUP_REQUIRED: Enter numeric Octane shared-space and workspace IDs in Connections");
  return endpoint.baseUrl().replaceAll("/+$", "")+"/api/shared_spaces/"+shared+"/workspaces/"+workspace;
 }
 // API key authorization is tenant-dependent; approved API credentials must be configured by a security-reviewed adapter.
 @McpTool(name="octane_connection_status",description="Report Octane credential setup status")
 public String status(){return conn.status("octane")+" (tenant authentication not verified)";}
 @McpTool(name="octane_search_defects",description="Search Octane defects by a text term, read-only")
 public String search(String term){
  Guard.project(term.replace(' ','_'));if(gate.missing("octane"))return gate.connect("octane","octane_defect_search",term); // restricted read-only replay
  try{return api.get(root()+"/defects?limit=20&query="+api.enc("name EQ '^"+term+"^'"),"Bearer "+conn.require("octane")).toString();}
  catch(IllegalStateException e){if(gate.authRejected(e)){gate.invalidate("octane");return gate.connect("octane","octane_defect_search",term);}throw e;}
 }
}
