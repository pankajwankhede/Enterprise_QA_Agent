package com.company.qa.phase7.full;
import com.company.qa.ApiClient;
import com.company.qa.ConnectionService;
import com.fasterxml.jackson.databind.JsonNode;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.springframework.stereotype.Service;
/** Sauce Labs job metadata. Does not claim unavailable artifacts or infer root cause. */
@Service
public class SauceResultsService {
 private final ApiClient api;private final ConnectorProfiles profiles;private final ConnectionService credentials;
 public SauceResultsService(ApiClient api,ConnectorProfiles p,ConnectionService c){
  this.api=api;profiles=p;credentials=c;
 }
 public Map<String,Object> job(String username,String id){
  if(username==null||!username.matches("[A-Za-z0-9_.-]{1,100}")||
     id==null||!id.matches("[A-Za-z0-9_-]{1,128}"))
     throw new IllegalArgumentException("Invalid Sauce Labs job/account identifier");
  String base=profiles.base("sauce").replaceAll("/$","");
  String creds=credentials.require("sauce");
  if(!creds.contains(":"))throw new IllegalStateException("Sauce credential must be username:access-key");
  String auth="Basic "+Base64.getEncoder().encodeToString(creds.getBytes(StandardCharsets.UTF_8));
  JsonNode j=api.get(base+"/rest/v1/"+api.enc(username)+"/jobs/"+api.enc(id),auth);
  Map<String,Object> result=new LinkedHashMap<>();
  result.put("jobId",id);result.put("account",username);
  for(String k:List.of("name","status","passed","error","os","browser","browser_version","creation_time","start_time","end_time","tags","build","public","video_url","log_url","commands_not_successful")){
   if(j.hasNonNull(k))result.put(k,j.get(k));
  }
  result.put("note","Job metadata only. Availability of screenshots, logs, videos and HTTP traces depends on the account, job settings and API response.");
  return result;
 }
}
