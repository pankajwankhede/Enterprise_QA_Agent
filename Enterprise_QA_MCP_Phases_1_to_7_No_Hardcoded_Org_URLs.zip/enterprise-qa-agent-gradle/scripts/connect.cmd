@echo off
setlocal EnableExtensions
if "%~1"=="" goto usage
if "%~2"=="" goto usage
set "ACTION=%~1"
set "TOOL=%~2"
if /I not "%ACTION%"=="save" if /I not "%ACTION%"=="delete" if /I not "%ACTION%"=="status" goto usage
set "ALLOWED=0"
for %%T in (octane sauce splunk bitbucket jira confluence jenkins) do if /I "%TOOL%"=="%%T" set "ALLOWED=1"
if "%ALLOWED%"=="0" goto usage
set "BACKEND=%~dp0..\backend"
set "GRADLE_CMD=gradle"
if exist "%BACKEND%\gradlew.bat" set "GRADLE_CMD=gradlew.bat"
if not exist "%BACKEND%\gradlew.bat" (
  where gradle >nul 2>&1
  if errorlevel 1 (echo ERROR: Gradle missing. & exit /b 1)
)
echo Only enter approved API tokens in the hidden console prompt. Never enter SSO passwords.
pushd "%BACKEND%" || exit /b 1
call %GRADLE_CMD% --quiet --console=plain credentialSetup -PcredentialAction=%ACTION% -PcredentialTool=%TOOL%
set "CODE=%errorlevel%"
popd
exit /b %CODE%
:usage
echo Usage: scripts\connect.cmd save^|delete^|status octane^|sauce^|splunk^|bitbucket^|jira^|confluence^|jenkins
exit /b 2
