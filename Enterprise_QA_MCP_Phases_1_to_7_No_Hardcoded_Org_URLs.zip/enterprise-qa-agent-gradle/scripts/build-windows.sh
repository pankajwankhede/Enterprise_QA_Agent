#!/usr/bin/env bash
# Run the Windows-native CMD build from Git Bash. Does not invoke PowerShell.
set -euo pipefail
here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
case "$(uname -s)" in
  MINGW*|MSYS*|CYGWIN*) ;;
  *) echo "This packaging script requires Git Bash running on Windows." >&2; exit 1 ;;
esac
win_script="$(cygpath -w "$here/build-windows.cmd")"
cmd.exe /d /c "\"$win_script\" ${1:-}" 
