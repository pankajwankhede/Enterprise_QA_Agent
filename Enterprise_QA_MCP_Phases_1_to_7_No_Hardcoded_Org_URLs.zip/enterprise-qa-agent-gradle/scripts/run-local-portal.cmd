@echo off
setlocal EnableExtensions
set "JAR=%~dp0..\backend\build\libs\enterprise-qa-mcp-0.1.0.jar"
if not exist "%JAR%" (
  echo ERROR: Backend JAR missing. Run scripts\build-windows.cmd first.
  exit /b 1
)
java -jar "%JAR%" --spring.profiles.active=portal
exit /b %errorlevel%
