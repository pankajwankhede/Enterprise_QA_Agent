@echo off
setlocal EnableExtensions DisableDelayedExpansion
rem Build React + Gradle Spring Boot + Windows jpackage. CMD only; no Maven/PowerShell.
rem Usage: scripts\build-windows.cmd [--exe]
set "ROOT=%~dp0.."
set "FRONTEND=%ROOT%\frontend"
set "BACKEND=%ROOT%\backend"
set "DIST=%ROOT%\windows-dist"
set "INPUT=%DIST%\input"
set "BUILD_EXE=0"
if /I "%~1"=="--exe" set "BUILD_EXE=1"
if not "%~1"=="" if /I not "%~1"=="--exe" (
  echo Usage: scripts\build-windows.cmd [--exe]
  exit /b 2
)
where npm >nul 2>&1
if errorlevel 1 (echo ERROR: npm not found. Configure Node.js PATH. & exit /b 1)
where jpackage >nul 2>&1
if errorlevel 1 (echo ERROR: jpackage not found. Configure JDK 21 PATH. & exit /b 1)
if not exist "%BACKEND%\build.gradle" (echo ERROR: Gradle backend missing. & exit /b 1)
if not exist "%FRONTEND%\package.json" (echo ERROR: React frontend missing. & exit /b 1)
set "GRADLE_CMD=gradle"
if exist "%BACKEND%\gradlew.bat" set "GRADLE_CMD=gradlew.bat"
if not exist "%BACKEND%\gradlew.bat" (
  where gradle >nul 2>&1
  if errorlevel 1 (echo ERROR: Gradle missing. Install organization-approved Gradle, or generate a Gradle Wrapper in backend. & exit /b 1)
)
echo [1/5] Installing npm dependencies...
pushd "%FRONTEND%" || exit /b 1
if exist package-lock.json (
  call npm ci
) else (
  echo WARNING: No package-lock.json - use approved registry and commit lockfile for repeatable builds.
  call npm install
)
if errorlevel 1 (popd & echo ERROR: npm install failed & exit /b 1)
echo [2/5] Building React...
call npm run build
if errorlevel 1 (popd & echo ERROR: React build failed & exit /b 1)
popd
if not exist "%FRONTEND%\dist\index.html" (echo ERROR: Missing React output & exit /b 1)
set "WEBTARGET=%BACKEND%\src\main\resources\static"
if not exist "%WEBTARGET%" mkdir "%WEBTARGET%"
echo [3/5] Copy React assets into backend...
xcopy "%FRONTEND%\dist\*" "%WEBTARGET%\" /E /I /Y /Q >nul
if errorlevel 1 (echo ERROR: React resource copy failed & exit /b 1)
echo [4/5] Running Gradle tests and building bootJar...
pushd "%BACKEND%" || exit /b 1
call %GRADLE_CMD% --no-daemon clean test bootJar
if errorlevel 1 (popd & echo ERROR: Gradle build failed & exit /b 1)
popd
set "JAR=%BACKEND%\build\libs\enterprise-qa-mcp-0.1.0.jar"
if not exist "%JAR%" (echo ERROR: Gradle bootJar missing: "%JAR%" & exit /b 1)
if not exist "%INPUT%" mkdir "%INPUT%"
copy /Y "%JAR%" "%INPUT%\enterprise-qa-mcp.jar" >nul
if errorlevel 1 (echo ERROR: JAR copy failed & exit /b 1)
echo [5/5] Creating Windows app image...
if exist "%DIST%\EnterpriseQA" rmdir /S /Q "%DIST%\EnterpriseQA"
jpackage --type app-image --name EnterpriseQA --app-version 1.0.0 --input "%INPUT%" --main-jar enterprise-qa-mcp.jar --main-class org.springframework.boot.loader.launch.JarLauncher --java-options "-Dspring.profiles.active=portal" --dest "%DIST%"
if errorlevel 1 (echo ERROR: jpackage app image failed & exit /b 1)
if "%BUILD_EXE%"=="1" (
  echo Packaging Windows EXE with jpackage...
  jpackage --type exe --name EnterpriseQA --app-version 1.0.0 --app-image "%DIST%\EnterpriseQA" --dest "%DIST%" --win-menu --win-shortcut
  if errorlevel 1 (echo ERROR: EXE packaging failed - verify WiX prerequisite & exit /b 1)
)
echo.
echo Output directory: "%DIST%"
echo WARNING: Installer not production tested or signed. Verify on approved Windows machine.
exit /b 0
