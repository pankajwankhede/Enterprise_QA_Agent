#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
JAR="$ROOT/backend/build/libs/enterprise-qa-mcp-0.1.0.jar"
[[ -f "$JAR" ]] || { echo 'Build backend first: cd backend && gradle bootJar' >&2;exit 1;}
exec java -Dspring.profiles.active=portal -jar "$JAR"
