#!/usr/bin/env bash
# Build on macOS only. No PowerShell, Maven, Jenkins or Windows tooling.
set -euo pipefail
if [[ "$(uname -s)" != "Darwin" ]]; then echo "ERROR: Native macOS packages must be built on a Mac." >&2; exit 2; fi
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
FRONT="$ROOT/frontend"; BACK="$ROOT/backend"; DIST="$ROOT/macos-dist"; INPUT="$DIST/input"
TYPE="${1:---dmg}"
case "$TYPE" in --dmg) PKG=dmg;; --pkg) PKG=pkg;; --app-image) PKG=app-image;; *) echo 'Usage: bash scripts/build-macos.sh [--dmg|--pkg|--app-image]' >&2;exit 2;;esac
for c in npm java jpackage; do command -v "$c" >/dev/null || { echo "ERROR: $c missing" >&2;exit 1;};done
if [[ -x "$BACK/gradlew" ]];then GRADLE=("$BACK/gradlew");else command -v gradle >/dev/null || { echo 'ERROR: Gradle missing or wrapper unavailable' >&2;exit 1;};GRADLE=(gradle);fi
mkdir -p "$INPUT"
cd "$FRONT"
if [[ -f package-lock.json ]]; then npm ci; else echo 'WARNING: package-lock.json absent; npm install is less reproducible'; npm install;fi
npm run build
[[ -f dist/index.html ]] || { echo 'ERROR: React production build missing';exit 1;}
TARGET="$BACK/src/main/resources/static";mkdir -p "$TARGET";rm -rf "$TARGET/assets";cp -R dist/. "$TARGET/"
cd "$BACK"; "${GRADLE[@]}" --no-daemon clean test bootJar
JAR="$BACK/build/libs/enterprise-qa-mcp-0.1.0.jar"
[[ -s "$JAR" ]] || { echo "ERROR: backend jar not found $JAR";exit 1;}
cp "$JAR" "$INPUT/enterprise-qa-mcp.jar"
mkdir -p "$DIST"
# A native macOS app bundle runs with its bundled Java runtime; it does not need Node or Gradle.
jpackage --type "$PKG" --name EnterpriseQA --app-version 1.0.0 --input "$INPUT" --main-jar enterprise-qa-mcp.jar --main-class org.springframework.boot.loader.launch.JarLauncher --java-options '-Dspring.profiles.active=portal' --dest "$DIST"
echo "Build output: $DIST"
echo 'NOT SIGNED OR NOTARIZED. Verify on a compatible Mac; corporate deployment requires security review.'
