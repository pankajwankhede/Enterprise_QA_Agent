> **Gradle edition note:** This file may contain historical implementation notes. Use the root `README.md` for current CMD/Gradle commands.

# Phase 7 — Functional components, setup, and verification boundaries

This source ZIP upgrades the Phase 7 **demo-only** code with the following functional, guarded operations:

| Component | Implemented behavior | Still required for use in your organization |
|---|---|---|
| Local portal guard | 256-bit per-process local token delivered as a browser URL fragment; React sends a protected header on `/api/v1/phase7/live/**` | Security review; corporate endpoint hardening and code-signing |
| Individual source approval | Persist per-task per-source decisions to user profile; exact location and 1-hour validity checked before framework reads | QA team policy, Windows filesystem ACL review |
| Bitbucket discovery | Paginated Data Center `files` API; inspect names, list test files/fixtures, classify framework hints | Approved repository URL, PAT and actual Bitbucket Data Center API validation |
| Local framework discovery | Bounded walk of explicitly approved local folder; metadata only | Windows path / repo source and permission |
| Framework scaffolder | Creates **new** Playwright TS or Selenium JUnit Java starter under approved local folder; refuses overwrite | Framework selection, generated code and business assertion review |
| Execution plans | Validate exact SHA, suite, environment, target list, max concurrency, allowlisted Jenkins job and HTTPS base; durable pending plan | Configured job, actual tested framework/target matrix |
| Execution approval | Per-plan 8-char challenge and expiry; immutable plan, persistent state, reject or trigger once | Corporate reviewer identity integration/authorization review |
| Jenkins adapter | POST `buildWithParameters` to one allowlisted HTTPS job using Windows Credential Manager Jenkins credential; fail closed | Jenkins credentials, job parameter contract, webhook/CI policy and remote integration test |
| MCP integration | Source approval listing and Bitbucket discovery tools on the MCP runtime | Confirm MCP tool discovery in target IDE |

**Not complete/verified:** automatic Jira/Confluence/OpenAPI requirements extraction, real synthetic test-data allocation, automated test case generation from unstructured requirements, source-code patching, reviewed Bitbucket PR creation, runtime Sauce Labs device inventory, execution-artifact correlation, Jenkins live status polling, automatic post-deployment shared approvals, unattended AI generation, and end-to-end validation of all Phases 1–6. The older Phase 1–6 modules remain starter adapters. Do not represent this bundle as fully production-ready.

## Portal flow

1. Build/run the **portal** profile on Windows. Browser opens with a fragment `#qa-session=...` (never log/share it). React clears it from the URL and holds it only in memory.
2. Go to **Live Phase 7**, then **Source Approvals**. Create task ID and choose source. For Bitbucket, location must exactly equal `https://bitbucket.glb.abc.com/projects/PROJECT/repos/REPO/browse` (update base in config). For local framework, give an absolute Windows directory.
3. Approve each source separately. Mode MANUAL stores approved nonsecret descriptions; it never triggers external reads. SKIP prohibits reads.
4. In **Framework Discovery**, submit task/project/repo/revision to retrieve the paginated Bitbucket file catalog using the user's read-only token, or a previously approved local directory.
5. For missing framework, choose Playwright TS or Selenium Java and scaffold to an approved empty destination parent. **Generated starter does not generate business test cases automatically.**
6. For execution, configure `QA_JENKINS_BASE_URL` and `QA_JENKINS_ALLOWED_JOBS`, and save a personal Jenkins credential using the approved Windows CLI mechanism (see below). Prepare immutable plan with exact deployed commit SHA and approve via portal. Jenkins must own orchestration, Sauce Labs credentials and test-run lifecycle.

## Windows Jenkins credential

`scripts/connect.cmd` can provision credentials for connector names accepted by `ConnectionService`, including `jenkins` in this build. Store the Jenkins credential as `<username>:<API-token>` with only the minimal trigger permissions and no plaintext file. Never insert it into the portal form or a Copilot prompt. Existing Sauce Labs, Bitbucket etc. have their own credential formats. Jenkins must use **its own** Sauce Labs service secret.

## Jenkins job parameter contract

The adapter passes exact parameter names: `APPLICATION`, `SUITE`, `ENVIRONMENT`, `REVISION`, `TARGETS` (comma-separated), `PARALLEL`. The Jenkins job must validate all these values again, check deployed SHA matches `REVISION`, check that actual Sauce Labs devices/versions/region are supported, enforce Sauce Labs account quota, reserve isolated synthetic test data, and require its own corporate approval gate for policies requiring centralized approval. Never blindly run untrusted shell commands from these values.

## Security/operational notes

- Localhost binding only; browser authorization token prevents unrelated local websites from calling live endpoints with ambient authority. This **is not** an enterprise SSO authorization/role mechanism.
- Local approvals belong to the machine's Windows identity; they are **not suitable as an organization-wide durable approval record**. For unattended pipelines use Jenkins `input`/reviewer authorization and CI-managed state.
- Approvals are locally stored JSON containing possibly sensitive manual descriptions. Only enter sanitized synthetic values and protect `%USERPROFILE%\\.enterprise-qa-mcp` via OS ACLs. Consider encryption/retention and purging before production deployment.
- The Jenkins adapter records `SUBMISSION_UNCERTAIN` on failures after starting submission. Check Jenkins queue before repeating to prevent duplicate expensive runs.
- The project's build was **not verified** here because Gradle and npm dependencies were not available in the offline runtime. A Windows CI build, tests, and full security review are required before rollout.
