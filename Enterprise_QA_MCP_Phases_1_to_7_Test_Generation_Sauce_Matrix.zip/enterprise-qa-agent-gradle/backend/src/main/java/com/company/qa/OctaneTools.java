package com.company.qa;
import org.springframework.ai.mcp.annotation.McpTool;
import org.springframework.stereotype.Component;import org.springframework.beans.factory.annotation.Value;
@Component
public class OctaneTools {
 private final com.company.qa.phase7.full.ConnectorProfiles profiles;private final ApiClient api;private final ConnectionService conn;
 @Value("${qa.octane.base-url}") String base;
 @Value("${qa.octane.shared-space}") String shared;
 @Value("${qa.octane.workspace}") String workspace;
 public OctaneTools(ApiClient a,ConnectionService c,com.company.qa.phase7.full.ConnectorProfiles p){api=a;conn=c;profiles=p;}
 private String root(){return profiles.base("octane")+"/api/shared_spaces/"+shared+"/workspaces/"+workspace;}
 // API key authorization is tenant-dependent; approved API credentials must be configured by a security-reviewed adapter.
 @McpTool(name="octane_connection_status",description="Report Octane credential setup status")
 public String status(){return conn.status("octane")+" (tenant authentication not verified)";}
 @McpTool(name="octane_search_defects",description="Search Octane defects by a text term, read-only")
 public String search(String term){
  Guard.project(term.replace(' ','_')); // strict safe term constraint for pilot
  return api.get(root()+"/defects?limit=20&query="+api.enc("name EQ '^"+term+"^'"),"Bearer "+conn.require("octane")).toString();
 }
}
