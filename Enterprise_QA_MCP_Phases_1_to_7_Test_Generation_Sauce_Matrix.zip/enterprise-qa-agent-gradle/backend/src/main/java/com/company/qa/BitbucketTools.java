package com.company.qa;
import org.springframework.ai.mcp.annotation.McpTool;import org.springframework.stereotype.Component;import org.springframework.beans.factory.annotation.Value;
@Component
public class BitbucketTools{
 private final com.company.qa.phase7.full.ConnectorProfiles profiles;private final ApiClient api;private final ConnectionService conn;@Value("${qa.bitbucket.base-url}")String base;
 public BitbucketTools(ApiClient a,ConnectionService c,com.company.qa.phase7.full.ConnectorProfiles p){api=a;conn=c;profiles=p;}
 @McpTool(name="bitbucket_connection_status",description="Check the local Bitbucket connection")public String status(){return conn.status("bitbucket");}
 @McpTool(name="bitbucket_list_projects",description="List accessible Bitbucket Data Center projects, read-only")
 public String projects(){return api.get(profiles.base("bitbucket")+"/rest/api/1.0/projects?limit=25","Bearer "+conn.require("bitbucket")).toString();}
 @McpTool(name="bitbucket_list_repositories",description="List accessible repositories for a Bitbucket project")
 public String repositories(String projectKey){Guard.project(projectKey);return api.get(profiles.base("bitbucket")+"/rest/api/1.0/projects/"+api.enc(projectKey)+"/repos?limit=25","Bearer "+conn.require("bitbucket")).toString();}
}
