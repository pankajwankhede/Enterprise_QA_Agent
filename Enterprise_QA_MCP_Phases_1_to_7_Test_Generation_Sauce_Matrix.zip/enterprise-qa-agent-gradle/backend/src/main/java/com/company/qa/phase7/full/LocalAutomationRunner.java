package com.company.qa.phase7.full;

import com.company.qa.ConnectionService;
import com.company.qa.WindowsCredentials;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import javax.xml.parsers.DocumentBuilderFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.*;

/**
 * Runs existing, explicitly approved local automation repositories.
 * WARNING: npm/Gradle scripts execute repository code with the current user's rights.
 * Disabled by default. No arbitrary shell-command input is accepted.
 */
@Service
public class LocalAutomationRunner {
  public record Request(String task,String directory,String framework,String suite,
                        String environment,List<String> targets,int parallel,boolean useSauce) {}
  public record Job(String id,String state,String framework,String suite,String directory,
                    List<String> targets,int parallel,boolean useSauce,long startedAt,Long finishedAt,
                    Integer exitCode,String message,String logFile,String reportFile) {}
  public record Approval(String jobId,String confirmation) {}
  private static final Set<String> FRAMEWORKS=Set.of("gradle","playwright","cypress","saucectl");
  private static final Set<String> SUITES=Set.of("smoke","regression","e2e","all");
  private static final Set<String> TARGETS=Set.of("chrome","firefox","edge","safari","android","ios");
  private final SourceApprovals sources;private final ConnectionService credentials;private final WindowsCredentials vault;
  private final ObjectMapper json=new ObjectMapper();
  private final ExecutorService workers=Executors.newFixedThreadPool(2,r->{Thread t=new Thread(r,"qa-local-runner");t.setDaemon(true);return t;});
  private final Path dir=Path.of(System.getProperty("user.home"),".enterprise-qa-mcp","local-runs");
  private final ConcurrentMap<String,String> confirmations=new ConcurrentHashMap<>();
  @Value("${qa.phase7.local-execution.enabled:false}") boolean enabled;
  @Value("${qa.phase7.local-execution.max-minutes:30}") int maxMinutes;
  public LocalAutomationRunner(SourceApprovals sources,ConnectionService credentials,WindowsCredentials vault) {
    this.sources=sources;this.credentials=credentials;this.vault=vault;
  }
  public synchronized Job prepare(Request r) {
    if(!enabled)throw new IllegalStateException("Local execution disabled by administrator; enable qa.phase7.local-execution.enabled after review");
    if(r==null||!safeId(r.task())||!FRAMEWORKS.contains(r.framework())||!SUITES.contains(r.suite())||
       !Set.of("qa","staging").contains(r.environment())||r.parallel()<1||r.parallel()>4||
       r.targets()==null||r.targets().isEmpty()||r.targets().size()>6||
       r.targets().stream().anyMatch(t->!TARGETS.contains(t)))
       throw new IllegalArgumentException("Invalid local execution configuration");
    sources.require(r.task(),"framework",r.directory());
    Path working=verifiedPath(r.directory());
    if(r.framework().equals("gradle")&&!Files.exists(working.resolve(isWindows()?"gradlew.bat":"gradlew")))
      throw new IllegalStateException("Gradle Wrapper missing; no system Gradle fallback");
    if(Set.of("playwright","cypress","saucectl").contains(r.framework())&&!Files.exists(working.resolve("package.json")))
      throw new IllegalStateException("package.json required");
    String id=UUID.randomUUID().toString();
    Job job=new Job(id,"PENDING_APPROVAL",r.framework(),r.suite(),working.toString(),List.copyOf(r.targets()),
          r.parallel(),r.useSauce(),Instant.now().getEpochSecond(),null,null,
          "Approved local repository scripts may execute arbitrary code; review the repository before approving.","","");
    persist(job);
    confirmations.put(id,UUID.randomUUID().toString().substring(0,8));
    return job;
  }
  public synchronized String approvalChallenge(String id) {
    Job job=read(id);
    if(!job.state().equals("PENDING_APPROVAL"))throw new IllegalStateException("Not pending");
    String code=confirmations.get(id);
    if(code==null)throw new IllegalStateException("Approval challenge expired after application restart; prepare a new run");
    return code;
  }
  public synchronized Job approveAndStart(Approval approval) {
    Job job=read(approval.jobId());
    if(!job.state().equals("PENDING_APPROVAL"))throw new IllegalStateException("Not pending");
    String challenge=confirmations.remove(job.id());
    if(challenge==null||!challenge.equals(approval.confirmation()))
      throw new IllegalStateException("Approval confirmation invalid or expired");
    if(Instant.now().getEpochSecond()-job.startedAt()>1800)
      throw new IllegalStateException("Approval expired");
    Job running=replace(job,"QUEUED",null,"Approved by local user; waiting for runner",null,null);
    workers.submit(()->run(running));
    return running;
  }
  public synchronized Job reject(String id) {
    Job j=read(id);
    if(!j.state().equals("PENDING_APPROVAL"))throw new IllegalStateException("Not pending");
    confirmations.remove(id);
    return replace(j,"REJECTED",null,"Rejected by user",null,null);
  }
  public Job read(String id){
    if(id==null||!id.matches("[0-9a-f-]{36}"))throw new IllegalArgumentException("Invalid run id");
    try{return json.readValue(dir.resolve(id+".json").toFile(),Job.class);}
    catch(IOException e){throw new IllegalArgumentException("Unknown run",e);}
  }
  public String logTail(String id){
    Job j=read(id);if(j.logFile().isBlank())return "";
    try {
      byte[] data=Files.readAllBytes(Path.of(j.logFile()));
      String tail=new String(data,Math.max(0,data.length-12000),Math.min(12000,data.length),StandardCharsets.UTF_8);
      try {String secret=credentials.require("sauce");int sep=secret.indexOf(':');if(sep>=0)tail=tail.replace(secret.substring(sep+1),"[REDACTED]");}catch(Exception ignored){}
      try {String secret=vault.read("nexus-password").orElse("");if(!secret.isEmpty())tail=tail.replace(secret,"[REDACTED]");}catch(Exception ignored){}
      return tail;
    }catch(IOException e){return "Log not yet available";}
  }
  private void run(Job approved) {
    Job current=approved;
    try{
      current=replace(current,"RUNNING",null,"Running locally",null,null);
      Path root=verifiedPath(current.directory());
      Path work=dir.resolve(current.id());Files.createDirectories(work);
      Path log=work.resolve("execution.log");
      List<String> cmd=command(current);
      ProcessBuilder builder=new ProcessBuilder(cmd).directory(root.toFile()).redirectErrorStream(true).redirectOutput(log.toFile());
      Map<String,String> env=builder.environment();
      env.put("QA_TEST_SUITE",current.suite());
      env.put("QA_EXECUTION_TARGETS",String.join(",",current.targets()));
      env.put("QA_MAX_PARALLEL",String.valueOf(current.parallel()));
      applyApprovedBuildProfile(env,work,current.framework());
      // Sauce secrets go only to the child process environment, never arguments or logs.
      if(current.useSauce()){
        String stored=credentials.require("sauce");
        int colon=stored.indexOf(':');
        if(colon<=0||colon==stored.length()-1)throw new IllegalStateException("Sauce credential must use username:access-key");
        env.put("SAUCE_USERNAME",stored.substring(0,colon));
        env.put("SAUCE_ACCESS_KEY",stored.substring(colon+1));
      }
      Process p=builder.start();
      env.remove("SAUCE_ACCESS_KEY");env.remove("SAUCE_USERNAME");
      env.remove("ORG_GRADLE_PROJECT_nexusPassword");
      boolean finished=p.waitFor(Math.max(1,Math.min(maxMinutes,120)),TimeUnit.MINUTES);
      if(!finished){p.descendants().forEach(ProcessHandle::destroyForcibly);p.destroyForcibly();p.waitFor(5,TimeUnit.SECONDS);}
      int exit=finished?p.exitValue():-1;
      Path report=work.resolve("results.json");
      Map<String,Object> data=new LinkedHashMap<>();data.put("runner",current.framework());data.put("exitCode",exit);data.put("timedOut",!finished);
      data.put("junit",junit(root));data.put("completedAt",Instant.now().toString());
      Files.writeString(report,json.writerWithDefaultPrettyPrinter().writeValueAsString(data));
      replace(current,finished&&exit==0?"PASSED":"FAILED",exit,finished?"Runner exited "+exit:"Timed out",
              log.toString(),report.toString());
    }catch(Exception ex){
      replace(current,"FAILED",-1,"Execution failed: "+ex.getClass().getSimpleName(),null,null);
      if(ex instanceof InterruptedException)Thread.currentThread().interrupt();
    }
  }
  /** Optional user-scoped build settings. Never persist passwords in runtime profiles. */
  private void applyApprovedBuildProfile(Map<String,String> env,Path runDir,String framework) throws IOException {
    Path profile=Path.of(System.getProperty("user.home"),".enterprise-qa-mcp","installer-build-profile.json");
    if(!Files.isRegularFile(profile))return;
    @SuppressWarnings("unchecked")
    Map<String,Object> conf=json.readValue(profile.toFile(),Map.class);
    if(framework.equals("gradle")){
      String url=Objects.toString(conf.getOrDefault("nexusUrl",""),"");
      String user=Objects.toString(conf.getOrDefault("nexusUsername",""),"");
      if(!url.isBlank()){
        if(!url.startsWith("https://"))throw new IllegalStateException("Nexus URL must use HTTPS");
        env.put("ORG_GRADLE_PROJECT_nexusUrl",url);
      }
      if(!user.isBlank())env.put("ORG_GRADLE_PROJECT_nexusUsername",user);
      var password=vault.read("nexus-password");
      password.ifPresent(v->env.put("ORG_GRADLE_PROJECT_nexusPassword",v));
    }else if(framework.equals("playwright")||framework.equals("cypress")){
      String npm=Objects.toString(conf.getOrDefault("npmrc",""),"");
      if(!npm.isBlank()){
        // The profile validator must exclude all auth tokens/passwords.
        if(npm.matches("(?is).*(?:_authToken|_password|_auth\\s*=|password\\s*=).*"))
          throw new IllegalStateException("Insecure npm profile contains credentials");
        Path file=runDir.resolve("npm-userconfig");
        Files.writeString(file,npm,StandardOpenOption.CREATE_NEW);
        env.put("NPM_CONFIG_USERCONFIG",file.toString());
      }
    }
  }
  private List<String> command(Job j){
    boolean win=isWindows();
    return switch(j.framework()){
      case "gradle" -> win?List.of("cmd.exe","/d","/c","gradlew.bat","--no-daemon","test","-Dqa.suite="+j.suite(),"-Dqa.targets="+String.join(",",j.targets()))
                          :List.of("./gradlew","--no-daemon","test","-Dqa.suite="+j.suite(),"-Dqa.targets="+String.join(",",j.targets()));
      case "playwright" -> win?List.of("cmd.exe","/d","/c","node_modules\\.bin\\playwright.cmd","test","--workers="+j.parallel())
                              :List.of("./node_modules/.bin/playwright","test","--workers="+j.parallel());
      case "cypress" -> win?List.of("cmd.exe","/d","/c","node_modules\\.bin\\cypress.cmd","run")
                            :List.of("./node_modules/.bin/cypress","run");
      case "saucectl" -> List.of("saucectl","run");
      default -> throw new IllegalArgumentException("Not allowlisted");
    };
  }
  private Map<String,Object> junit(Path root) {
    int tests=0,failures=0,skipped=0;List<String> files=new ArrayList<>();
    try(var paths=Files.walk(root,9)){
      for(Path p:paths.filter(Files::isRegularFile).filter(x->x.getFileName().toString().startsWith("TEST-")&&x.toString().endsWith(".xml")).limit(200).toList()){
        if(p.toString().contains("node_modules"))continue;
        DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();
        f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
        f.setFeature("http://xml.org/sax/features/external-general-entities",false);
        f.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
        Element e=f.newDocumentBuilder().parse(p.toFile()).getDocumentElement();
        tests+=number(e.getAttribute("tests"));failures+=number(e.getAttribute("failures"))+number(e.getAttribute("errors"));
        skipped+=number(e.getAttribute("skipped"));files.add(root.relativize(p).toString());
      }
    }catch(Exception ignored){}
    return Map.of("tests",tests,"failures",failures,"skipped",skipped,"files",files);
  }
  private int number(String v){try{return Integer.parseInt(v);}catch(Exception e){return 0;}}
  private Path verifiedPath(String p) {
    try {Path path=Path.of(p).toRealPath();if(!Files.isDirectory(path)||Files.isSymbolicLink(path))throw new IllegalArgumentException("Not an approved directory");return path;}
    catch(IOException e){throw new IllegalArgumentException("Invalid framework directory",e);}
  }
  private boolean safeId(String x){return x!=null&&x.matches("[A-Za-z0-9_-]{1,64}");}
  private boolean isWindows(){return System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");}
  private synchronized Job replace(Job j,String state,Integer exit,String msg,String log,String report){
    Job n=new Job(j.id(),state,j.framework(),j.suite(),j.directory(),j.targets(),j.parallel(),j.useSauce(),j.startedAt(),
      Set.of("PASSED","FAILED","REJECTED").contains(state)?Instant.now().getEpochSecond():null,exit,msg,
      log==null?j.logFile():log,report==null?j.reportFile():report);
    persist(n);return n;
  }
  private void persist(Job j){
    try{Files.createDirectories(dir);Path tmp=Files.createTempFile(dir,"job-",".tmp");Files.writeString(tmp,json.writeValueAsString(j));
      try{Files.move(tmp,dir.resolve(j.id()+".json"),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
      catch(AtomicMoveNotSupportedException e){Files.move(tmp,dir.resolve(j.id()+".json"),StandardCopyOption.REPLACE_EXISTING);}
    }catch(IOException e){throw new IllegalStateException("Cannot persist local run",e);}
  }
}
