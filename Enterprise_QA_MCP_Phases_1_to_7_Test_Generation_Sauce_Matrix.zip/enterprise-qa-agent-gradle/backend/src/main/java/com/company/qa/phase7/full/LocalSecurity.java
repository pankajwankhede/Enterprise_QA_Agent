package com.company.qa.phase7.full;

import java.security.SecureRandom;
import java.util.Base64;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import org.springframework.stereotype.Component;
import org.springframework.core.annotation.Order;
/** Per-process bearer key delivered through browser URL fragment, never via HTTP query or server log. */
@Component @Order(1)
public class LocalSecurity implements Filter {
  private final String token;
  public LocalSecurity(){byte[] secret=new byte[32];new SecureRandom().nextBytes(secret);token=Base64.getUrlEncoder().withoutPadding().encodeToString(secret);}
  public String launchFragment(){return token;}
  @Override public void doFilter(ServletRequest req,ServletResponse res,FilterChain chain)throws IOException,ServletException{
    HttpServletRequest r=(HttpServletRequest)req;HttpServletResponse w=(HttpServletResponse)res;
    if(!r.getRemoteAddr().equals("127.0.0.1")&&!r.getRemoteAddr().equals("0:0:0:0:0:0:0:1")) {w.sendError(403);return;}
    if(r.getRequestURI().startsWith("/api/v1/phase7/live")) {
      String supplied=r.getHeader("X-QA-Local-Token");
      if(supplied==null||!java.security.MessageDigest.isEqual(token.getBytes(java.nio.charset.StandardCharsets.UTF_8),supplied.getBytes(java.nio.charset.StandardCharsets.UTF_8))){w.sendError(401,"Local UI session required");return;}
      String origin=r.getHeader("Origin");
      if(origin!=null&&!origin.equals("http://127.0.0.1:8765")){w.sendError(403,"Origin not allowed");return;}
      w.setHeader("Cache-Control","no-store");
    }
    chain.doFilter(req,res);
  }
}
