package com.company.qa;

import java.awt.Desktop;
import java.net.URI;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import com.company.qa.phase7.full.LocalSecurity;

/** Open the user's browser only in the opt-in portal profile. Never reads credentials. */
@Component
public class PortalBrowserLauncher {
  @Value("${qa.portal.browser.auto-open:false}") private boolean enabled;
  private final LocalSecurity security;
  public PortalBrowserLauncher(LocalSecurity security){this.security=security;}
  @EventListener(ApplicationReadyEvent.class)
  public void launch() {
    if (!enabled) return;
    try {
      if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
        Desktop.getDesktop().browse(URI.create("http://127.0.0.1:8765/#qa-session="+security.launchFragment()));
      }
    } catch (Exception ex) {
      System.err.println("Browser launch failed. Restart with auto-open enabled; do not use an unauthenticated portal session.");
    }
  }
}
